function [wk, w0] = fenkaiSDR_solving(hr_k, g, hd_k, hr_n, hd_n, M, Nt, phi0, phik, Kcluster, N, SNR, PS, Pirs, pout, derta1_2, derta2_2, derta3n_2, Edt, t1, t0, yita)
       K=Kcluster;
       for k=1:K
            hk(:,k)=hd_k(:,k)+g*phik(:,:,k)*hr_k(:,k);  %Nt*1
            Gk(:,:,k)=g*phik(:,:,k);   %Nt*M
            hrk(:,k)=(norm(phik(:,:,k)*hr_k(:,k)))^2;   %1*1
            Ik(:,k)=derta1_2*(norm(phik(:,:,k)*eye(M)))^2;   %1*1
        end
        G1=phi0*g';  %M*Nt
        I0=derta1_2*(norm(phi0*eye(M)))^2;  %1*1
        for n=1:N
            hrn(:,n)=derta1_2*(norm((hr_n(:,n))'*phi0))^2;  %1*1
        end
        hn=[];
        for n=1:N
            hn=[hn ; ((hd_n(:,n))'+(hr_n(:,n))'*phi0*g')];  %1*Nt
        end
       
        for k=1:K
            Ak(:,:,k)=derta1_2*(Gk(:,:,k)*(Gk(:,:,k))')+derta2_2*eye(Nt);
            Hk(:,:,k)=hk(:,k)*(hk(:,k))';
        end
        C1=0;
        for n=1:N
            Cn1(:,:,n)=PS*((hn(n,:))'*hn(n,:));
            C1=C1+Cn1(:,:,n);
        end
        C=t0*yita*C1;
        HZ1=0;
        for n=1:N
            Hz1(:,n)=hrn(:,n)+derta3n_2;
            HZ1=HZ1+Hz1(:,n);
        end
        HZ=t0*yita*HZ1;
        BB=PS*(G1'*G1);  %BB为原文的B 
        cvx_begin sdp quiet
            variable Wk1(Nt,Nt,K) hermitian semidefinite;%此处的Wk1是原文的Wk~,即pk*Wk,非负常数乘以半正定阵仍是半正定的 
            variable W0(Nt,Nt) hermitian semidefinite; 
            variable pk(1,K);
            expression Y;
            Y=[];
            for k=1:K
                Y=[Y (t1*((trace(Ak(:,:,k)*Wk1(:,:,k)))*SNR+(trace(Ak(:,:,k)*Wk1(:,:,k)))*SNR*hrk(:,k)+Ik(:,k)+M*Pirs))];
            end
%             Y1=sum(Y(1:K));
%             minimize real(Y1+Edt+t0*(PS*trace(W0)+M*PIRS+trace(BB*W0)+I0)-t0*yita*Z1);
            maximize real(trace(C*W0)+HZ-sum(Y(1:K))-Edt-t0*(PS*trace(W0)+M*Pirs+trace(BB*W0)+I0));
            subject to
            for k=1:K
                real(trace(Hk(:,:,k)*Wk1(:,:,k)))==1;
                real((trace(Ak(:,:,k)*Wk1(:,:,k)))*SNR*hrk(:,k)+Ik(:,k))<=pout;
                real(trace(Wk1(:,:,k)))<=pk(:,k);
                pk(:,k)>=0;
                Wk1(:,:,k)==hermitian_semidefinite(Nt);
            end
                real(trace(BB*W0)+I0)<=pout;
                real(trace(W0))<=1;
                W0==hermitian_semidefinite(Nt);
       cvx_end
%        %**********判断是否为秩1矩阵***************
%        for k=1:K
%            A = W0;
%            % 计算 A 的秩
%            r = rank(A);
%            % 判断秩是否为1
%            if r == 1
%                disp('A 的秩为1');
%            else
%                disp('A 的秩不为1');
%            end
%        end
       %*****************************************基于惩罚的方法恢复最优秩一解，上行
       wk=[];
       for k=1:K
%           epsilon2 = K*(1e-3);
%           epsilon2 = (1e-3);
%           epsilon3 = K*(1e-3);
%           epsilon3 = (1e-3);
          pun = 10; % 惩罚权重
          [x0k(:,:,k),y0k(:,:,k)]=eig(Wk1(:,:,k)); % 求矩阵的特征值和特征向量，x为特征向量矩阵，y为特征值矩阵。
          eigenvaluek(:,k)=diag(y0k(:,:,k)); % 求对角线向量
          lambda0k(:,k) =max(eigenvaluek(:,k)); % 求最大特征值
          for i=1:length(Wk1(:,:,k))
              if lambda0k(:,k) == eigenvaluek(i,k)
                  break;
              end
          end
          u_max0k(:,k) = x0k(:,i,k);%求矩阵最大特征值对应的特征向量
       end
%        KK=[];
%        for k=1:K
%            KK=[KK abs(trace(Wk1(:,:,k))-lambda0k(:,k))];
%        end
%            %*******************判断每一项是否符合秩1矩阵******************quiet
       for k=1:K
           if abs(trace(Wk1(:,:,k))-lambda0k(:,k))>1e-3
               ttt(k)=1;
           else
               ttt(k)=0;
           end
       end  
%            %************************************************************
       while (all(ttt) ==1)
            cvx_begin sdp quiet
                variable Wk2(Nt,Nt,K) hermitian semidefinite;%此处的Wk1是原文的Wk~,即pk*Wk,非负常数乘以半正定阵仍是半正定的
                variable pk2(1,K);
                expression Y1;
                expression Z;
                Y1=[];
                for k=1:K
                    Y1=[Y1 (t1*((trace(Ak(:,:,k)*Wk2(:,:,k)))*SNR+(trace(Ak(:,:,k)*Wk2(:,:,k)))*SNR*hrk(:,k)+Ik(:,k)+M*Pirs))];
                end
                Z=[];
                for k=1:K
                    Z=[Z (trace(Wk2(:,:,k))-((u_max0k(:,k))'*Wk2(:,:,k)*(u_max0k(:,k))))];
                end
                minimize real(sum(Y1(1:K)))+pun*real(sum(Z(1:K)));
                subject to
                for k=1:K
                    real(trace(Hk(:,:,k)*Wk2(:,:,k)))==1;
                    (1e0)*real((trace(Ak(:,:,k)*Wk2(:,:,k)))*SNR*hrk(:,k)+Ik(:,k))<=(1e0)*pout;
                    real(trace(Wk2(:,:,k)))<=pk2(:,k);
                    (pk2(:,k))>=0;
                    Wk2(:,:,k)==hermitian_semidefinite(Nt);
                end
            cvx_end
            for k=1:K
                [x1k(:,:,k),y1k(:,:,k)]=eig(Wk2(:,:,k)); % 求矩阵的特征值和特征向量，x为特征向量矩阵，y为特征值矩阵。
                eigenvaluek1(:,k)=diag(y1k(:,:,k)); % 求对角线向量
                lambda1k(:,k)=max(eigenvaluek1(:,k)); % 求最大特征值
                for i=1:length(Wk2(:,:,k))
                    if lambda1k(:,k) == eigenvaluek1(i,k)
                       break;
                    end
                end
                u_max1k(:,k) = x1k(:,i,k);%求矩阵最大特征值对应的特征向量
            end
%             nn=[];
%             for k=1:K
%                 nn=[nn norm((Wk2(:,:,k)-Wk1(:,:,k)),"fro")];
%             end
            for k=1:K
                if norm(Wk2(:,:,k)-Wk1(:,:,k),"fro") <= 1e-3
                    nnn(k)=1;
                else
                    nnn(k)=0;
                end
            end
            if all(nnn)==1
%             if sum(nn(1:K))<=epsilon3
                pun = 2*pun;
            else
                Wk1 = Wk2;
                u_max0k = u_max1k;
                lambda0k= lambda1k;
                pk=pk2;
            end
            for k=1:K
                if abs(trace(Wk1(:,:,k))-lambda0k(:,k))>1e-3
                    ttt(k)=1;
                else
                    ttt(k)=0;
                end
           end  
       end
      for k=1:K
          Wk(:,:,k)=Wk1(:,:,k)/pk(:,k);
          [xk,yk]=eig(Wk(:,:,k)); % 求矩阵的特征值和特征向量，x为特征向量矩阵，y为特征值矩阵。
          eigenvalue=diag(yk); % 求对角线向量
          lambdak=max(eigenvalue); % 求最大特征值
          for i=1:length(Wk(:,:,k))
              if lambdak == eigenvalue(i)
                 break;
              end
          end
          u_maxk = xk(:,i);%求矩阵最大特征值对应的特征向量
          wkk = u_maxk*sqrt(lambdak); % 最佳波束赋形
          wk=[wk wkk];
      end
%       for k=1:K
%           if wk(:,k)'*wk(:,k)<=1
%               eee(k)=1;
%           else
%               eee(k)=0;
%           end
%       end
       %*****************************************基于惩罚的方法恢复最优秩一解，下行
       epsilon22 = 1e-3;
       epsilon3 = 1e-3;
       pun = 10; % 惩罚权重
       [x0,y0]=eig(W0); % 求矩阵的特征值和特征向量，x为特征向量矩阵，y为特征值矩阵。
       eigenvalue=diag(y0); % 求对角线向量
       lambda0 =max(eigenvalue); % 求最大特征值
       for i=1:length(W0)
           if lambda0 == eigenvalue(i)
               break;
           end
       end
       u_max0 = x0(:,i);%求矩阵最大特征值对应的特征向量
       while abs(trace(W0)-lambda0) > epsilon22
             cvx_begin sdp quiet
                 variable W02(Nt,Nt) hermitian semidefinite
                 minimize real(-(trace(C*W02)+HZ-t0*(PS*trace(W02)+M*Pirs+trace(BB*W02)+I0)))...
                          + pun*real(trace(W02)-u_max0'*W02*u_max0)
                 subject to
                (1e+12)*real(trace(BB*W02)+I0)<=(1e+12)*pout;
                (1e+0)*real(trace(W02))<=(1e+0)*1;
                W02==hermitian_semidefinite(Nt);
            cvx_end
            [x1,y1]=eig(W02); % 求矩阵的特征值和特征向量，x为特征向量矩阵，y为特征值矩阵。
            eigenvalue=diag(y1); % 求对角线向量
            lambda1=max(eigenvalue); % 求最大特征值
            for i=1:length(W02)
                if lambda1 == eigenvalue(i)
                   break;
                end
            end
            u_max1 = x1(:,i);%求矩阵最大特征值对应的特征向量
            if norm(W02-W0,"fro") <= epsilon3
               pun = 2*pun;
            else
            W0 = W02;
            u_max0 = u_max1;
            lambda0 = lambda1;
            end
       end
       [x,y]=eig(W0); % 求矩阵的特征值和特征向量，x为特征向量矩阵，y为特征值矩阵。
       eigenvalue=diag(y); % 求对角线向量
       lambda=max(eigenvalue); % 求最大特征值
       for i=1:length(W0)
           if lambda == eigenvalue(i)
              break;
           end
       end
       u_max = x(:,i);%求矩阵最大特征值对应的特征向量
       w0 = u_max*sqrt(lambda); % 最佳波束赋形
end