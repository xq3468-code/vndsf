function [v0] = pehSCA(g, hr_n, hd_n, M, N,  PS, w0)
        phi0_=unifrnd(0,2*pi,M,1);
        v0=cos(phi0_)+sin(phi0_)*1j;  %v0_为原文的v0_q-1，即SCA算法的初始迭代点 M*1
        w01=(norm(w0))^2;  %w01为原文的w0_，即||w0||^2
        g0_=(w0)'*g;  %1*M
        for n=1:N
            hdn_(:,n)=(w0)'*(hd_n(:,n));  %1*1
            bn(:,n)=diag((hr_n(:,n))')*(g0_)';  %M*1
        end
        Sh=0;
        for n=1:N
            Sh1(:,:,n)=bn(:,n)*(bn(:,n))';
            Sh=Sh+Sh1(:,:,n);
        end
        E=PS*Sh;
        bd=0;
        for n=1:N
            bd1(:,n)=bn(:,n)* hdn_(:,n);
            bd=bd+bd1(:,n);
        end
        for itsca=1:500
            yitam=E*v0+PS*bd;
            v0_=zeros(M,1);
            for m=1:M
                if yitam(m)==0
                    v0_(m,1)=1;
                else
                    v0_(m,1)=(yitam(m))/abs(yitam(m));
                end
            end
            if norm(v0-v0_)<=1e-12
                break
            else
                v0=v0_;
            end
        end        
end