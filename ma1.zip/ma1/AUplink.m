% function [eemU,EEmU]=AUplink(g,hd_k,hr_k,hd_n,hr_n,Kcluster,ECM,N,Esink,ECH_intra,L)
clear;
clc;


EE_4=zeros(10,1);
HH14=zeros(10,100);
Etotal_4=zeros(10,1);
EEe14=zeros(10,100);
Ex_4=zeros(10,1);
EE1_4=zeros(10,100);
HH4=zeros(1,100);
pout=db2pow(8)/1000;%pout为5dBm 10^-2.5 10dBm:10^-2; PC=PDC=-10dBm=10^-4,pIRS=10dBm=0.01
PC=db2pow(-10)/1000;
PDC=db2pow(-10)/1000;
Pirs=PC+PDC;
PS=10; %PS为30dBm 10^0 , 40dBm:10W , 37dBm:10^0.7,46dBm:40W，此处的PA是原文的PS，下同
M=10; %反射单元数
lamuda=0.3333; %信号传输波长0.325,0.3333
C0=(lamuda/(4*pi))^2; 
Nt=4; %sink天线数量
% dsink=lamuda/2; %天线之间的间隔半波长
% dx=lamuda/2;%每个RE的dx,相邻RE之间假定半波长间隔
% dy=lamuda/2;%每个RE的dy
Kcluster=100;
% Kcluster=20;%20个簇,sink(0,0,0),IRS(0,yIRS,dv),CHs(x(k),y(k),0)%%%%%%%%%%改变CHs数，ECM也要改
% CHpositionx=xlsread('100jiedianECM.xlsx','C7:V7');%CH节点坐标
% CHpositiony=xlsread('100jiedianECM.xlsx','C8:V8');
% K=15; %15个簇,sink(0,0,0),IRS(0,yIRS,dv),CHs(x(k),y(k),0)%%%%%%%%%%改变CHs数，ECM也要改
% CHpositionx=xlsread('100jiedianECM.xlsx','C11:Q11');%CH节点坐标
% CHpositiony=xlsread('100jiedianECM.xlsx','C12:Q12'); 
% K=10; %10个簇,sink(0,0,0),IRS(0,yIRS,dv),CHs(x(k),y(k),0)%%%%%%%%%%改变CHs数，ECM也要改
% CHpositionx=xlsread('100jiedianECM.xlsx','C15:L15');%CH节点坐标
% CHpositiony=xlsread('100jiedianECM.xlsx','C16:L16');
% K=5; %5个簇,sink(0,0,0),IRS(0,yIRS,dv),CHs(x(k),y(k),0)%%%%%%%%%%改变CHs数，ECM也要改
% CHpositionx=xlsread('100jiedianECM.xlsx','C19:G19');%CH节点坐标
% CHpositiony=xlsread('100jiedianECM.xlsx','C20:G20');
% x=CHpositionx;
% y=CHpositiony;
CRSNspositionx=xlsread('100jiedianECM.xlsx','C2:CX2');%CRSNs节点坐标
CRSNspositiony=xlsread('100jiedianECM.xlsx','C3:CX3');
x1=CRSNspositionx;
y1=CRSNspositiony;
x=CRSNspositionx;
y=CRSNspositiony;
Eelec=50*0.000000001;%发送和接收数据时电路能耗Eelec=50nJ/b 
% Efs=10*0.000000000001;%发送时功率放大器功耗取决于距离，当小于参考距离d0时为10pJ/b/m2;大于参考距离d0时为0.0013pJ/b/m4
% Emp=0.0013*0.000000000001;
EDA=5*0.000000001; %聚合数据时消耗能量为5nJ/b/packet
L=1000;%数据包大小1000bit,控制包大小100bit                              
N=100;%簇内CRSNs节点总数为100
% R_=2;%簇半径为2m
% dCMtoCH=(2*R_)/3;
ECM=0;
ECH_intra=0;
% ECM=L1*(Eelec+Efs*(dCMtoCH)^2);
% ECM=xlsread('100jiedianECM.xlsx','C10:C10');  %20CHs  %ECM是从CogLEACH中算出来的，此处的ECM为原文的(N-K)*ECM
% ECM=xlsread('100jiedianECM.xlsx','C14:C14');  %15CHs
% ECM=xlsread('100jiedianECM.xlsx','C18:C18');  %10CHs
% ECM=xlsread('100jiedianECM.xlsx','C22:C22');  %5CHs
% ECH_intra=((N/Kcluster)-1)*(Eelec+EDA)*L; %从CogLEACH里过来的ECH_intra是原文的K*ECH_intra
Esink=Kcluster*Eelec*L;
% Edt=Kcluster*Eelec*L+ECM+Kcluster*ECH_intra;
Edt=Esink+ECM+ECH_intra;
HIRS = 5; % IRS与平面的垂直距离
D0=1;%参考距离
derta2_2=10^-11; %噪声功率-80dBm:10^-11
derta1_2=10^-11;
derta3n_2=10^-11;
% 路损参数
alpha_SI = 2.3; %级联链路莱斯
alpha_IC = 2.3;
alpha_SC = 2.9; %直接链路自由空间
% beta_SI = 10; %莱斯因子10  db2pow(3)
% beta_IC = 10;
% beta_SC = 10;
beta_SI = db2pow(3); %莱斯因子10  db2pow(3)
beta_IC = db2pow(3);
beta_SC = db2pow(3);
beta_SC = 0;
www=[];
t0=0.5;%sink辐射时间1s
t1=0.001;%CH k上行数据传输时长0.01s  此处的t1为原文的taok  taok=L/Rs=1000/10^6=0.001s
SNR=db2pow(30);%30dB
Bt=100000; %信道带宽  Rb=Blog2(1+SNR),Rb=1Mbps,SNR=30dB,推出B=1.0033e+05
R=Bt*log2(1+SNR);
tintra=(N/Kcluster-1)*(L/(Bt*log2(1+SNR)));
T=Kcluster*t1+t0+tintra;
Rtotal=((Bt*log2(1+SNR))*Kcluster*tintra+(t1*Kcluster)*R)/(T-t0);
% Rtotal=R; %Rtotal为R的倍数
yita=0.8; %能量转换效率
epsilon=1e-3;
maxIter=20; %20
eee1=[];
ES=[];
Exx=[];
% eee=[]; %建立空数组，为最后100次取平均值做准备
% hhh=[];
% ppk=[];
nengxiao=[];
% HHM=[];
% yIRS=-50:10:50;   %IRS:(0,yIRS,dv)-50:0.1:50
for it=1:5 %跑100次取平均值 it=1:100
    it
%     weizhi=[];
%     Eee=[];
%     Etotal=[];
%     Eeh=[];
    for yIRS=2.1   %IRS:(0,yIRS,dv)-50:0.1:50  -0.4
% %     for yirs=1:length(yIRS)
% %         yirs
% %         yIRS_irs = yIRS(yirs);
% %         yIRS
        sinkloc=[0;0;0]; %sink坐标[0,0,0]
        CHsloc=[];
        IRSloc=[0;yIRS;HIRS];
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%远场条件下IRS一块板反射信号，不具体表示每个RE的坐标%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        dIS=sqrt(sum((IRSloc-sinkloc).^2)); %IRS到sink之间的距离Nt*M
        for k=1:Kcluster
            CHsloc=[CHsloc [x(:,k);y(:,k);0]];
        end
        dCS=[]; 
        for k=1:Kcluster
            dCS=[dCS sqrt(sum((sinkloc-CHsloc(:,k)).^2))];%sink到CHs距离Nt*1
        end
        dCI=[];
        for k=1:Kcluster
            dCI=[dCI sqrt(sum((CHsloc(:,k)-IRSloc).^2))]; %CHs到IRS距离M*1
        end
        g=sqrt(C0*((dIS/D0).^(-alpha_SI)))*(sqrt(beta_SI/(beta_SI+1))*ones(Nt,M)+sqrt(1/(beta_SI+1))*(sqrt(1/2)*(randn(Nt,M)+1j*randn(Nt,M)))); 
        for k=1:Kcluster
            hr_k(:,k)=sqrt(C0.*(((dCI(1,k))./D0).^(-alpha_IC)))*(sqrt(beta_IC/(beta_IC+1))*ones(M,1)+sqrt(1/(beta_IC+1))*(sqrt(1/2)*(randn(M,1)+1j*randn(M,1)))); %上行CH到IRS信道M*1
        end
        for k=1:Kcluster
            hd_k(:,k)=sqrt(C0.*((dCS(:,k)./D0).^(-alpha_SC)))*(sqrt(beta_SC/(beta_SC+1))*ones(Nt,1)+sqrt(1/(beta_SC+1))*(sqrt(1/2)*(randn(Nt,1)+1j*randn(Nt,1)))); %上行CH到sink信道Nt*1
        end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%上行信道构建完毕，开始构建下行信道%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        CRSNsloc=[];
        for n=1:N
            CRSNsloc=[CRSNsloc [x1(:,n);y1(:,n);0]];
        end
        dSC=[];
        for n=1:N
            dSC=[dSC sqrt(sum((CRSNsloc(:,n)-sinkloc).^2))];%sink到CRSNs距离Nt*1
        end
        dIC=[];
        for n=1:N
            dIC=[dIC sqrt(sum((CRSNsloc(:,n)-IRSloc).^2))]; %IRS到CRSNs距离1*M
        end
        for n=1:N
            hr_n(:,n)=sqrt(C0.*(((dIC(1,n))./D0).^(-alpha_IC)))*(sqrt(beta_IC/(beta_IC+1))*ones(M,1)+sqrt(1/(beta_IC+1))*(sqrt(1/2)*(randn(M,1)+1j*randn(M,1)))); %hr,n维度M*1
        end
        for n=1:N
            hd_n(:,n)=sqrt(C0.*((dSC(1,n)./D0).^(-alpha_SC)))*(sqrt(beta_SC/(beta_SC+1))*ones(Nt,1)+sqrt(1/(beta_SC+1))*(sqrt(1/2)*(randn(Nt,1)+1j*randn(Nt,1))));
        end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%至此所有信道构建完毕%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %交替优化算法
        %固定波束赋形优化反射因子矩阵
        w0c=randn(Nt,1)+1j.*randn(Nt,1);%随机生成发射波束向量
        w0_mo=sqrt(sum((abs(w0c)).^2));
        w0=w0c./w0_mo;%单位化  w0_为固定波束赋形优化反射因子矩阵的波束赋形向量，即交替优化算法的初始迭代点 Nt*1
        wk0=[];
        for k=1:Kcluster
            wkc=randn(Nt,1)+1j.*randn(Nt,1);%随机生成发射波束向量
            wk_mo=sqrt(sum((abs(wkc)).^2));
            wk_1=wkc./wk_mo;%单位化
            wk0=[wk0 wk_1];  %wk_为固定波束赋形优化反射因子矩阵的波束赋形向量，即交替优化算法的初始迭代点 Nt*1
        end
        wk=wk0;
        EE_old=0;
        EE=10;
        AO=[];
%         for Iao=1:50
%             Iao
%         if (abs((EE_old-EE)/EE)>epsilon)
        count=0;
%         while (abs((EE_old-EE)/EE)>epsilon && count < maxIter)
            count = count + 1;
%             count
        %SCA优化方法，得到上界
        [ak, v0, theta] = AUplinkSCA(hr_k, g, hd_k, M, Kcluster, SNR, PS, Pirs, pout, derta1_2, derta2_2, w0, wk, Edt, t1);
        for k=1:Kcluster
            vk(:,k)=ak(:,k).*exp(1j.*theta(:,k));
            phik(:,:,k)=diag((vk(:,k)).');
        end
        phi0=diag((v0)');
        %SDR优化波束赋形
        [wk, w0] = SDR_solving(hr_k, g, hd_k, hr_n, hd_n, M, Nt, phi0, phik, Kcluster, N, SNR, PS, Pirs, pout, derta1_2, derta2_2, derta3n_2, Edt, t1, t0, yita);
%         [wk, w0] = fenkaiSDR_solving(hr_k, g, hd_k, hr_n, hd_n, M, Nt, phi0, phik, Kcluster, N, SNR, PS, Pirs, pout, derta1_2, derta2_2, derta3n_2, Edt, t1, t0, yita);
        while (size(w0,1)==1 || size(wk,1)==1)
            w0c=randn(Nt,1)+1j.*randn(Nt,1);%随机生成发射波束向量
            w0_mo=sqrt(sum((abs(w0c)).^2));
            w0=w0c./w0_mo;%单位化  w0_为固定波束赋形优化反射因子矩阵的波束赋形向量，即交替优化算法的初始迭代点 Nt*1
            wk0=[];
            for k=1:Kcluster
                wkc=randn(Nt,1)+1j.*randn(Nt,1);%随机生成发射波束向量
                wk_mo=sqrt(sum((abs(wkc)).^2));
                wk_1=wkc./wk_mo;%单位化
                wk0=[wk0  wk_1];  %wk_为固定波束赋形优化反射因子矩阵的波束赋形向量，即交替优化算法的初始迭代点 Nt*1
            end
            wk=wk0;
            [ak, v0, theta] = AUplinkSCA(hr_k, g, hd_k, M, Kcluster, SNR, PS, Pirs, pout, derta1_2, derta2_2, w0, wk, Edt, t1);
            for k=1:Kcluster
                vk(:,k)=ak(:,k).*exp(1j.*theta(:,k));
                phik(:,:,k)=diag((vk(:,k)).');
            end
            phi0=diag((v0)');
            [wk, w0] = SDR_solving(hr_k, g, hd_k, hr_n, hd_n, M, Nt, phi0, phik, Kcluster, N, SNR, PS, Pirs, pout, derta1_2, derta2_2, derta3n_2, Edt, t1, t0, yita);
        end
        EE_old=EE;
        EE1=[];
        for k=1:Kcluster
            EE1=[EE1 (t1*(((derta1_2*(norm((wk(:,k))'*g*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k(:,k)+g*phik(:,:,k)*hr_k(:,k))))^2))*SNR+...
                ((derta1_2*(norm((wk(:,k))'*g*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k(:,k)+g*phik(:,:,k)*hr_k(:,k))))^2))*SNR*(norm(phik(:,:,k)*hr_k(:,k)))^2+...
                derta1_2*(norm(phik(:,:,k)*eye(M)))^2+M*Pirs)+(Eelec+EDA)*L)]; %Eelec*L是电子电路能耗，EDA*L是CHk聚合自身的能耗。
        end
        EE2=sum(EE1(1:Kcluster));
        Etotal_=EE2+Esink+ECM+ECH_intra+t0*(PS*(norm(w0))^2+M*Pirs+PS*(norm(phi0*g'*w0))^2+derta1_2*(norm(phi0*eye(M)))^2);
        Ex1=t0*(PS*(norm(w0))^2+M*Pirs+PS*(norm(phi0*g'*w0))^2+derta1_2*(norm(phi0*eye(M)))^2);
        HH1=[];
        for n=1:N
            HH1=[HH1 (PS*(abs(((hd_n(:,n))'+(hr_n(:,n))'*phi0*g')*w0))^2+derta1_2*(norm((hr_n(:,n))'*phi0))^2+derta3n_2)];
        end
        HH3=t0*yita*HH1
        HH2=sum(HH1(1:N));
        Eharvesting_=t0*yita*HH2;
        EE=Rtotal/(Etotal_-Eharvesting_);
        Ex=Ex1-Eharvesting_;
%         HHm=t0*yita*HH1;
        AO=[AO EE]; %看交替优化收敛性
%         end
%         HHM=[HHM ; HHm];
%         AO=[AO EE];
%         end
%         figure
%         plot(1:length(AO),real(AO));
%         weizhi=[weizhi EE]; %IRS不同位置的能效
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%所有CHs上行数据传输阶段消耗的总能量%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        EEe1=[];
        for k=1:Kcluster
            EEe1=[EEe1 (t1*((derta1_2*(norm((wk(:,k))'*g*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k(:,k)+g*phik(:,:,k)*hr_k(:,k))))^2))*SNR)];
        end
%         EEe2=sum(EEe1(1:Kcluster));
%         Eee=[Eee EEe2];
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%EH-CRSNs总功耗%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%         Egonghao=Etotal_; %CHs向sink传输数据的功耗，上下行主动IRS的功耗，sink的功耗

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%所有CRSNs节点收集的总能量%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%         Eeh1=Eharvesting_; %所有CRSNs节点收集的总能量
%         HHm=t0*yita*HH1; %每个CRSNs节点收集的能量
%         Eeh=[Eeh Eeh1];
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%CHk上行数据传输的发送功率%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%         pk=[];
%         for k=1:Kcluster
%             pk=[pk ((derta1_2*(norm((wk(:,k))'*g*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k(:,k)+g*phik(:,:,k)*hr_k(:,k))))^2))*SNR];
%         end
        
 % for io_1=1:11
  for io_1=1:1
xindaopiancha_1=[0,0.02,0.04,0.06,0.08,0.1,0.12,0.14,0.16,0.18,0.2];
xindaopiancha=xindaopiancha_1(io_1);
% for io=1:100
for io=1:1

        hd_k_3=hd_k-sqrt(xindaopiancha)*abs(hd_k).*(sqrt(1/2)*(randn(Nt,Kcluster)+1j*randn(Nt,Kcluster)));
        hr_k_3= hr_k-sqrt(xindaopiancha)*abs(hr_k).*(sqrt(1/2)*(randn(M,Kcluster)+1j*randn(M,Kcluster)));
       g_3=g-sqrt(xindaopiancha)*abs(g).*(sqrt(1/2)*(randn(Nt,M)+1j*randn(Nt,M))); 
        hd_n_3=hd_n-sqrt(xindaopiancha)*abs(hd_n).*(sqrt(1/2)*(randn(Nt,N)+1j*randn(Nt,N)));
        hr_n_3=hr_n-sqrt(xindaopiancha)*abs(hr_n).*(sqrt(1/2)*(randn(M,N)+1j*randn(M,N)));

EE_old=EE;
       EE1_1=[];
for k=1:Kcluster
    EE1_1=[EE1_1 (t1*(((derta1_2*(norm((wk(:,k))'*g_3*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k_3(:,k)+g_3*phik(:,:,k)*hr_k_3(:,k))))^2))*SNR+...
        ((derta1_2*(norm((wk(:,k))'*g_3*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k_3(:,k)+g_3*phik(:,:,k)*hr_k_3(:,k))))^2))*SNR*(norm(phik(:,:,k)*hr_k_3(:,k)))^2+...
        derta1_2*(norm(phik(:,:,k)*eye(M)))^2+M*Pirs)+(Eelec+EDA)*L)]; %Eelec*L是电子电路能耗，EDA*L是CHk聚合自身的能耗。
end
EE2_1=sum(EE1_1(1:Kcluster));
Etotal_1=EE2_1+Esink+ECM+ECH_intra+t0*(PS*(norm(w0))^2+M*Pirs+PS*(norm(phi0*g_3'*w0))^2+derta1_2*(norm(phi0*eye(M)))^2);
Ex1_1=t0*(PS*(norm(w0))^2+M*Pirs+PS*(norm(phi0*g_3'*w0))^2+derta1_2*(norm(phi0*eye(M)))^2);
HH1_1=[];
for n=1:N
    HH1_1=[HH1_1 (PS*(abs(((hd_n_3(:,n))'+(hr_n_3(:,n))'*phi0*g_3')*w0))^2+derta1_2*(norm((hr_n_3(:,n))'*phi0))^2+derta3n_2)];
end
HH2_1=sum(HH1_1(1:N));
Eharvesting_1=t0*yita*HH2_1;
EE_1=Rtotal/(Etotal_1-Eharvesting_1);
Ex_1=Ex1_1-Eharvesting_1;
%        
      
       
%         HHM=[HHM ; HHm];
%         AO=[AO EE];
%         end
%         figure
%         plot(1:length(AO),real(AO));
%         weizhi=[weizhi EE]; %IRS不同位置的能效
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%所有CHs上行数据传输阶段消耗的总能量%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
EEe1_1=[];
for k=1:Kcluster
    EEe1_1=[EEe1_1 (t1*((derta1_2*(norm((wk(:,k))'*g_3*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k_3(:,k)+g_3*phik(:,:,k)*hr_k_3(:,k))))^2))*SNR)];
end

EE_2(io)=EE_1;
HH12(io,:)=HH1_1;
Etotal_2(io,:)=Etotal_1;
EEe12(io,:)=EEe1_1;
Ex_2(io,:)=Ex_1;
EE1_2(io,:)=EE1_1;
end
EE_3(io_1,:)=sum(EE_2)/io;
HH13(io_1,:)=sum(HH12,1)/io;
Etotal_3(io_1,:)=sum(Etotal_2,1)/io;
EEe13(io_1,:)=sum(EEe12,1)/io;
Ex_3(io_1,:)=sum(Ex_2,1)/io;
EE1_3(io_1,:)=sum(EE1_2,1)/io;
 end
 HH3_1=t0*yita*HH13;;
 EE_4=EE_4+EE_3;
HH14=HH13+HH14;
Etotal_4=Etotal_3+Etotal_4;
EEe14=EEe13+EEe14;
Ex_4=Ex_3+Ex_4;
EE1_4=EE1_3+EE1_4;
HH4=HH3+HH4;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    end
%     figure
%     plot(1:length(weizhi),real(weizhi));
    eee1=[eee1 ; EEe1];
    ES=[ES ; EE1];
    Exx=[Exx ; Ex];
%     eee=[eee ; Eee];
%     hhh=[hhh ; Eeh];
%     HHM=[HHM ; HHm];
%     ppk=[ppk ; pk];
    nengxiao=[nengxiao ; EE]; %it次不同IRS位置能效
end

EE_5=EE_4/it;
HH15=HH14/it;
HH16=t0*yita*HH15
Etotal_5=Etotal_4/it;
EEe15=EEe14/it;
Ex_5=+Ex_4/it;
EE1_5=EE1_4/it;
eemU=mean(eee1,1);
EEmU=mean(nengxiao,1);
ESS=mean(ES,1);
EXX=mean(Exx,1);