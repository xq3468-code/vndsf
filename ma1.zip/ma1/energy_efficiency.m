% function [eem,EEm]=energy_efficiency(g,hd_k,hr_k,hd_n,hr_n,Kcluster,ECM,N,Esink,ECH_intra,L)
clear;
clc;
% EE_4=zeros(11,1);
% HH14=zeros(11,100);
% Etotal_4=zeros(11,1);
% EEe14=zeros(11,100);
% Ex_4=zeros(11,1);
% EE1_4=zeros(11,100);
% HH4=zeros(1,100);
SS11={};
AO3={};

v0_1=[];
EE_4=[];
HH14=[];
Etotal_4=[];
EEe14=[];
Ex_4=[];
EE1_4=[];
HH4=zeros(1,100);
akio1={};akio2={};akio3={};akio4={};akio5={};
akio6={};akio7={};akio8={};akio9={};akio10={};akio11={};
% akio12={};akio13={};akio14={};akio15={};akio16={};akio17={};akio18={};
% akio19={};akio20={};akio21={};akio22={};akio23={};





pout=db2pow(8)/1000;%pout为5dBm 10^-2.5 10dBm:10^-2; PC=PDC=-10dBm=10^-4,pIRS=10dBm=0.01   pout=8dBm
PC=db2pow(-10)/1000;
PDC=db2pow(-10)/1000;
Pirs=PC+PDC;
PS=10; %PS为30dBm 10^0 , 40dBm:10W , 37dBm:10^0.7,46dBm:40W，此处的PA是原文的PS，下同
M=10; %反射单元数7 M=8
lamuda=0.3333; %信号传输波长0.325,0.3333
C0=(lamuda/(4*pi))^2; 
Nt=4; %sink天线数量
% dsink=lamuda/2; %天线之间的间隔半波长
% dx=lamuda/2;%每个RE的dx,相邻RE之间假定半波长间隔
% dy=lamuda/2;%每个RE的dy
Kcluster=100;
% Kcluster=20;%20个簇,sink(0,0,0),IRS(0,yIRS,dv),CHs(x(k),y(k),0)%%%%%%%%%%改变CHs数，ECM也要改
% CHpositionx=xlsread('100jiedianECM.xlsx','C7:V7');%CH节点坐标
% CHpositiony=xlsread('100jiedianECM.xlsx','C8:V8'); 
% K=15; %15个簇,sink(0,0,0),IRS(0,yIRS,dv),CHs(x(k),y(k),0)%%%%%%%%%%改变CHs数，ECM也要改
% CHpositionx=xlsread('100jiedianECM.xlsx','C11:Q11');%CH节点坐标
% CHpositiony=xlsread('100jiedianECM.xlsx','C12:Q12'); 
% K=10; %10个簇,sink(0,0,0),IRS(0,yIRS,dv),CHs(x(k),y(k),0)%%%%%%%%%%改变CHs数，ECM也要改
% CHpositionx=xlsread('100jiedianECM.xlsx','C15:L15');%CH节点坐标
% CHpositiony=xlsread('100jiedianECM.xlsx','C16:L16');
% K=5; %5个簇,sink(0,0,0),IRS(0,yIRS,dv),CHs(x(k),y(k),0)%%%%%%%%%%改变CHs数，ECM也要改
% CHpositionx=xlsread('100jiedianECM.xlsx','C19:G19');%CH节点坐标
% CHpositiony=xlsread('100jiedianECM.xlsx','C20:G20');
% x=CHpositionx;
% y=CHpositiony;
CRSNspositionx=xlsread('100jiedianECM.xlsx','C2:CX2');%CRSNs节点坐标
CRSNspositiony=xlsread('100jiedianECM.xlsx','C3:CX3');
% CRSNspositionx=readtable('100jiedianECM.xlsx','Sheet','Sheet1','Range','C2:CX2');
% CRSNspositiony=readtable('100jiedianECM.xlsx','Sheet','Sheet1','Range','C3:CX3');
x1=CRSNspositionx;
y1=CRSNspositiony;
x=CRSNspositionx;
y=CRSNspositiony;
Eelec=50*0.000000001;%发送和接收数据时电路能耗Eelec=50nJ/b 
% Efs=10*0.000000000001;%发送时功率放大器功耗取决于距离，当小于参考距离d0时为10pJ/b/m2;大于参考距离d0时为0.0013pJ/b/m4
% Emp=0.0013*0.000000000001;
EDA=5*0.000000001; %聚合数据时消耗能量为5nJ/b/packet
L=1000;%数据包大小1000bit,控制包大小100bit                              
N=100;%簇内CRSNs节点总数为100
% R_=2;%簇半径为2m
% dCMtoCH=(2*R_)/3;
ECM=0;
ECH_intra=0;
% ECM=L1*(Eelec+Efs*(dCMtoCH)^2);
% ECM=xlsread('100jiedianECM.xlsx','C10:C10');  %20CHs  %ECM是从CogLEACH中算出来的，此处的ECM为原文的(N-K)*ECM
% ECM=xlsread('100jiedianECM.xlsx','C14:C14');  %15CHs
% ECM=xlsread('100jiedianECM.xlsx','C18:C18');  %10CHs
% ECM=xlsread('100jiedianECM.xlsx','C22:C22');  %5CHs
 % ECH_intra=((N/Kcluster)-1)*(Eelec+EDA)*L; %从CogLEACH里过来的ECH_intra是原文的K*ECH_intra
Esink=Kcluster*Eelec*L;
% Edt=Kcluster*Eelec*L+ECM+Kcluster*ECH_intra;
Edt=Esink+ECM+ECH_intra;
HIRS = 5; % IRS与平面的垂直距离
D0=1;%参考距离
derta2_2=10^-11; %噪声功率-80dBm:10^-11
derta1_2=10^-11;
derta3n_2=10^-11;
% 路损参数
alpha_SI = 2.3; %级联链路莱斯
alpha_IC = 2.3;
alpha_SC = 2.9; 
% alpha_SI = 2; %自由空间
% alpha_IC = 2;
% alpha_SC = 2; 
% beta_SI = 10; %莱斯因子10  db2pow(3)
% beta_IC = 10;
% beta_SC = 10;
beta_SI = db2pow(3); %莱斯因子10  db2pow(3)
beta_IC = db2pow(3);
beta_SC = db2pow(3);
% beta_SC = 0;
www=[];
t0=0.5;%sink辐射时间1s
t1=0.001;%CH k上行数据传输时长0.01s  此处的t1为原文的taok  taok=L/Rs=1000/10^6=0.001s
SNR=db2pow(30);%30dB
Bt=100000; %信道带宽  Rb=Blog2(1+SNR),Rb=1Mbps,SNR=30dB,推出B=1.0033e+05
R=Bt*log2(1+SNR);
tintra=(N/Kcluster-1)*(L/(Bt*log2(1+SNR)));
T=Kcluster*t1+t0+tintra;
Rtotal=((Bt*log2(1+SNR))*Kcluster*tintra+(t1*Kcluster)*R)/(T-t0);
% Rtotal=R; %Rtotal为R的倍数
yita=0.8; %能量转换效率
epsilon=1e-3;
% epsilon=2*1e-3;
% maxIter=10;
maxIter=20;
eee1=[];
ES=[];
Exx=[];
% eee=[]; %建立空数组，为最后100次取平均值做准备
% hhh=[];
% ppk=[];
nengxiao=[];
nengxiao1=[];
nengxiao_2=[];
nengxiao2=[];
p_k=[0.01:0.01:0.2];
% weizhi=[];
% HHM=[];0
% yIRS=-50:10:50;   %IRS:(0,yIRS,dv)-50:0.1:50



for it=1:10


     weizhi_2=[];
%     Eee=[];
%     Etotal=[];
%     Eeh=[];
ioi=0;
opp=[0.1:0.1:4];
weizhi=[];
     yIRS=2.1   %IRS:(0,yIRS,dv)-50:0.1:50  2.1
   for ioi=1:1


ioi=0;
opp=[0.1:0.1:4];
weizhi=[];
     yIRS=2.1


% %     for yirs=1:length(yIRS)
% yIRS= opp(it);
% ioi=ioi+1
% PC=db2pow(-10+ioi)/1000;
% PDC=db2pow(-10+ioi)/1000;
% PC=db2pow(-11.8)/1000;
% PDC=db2pow(12.43)/1000;
% 
% 
% Pirs=PC+PDC;
% %         yirs
% %         yIRS_irs = yIRS(yirs);
%         yIRS
        sinkloc=[0;0;0]; %sink坐标[0,0,0]
        CHsloc=[];
        IRSloc=[0;yIRS;HIRS];
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%远场条件下IRS一块板反射信号，不具体表示每个RE的坐标%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      
        
        
        
        dIS=sqrt(sum((IRSloc-sinkloc).^2)); %IRS到sink之间的距离Nt*M
                rng(3+it); 
                % rng(5); 
        for k=1:Kcluster
            CHsloc=[CHsloc [x(:,k);y(:,k);0]];
        end
        dCS=[]; 
        for k=1:Kcluster
            dCS=[dCS sqrt(sum((sinkloc-CHsloc(:,k)).^2))];%sink到CHs距离Nt*1
        end
        dCI=[];
        for k=1:Kcluster
            dCI=[dCI sqrt(sum((CHsloc(:,k)-IRSloc).^2))]; %CHs到IRS距离M*1
        end
        g=sqrt(C0*((dIS/D0).^(-alpha_SI)))*(sqrt(beta_SI/(beta_SI+1))*ones(Nt,M)+sqrt(1/(beta_SI+1))*(sqrt(1/2)*(randn(Nt,M)+1j*randn(Nt,M)))); 
        for k=1:Kcluster
            hr_k(:,k)=sqrt(C0.*(((dCI(1,k))./D0).^(-alpha_IC)))*(sqrt(beta_IC/(beta_IC+1))*ones(M,1)+sqrt(1/(beta_IC+1))*(sqrt(1/2)*(randn(M,1)+1j*randn(M,1)))); %上行CH到IRS信道M*1
        end
        for k=1:Kcluster
            hd_k(:,k)=sqrt(C0.*((dCS(:,k)./D0).^(-alpha_SC)))*(sqrt(beta_SC/(beta_SC+1))*ones(Nt,1)+sqrt(1/(beta_SC+1))*(sqrt(1/2)*(randn(Nt,1)+1j*randn(Nt,1)))); %上行CH到sink信道Nt*1
        end
%         g=(sqrt(C0*((dIS/D0).^(-alpha_SI))).*exp(-1j*((2*pi/lamuda)*dIS)))*ones(Nt,M); 
%         for k=1:Kcluster
%             hr_k(:,k)=(sqrt(C0.*(((dCI(1,k))./D0).^(-alpha_IC))).*exp(-1j.*((2*pi/lamuda).*(dCI(1,k)))))*ones(M,1); %上行CH到IRS信道M*1
%         end
%         for k=1:Kcluster
%             hd_k(:,k)=(sqrt(C0.*((dCS(:,k)./D0).^(-alpha_SC))).*exp(-1j.*((2*pi/lamuda).*(dCS(:,k)))))*ones(Nt,1); %上行CH到sink信道Nt*1
%         end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%上行信道构建完毕，开始构建下行信道%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        CRSNsloc=[];
        for n=1:N
            CRSNsloc=[CRSNsloc [x1(:,n);y1(:,n);0]];
        end
        dSC=[];
        for n=1:N
            dSC=[dSC sqrt(sum((CRSNsloc(:,n)-sinkloc).^2))];%sink到CRSNs距离Nt*1
        end
        dIC=[];
        for n=1:N
            dIC=[dIC sqrt(sum((CRSNsloc(:,n)-IRSloc).^2))]; %IRS到CRSNs距离1*M
        end
        for n=1:N
            hr_n(:,n)=sqrt(C0.*(((dIC(1,n))./D0).^(-alpha_IC)))*(sqrt(beta_IC/(beta_IC+1))*ones(M,1)+sqrt(1/(beta_IC+1))*(sqrt(1/2)*(randn(M,1)+1j*randn(M,1)))); %hr,n维度M*1
        end
        for n=1:N
            hd_n(:,n)=sqrt(C0.*((dSC(1,n)./D0).^(-alpha_SC)))*(sqrt(beta_SC/(beta_SC+1))*ones(Nt,1)+sqrt(1/(beta_SC+1))*(sqrt(1/2)*(randn(Nt,1)+1j*randn(Nt,1))));
        end
%         for n=1:N
%             hr_n(:,n)=(sqrt(C0.*(((dIC(1,n))./D0).^(-alpha_IC))).*exp(-1j.*((2*pi/lamuda).*(dIC(1,n)))))*ones(M,1); %hr,n维度M*1
%         end
%         for n=1:N
%             hd_n(:,n)=(sqrt(C0.*((dSC(1,n)./D0).^(-alpha_SC))).*exp(-1j.*((2*pi/lamuda).*(dSC(1,n)))))*ones(Nt,1);
%         end
hd_n_2=hd_n;
        hr_n_2=hr_n;
        hd_n_1=hd_n;
        hr_n_1=hr_n;
        hd_k_1=hd_k;
        hr_k_1=hr_k;
        g_1=g;
        g_2=g;



% % 
%         for it=1:5 %跑100次取平均值 it=1:100  4:10 6:10
% 
% 
%      weizhi_2=[];
% %     Eee=[];
% %     Etotal=[];
% %     Eeh=[];
% 
% 
% 
% 
% 
% ioi=0;
% opp=[0.1:0.1:4];
% weizhi=[];
%      yIRS=2.1   %IRS:(0,yIRS,dv)-50:0.1:50  2.1
%    for ioi=1:1
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%至此所有信道构建完毕%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %交替优化算法
        %固定波束赋形优化反射因子矩阵
          % rng(10);
        w0c=randn(Nt,1)+1j.*randn(Nt,1);%随机生成发射波束向量
        w0_mo=sqrt(sum((abs(w0c)).^2));
        w0=w0c./w0_mo;%单位化  w0_为固定波束赋形优化反射因子矩阵的波束赋形向量，即交替优化算法的初始迭代点 Nt*1
        wk0=[];
        for k=1:Kcluster
            wkc=randn(Nt,1)+1j.*randn(Nt,1);%随机生成发射波束向量
            wk_mo=sqrt(sum((abs(wkc)).^2));
            wk_1=wkc./wk_mo;%单位化
            wk0=[wk0 wk_1];  %wk_为固定波束赋形优化反射因子矩阵的波束赋形向量，即交替优化算法的初始迭代点 Nt*1
        end
        wk=wk0;
        EE_old=0;
        EE=10;
        AO=[];
         AO1=[];
          AO2=[];




%         for it=1:5 %跑100次取平均值 it=1:100  4:10 6:10
% 
% 
%      weizhi_2=[];
% %     Eee=[];
% %     Etotal=[];
% %     Eeh=[];
% 
% 
% 
% 
% 
% ioi=0;
% opp=[0.1:0.1:4];
% weizhi=[];
%      yIRS=2.1   %IRS:(0,yIRS,dv)-50:0.1:50  2.1
%    for ioi=1:1

%         for Iao=1:50
%             Iao
%         if (abs((EE_old-EE)/EE)>epsilon)
        count=0;
        HH1_10=[];
        EEe1_10=[];
        Ex_10=[];
        EE1_10=[];

ak_=[];
 % rng(2024);
        for k=1:Kcluster
            ak1=ones(M,1);
            ak_=[ak_ ak1];  %ak_为原文的ak_q-1，即SCA算法的初始迭代点 K个M*1
        end
        phi0_=unifrnd(0,2*pi,M,1);
v0_=cos(phi0_)+sin(phi0_)*1j;

SS1=[];

% for it=1:5 %跑100次取平均值 it=1:100  4:10 6:10
% 
% 
%      weizhi_2=[];
% %     Eee=[];
% %     Etotal=[];
% %     Eeh=[];
% 
% 
% 
% 
% 
% ioi=0;
% opp=[0.1:0.1:4];
% weizhi=[];
%      yIRS=2.1   %IRS:(0,yIRS,dv)-50:0.1:50  2.1
%    for ioi=1:1
   % count=0;
   %      HH1_10=[];
   %      EEe1_10=[];
   %      Ex_10=[];
   %      EE1_10=[];


        while (abs((EE_old-EE)/EE)>epsilon && count < maxIter)
        
      % while  count < maxIter
     % while  count < 1
            count = count + 1;
            count

          
        %SCA优化方法，得到上界
        % [ak_, v0_, ak, v0, theta] = SCA_solving(hr_k, g, hd_k, hr_n, hd_n, M, Kcluster, N, SNR, PS, Pirs, pout, derta1_2, derta2_2, derta3n_2, w0, wk, Edt, t1, t0, yita, ak_, v0_);
       
        
              for k=1:Kcluster
            theta(:,k)=mod((angle((wk(:,k))'*hd_k(:,k))*ones(M,1)-angle(diag((wk(:,k))'*g)*hr_k(:,k))),2*pi);%IRS最优相位 M*1
        end
        % ak_=[];
        % for k=1:Kcluster
        %     ak1=ones(M,1);
        %     ak_=[ak_ ak1];  %ak_为原文的ak_q-1，即SCA算法的初始迭代点 K个M*1
        % end
        % phi0_=unifrnd(0,2*pi,M,1);
        %  v0_=cos(phi0_)+sin(phi0_)*1j;  %v0_为原文的v0_q-1，即SCA算法的初始迭代点 M*1
        w01=(norm(w0))^2;  %w01为原文的w0_，即||w0||^2
        wk1=[];
        for k=1:Kcluster
            wk11=(norm(wk(:,k)))^2;  
            wk1=[wk1 wk11];  %wk1为原文的wk_，即||wk||^2
        end
        Eeh=t0*(PS*w01+M*Pirs); 
        g_=[];
        for k=1:Kcluster
            g_=[g_ ; (wk(:,k))'*g];  %1*M
            G(:,:,k)=diag((abs(g_(k,:))).^2);  %M*M
            bk(:,k)=diag((hr_k(:,k))')*(g_(k,:))';  %M*1
            Hr_k(:,:,k)=diag((abs(hr_k(:,k))).^2);  %M*M
            hdk_(:,k)=(wk(:,k))'*hd_k(:,k);   %1*1
        end
        g0_=(w0)'*g;  %1*M
        G0=PS*diag((abs(g0_)).^2)+derta1_2*eye(M);   %M*M
        for n=1:N
            hdn_(:,n)=(w0)'*(hd_n(:,n));  %1*1
            bn(:,n)=diag((hr_n(:,n))')*(g0_)';  %M*1
            Hr_n(:,:,n)=diag((abs(hr_n(:,n))).^2);  %M*M
        end
        Sh=0;
        for n=1:N
            Sh1(:,:,n)=bn(:,n)*(bn(:,n))';
            Sh=Sh+Sh1(:,:,n);
        end
        SH=PS*Sh;
        PAI=0;
        for n=1:N
            PAI=PAI+Hr_n(:,:,n);
        end
        PA=derta1_2*PAI;
        Xi=0;
        for n=1:N
            Xi1(:,n)=bn(:,n)*hdn_(:,n);
            Xi=Xi+Xi1(:,n);
        end
        XI=PS*Xi;
        HD1=0;
        for n=1:N
            HD1=HD1+(abs(hdn_(:,n)))^2;
        end
        HD=PS*HD1;
        ZAO=0;
        for n=1:N
            ZAO=ZAO+derta3n_2;
        end
        for k=1:Kcluster
            tk_(:,k)=(derta1_2*((ak_(:,k)).'*G(:,:,k)*ak_(:,k))+derta2_2*wk1(:,k))/((abs(abs(hdk_(:,k))+abs((bk(:,k))')*ak_(:,k)))^2);
            uk_(:,k)=tk_(:,k)*((ak_(:,k)).'*Hr_k(:,:,k)*ak_(:,k));
        end
        A11=[];
        B11=[];
        for k=1:Kcluster
            A11=[A11 (t1*(((derta1_2*((ak_(:,k)).'*G(:,:,k)*ak_(:,k))+derta2_2*wk1(:,k))/((abs(abs(hdk_(:,k))+abs((bk(:,k))')*ak_(:,k)))^2))*SNR+...
                ((derta1_2*((ak_(:,k)).'*G(:,:,k)*ak_(:,k))+derta2_2*wk1(:,k))/((abs(abs(hdk_(:,k))+abs((bk(:,k))')*ak_(:,k)))^2))*SNR*((ak_(:,k)).'*Hr_k(:,:,k)*ak_(:,k))+...
                derta1_2*((ak_(:,k)).'*eye(M)*ak_(:,k))+M*Pirs))];
        end
        A_=sum(A11(1:Kcluster));
        for n=1:N
            B11=[B11 (PS*(abs(hdn_(:,n)+(bn(:,n))'*v0_))^2+derta1_2*(v0_'*Hr_n(:,:,n)*v0_)+derta3n_2)];
        end
        B_=sum(B11(1:N));

        % SS_=A_+Edt+Eeh+t0*(v0_'*G0*v0_)-t0*yita*B_;
SS_=10000000;
        SSS=[];
  for k=1:Kcluster
        Ak_(:,k)=10;
  end
        for Isca=1:30 %1:100  quiet
  %           for k=1:Kcluster
  %       Ak_(:,k)=60;
  % end
%             ak=[];
%             max_retries=5;
%             retries=0;
%             while retries<max_retries
%                 retries=retries+1;
                cvx_begin 
cvx_solver mosek
                variable ak(M,Kcluster);
                variable v0(M,1) complex;
                variable tk(1,Kcluster);
                variable uk(1,Kcluster);
                variable zk(1,Kcluster);
                expression A;
                A=[];
                for k=1:Kcluster
                    A=[A (t1*(tk(:,k)*SNR+SNR*uk(:,k)+derta1_2*((ak(:,k)).'*eye(M)*ak(:,k))+M*Pirs))];
                end
                %                 A1=sum(A(1:K));
                %                 minimize real(square_pos(norm((v0'*G0), 2)))   %二范数求模求平方用square_pos(norm(x, 2))：||x||^2
                minimize real(sum(A(1:Kcluster))+t0*(v0'*G0*v0)-t0*yita*real(2*real(v0'*(SH*v0_+XI+PA*v0_))-(v0_)'*SH*v0_-(v0_)'*PA*v0_+HD+ZAO))
                %                 minimize real(sum(A(1:Kcluster))-t0*yita*real(2*real(v0'*(SH*v0_+XI+PA*v0_))-(v0_)'*SH*v0_-(v0_)'*PA*v0_+HD+ZAO))
                %%%                 maximize real(t0*yita*real(B1)-A1-Edt-t0*(Eeh+v0'*G0*v0))
                subject to



                % for k=1:Kcluster
                %     (10^13)*(derta1_2*((ak(:,k)).'*G(:,:,k)*ak(:,k))+derta2_2*wk1(:,k))<=(10^13)*(tk_(:,k)*(abs(abs(hdk_(:,k))+abs((bk(:,k))')*ak_(:,k)))^2+...
                %         (abs(abs(hdk_(:,k))+abs((bk(:,k))')*ak_(:,k)))^2*(tk(:,k)-tk_(:,k))+...
                %         tk_(:,k)*2*real((ak_(:,k)).'*abs(bk(:,k))*abs((bk(:,k))')+abs((hdk_(:,k))')*abs((bk(:,k))'))*(ak(:,k)-ak_(:,k)));
                %     SNR*uk(:,k)+derta1_2*((ak(:,k)).'*eye(M)*ak(:,k))<=pout;
                %     ((ak(:,k)).'*Hr_k(:,:,k)*ak(:,k))<=(uk_(:,k))/(tk_(:,k))+(uk(:,k)-uk_(:,k))/(tk_(:,k))-((uk_(:,k))/(tk_(:,k))^2)*(tk(:,k)-tk_(:,k));
                %     tk(:,k)>=0;
                %     uk(:,k)>=0;
                % end


  for k=1:Kcluster

      L100 = chol(G(:,:,k), 'lower');
vec = [ sqrt(derta1_2) * (L100' * ak(:,k)); sqrt(derta2_2*wk1(:,k)) ];


    % (10^13)*(derta1_2*((ak(:,k)).'*G(:,:,k)*ak(:,k))+derta2_2*wk1(:,k))<=(10^13)*(tk_(:,k)*(abs(abs(hdk_(:,k))+abs((bk(:,k))')*ak_(:,k)))^2+...
    %                     (abs(abs(hdk_(:,k))+abs((bk(:,k))')*ak_(:,k)))^2*(tk(:,k)-tk_(:,k))+...
    %                     tk_(:,k)*2*real((ak_(:,k)).'*abs(bk(:,k))*abs((bk(:,k))')+abs((hdk_(:,k))')*abs((bk(:,k))'))*(ak(:,k)-ak_(:,k)));
                   (10^5)* quad_over_lin(vec, tk(:,k))<=(10^5)*((abs(abs(hdk_(:,k))+abs((bk(:,k))')*ak_(:,k)))^2+...
                       2*real((ak_(:,k)).'*abs(bk(:,k))*abs((bk(:,k))')+abs((hdk_(:,k))')*abs((bk(:,k))'))*(ak(:,k)-ak_(:,k)));
                    SNR*uk(:,k)+derta1_2*((ak(:,k)).'*eye(M)*ak(:,k))<=pout;
                    % ((ak(:,k)).'*Hr_k(:,:,k)*ak(:,k))<=(uk_(:,k))/(tk_(:,k))+(uk(:,k)-uk_(:,k))/(tk_(:,k))-((uk_(:,k))/(tk_(:,k))^2)*(tk(:,k)-tk_(:,k));
                     ((ak(:,k)).'*Hr_k(:,:,k)*ak(:,k))<=zk(:,k);
                     % zk(:,k)<=(uk_(:,k))/(tk_(:,k))+(uk(:,k)-uk_(:,k))/(tk_(:,k))-((uk_(:,k))/(tk_(:,k))^2)*(tk(:,k)-tk_(:,k));
                    tk(:,k)>=0;
                    uk(:,k)>=0;
                     zk(:,k)>=0;
  (1/2)*(Ak_(:,k)* (tk(:,k)^2)+(zk(:,k)^2)/Ak_(:,k))<= uk(:,k);

                end


                real(v0'*G0*v0)<=pout;
                for k=1:Kcluster
                    for m=1:M
                        ak(m,k)>=1;
                    end
                end
                for m=1:M
                    2*real((v0(m))'*v0_(m))-(v0_(m))'*v0_(m)>=1;
                end
                cvx_end
                 for k=1:Kcluster
        Ak_(:,k)=zk(:,k)/tk(:,k);
  end
%                 if strcmp(cvx_status,'Solved')
%                     break
%                 else
%                     fprintf('第%d次求解失败。\n',retries);
%                     w0c=randn(Nt,1)+1j.*randn(Nt,1);%随机生成发射波束向量
%                     w0_mo=sqrt(sum((abs(w0c)).^2));
%                     w0=w0c./w0_mo;%单位化  w0_为固定波束赋形优化反射因子矩阵的波束赋形向量，即交替优化算法的初始迭代点 Nt*1
%                     wk0=[];
%                     for k=1:Kcluster
%                         wkc=randn(Nt,1)+1j.*randn(Nt,1);%随机生成发射波束向量
%                         wk_mo=sqrt(sum((abs(wkc)).^2));
%                         wk_1=wkc./wk_mo;%单位化
%                         wk0=[wk0 wk_1];  %wk_为固定波束赋形优化反射因子矩阵的波束赋形向量，即交替优化算法的初始迭代点 Nt*1
%                     end
%                     wk=wk0;
%                     for k=1:Kcluster
%                         theta(:,k)=mod((angle((wk(:,k))'*hd_k(:,k))*ones(M,1)-angle(diag((wk(:,k))'*g)*hr_k(:,k))),2*pi);%IRS最优相位 M*1
%                     end
%                     ak_=[];
%                     for k=1:Kcluster
%                         ak1=ones(M,1);
%                         ak_=[ak_ ak1];  %ak_为原文的ak_q-1，即SCA算法的初始迭代点 K个M*1
%                     end
%                     phi0_=unifrnd(0,2*pi,M,1);
%                     v0_=cos(phi0_)+sin(phi0_)*1j;  %v0_为原文的v0_q-1，即SCA算法的初始迭代点 M*1
%                     w01=(norm(w0))^2;  %w01为原文的w0_，即||w0||^2
%                     wk1=[];
%                     for k=1:Kcluster
%                         wk11=(norm(wk(:,k)))^2;
%                         wk1=[wk1 wk11];  %wk1为原文的wk_，即||wk||^2
%                     end
%                     Eeh=t0*(PS*w01+M*Pirs);
%                     g_=[];
%                     for k=1:Kcluster
%                         g_=[g_ ; (wk(:,k))'*g];  %1*M
%                         G(:,:,k)=diag((abs(g_(k,:))).^2);  %M*M
%                         bk(:,k)=diag((hr_k(:,k))')*(g_(k,:))';  %M*1
%                         Hr_k(:,:,k)=diag((abs(hr_k(:,k))).^2);  %M*M
%                         hdk_(:,k)=(wk(:,k))'*hd_k(:,k);   %1*1
%                     end
%                     g0_=(w0)'*g;  %1*M
%                     G0=PS*diag((abs(g0_)).^2)+derta1_2*eye(M);   %M*M
%                     for n=1:N
%                         hdn_(:,n)=(w0)'*(hd_n(:,n));  %1*1
%                         bn(:,n)=diag((hr_n(:,n))')*(g0_)';  %M*1
%                         Hr_n(:,:,n)=diag((abs(hr_n(:,n))).^2);  %M*M
%                     end
%                     Sh=0;
%                     for n=1:N
%                         Sh1(:,:,n)=bn(:,n)*(bn(:,n))';
%                         Sh=Sh+Sh1(:,:,n);
%                     end
%                     SH=PS*Sh;
%                     PAI=0;
%                     for n=1:N
%                         PAI=PAI+Hr_n(:,:,n);
%                     end
%                     PA=derta1_2*PAI;
%                     Xi=0;
%                     for n=1:N
%                         Xi1(:,n)=bn(:,n)*hdn_(:,n);
%                         Xi=Xi+Xi1(:,n);
%                     end
%                     XI=PS*Xi;
%                     HD1=0;
%                     for n=1:N
%                         HD1=HD1+(abs(hdn_(:,n)))^2;
%                     end
%                     HD=PS*HD1;
%                     ZAO=0;
%                     for n=1:N
%                         ZAO=ZAO+derta3n_2;
%                     end
%                     for k=1:Kcluster
%                         tk_(:,k)=(derta1_2*((ak_(:,k)).'*G(:,:,k)*ak_(:,k))+derta2_2*wk1(:,k))/((abs(abs(hdk_(:,k))+abs((bk(:,k))')*ak_(:,k)))^2);
%                         uk_(:,k)=tk_(:,k)*((ak_(:,k)).'*Hr_k(:,:,k)*ak_(:,k));
%                     end
%                     A11=[];
%                     B11=[];
%                     for k=1:Kcluster
%                         A11=[A11 (t1*(((derta1_2*((ak_(:,k)).'*G(:,:,k)*ak_(:,k))+derta2_2*wk1(:,k))/((abs(abs(hdk_(:,k))+abs((bk(:,k))')*ak_(:,k)))^2))*SNR+...
%                             ((derta1_2*((ak_(:,k)).'*G(:,:,k)*ak_(:,k))+derta2_2*wk1(:,k))/((abs(abs(hdk_(:,k))+abs((bk(:,k))')*ak_(:,k)))^2))*SNR*((ak_(:,k)).'*Hr_k(:,:,k)*ak_(:,k))+...
%                             derta1_2*((ak_(:,k)).'*eye(M)*ak_(:,k))+M*Pirs))];
%                     end
%                     A_=sum(A11(1:Kcluster));
%                     for n=1:N
%                         B11=[B11 (PS*(abs(hdn_(:,n)+(bn(:,n))'*v0_))^2+derta1_2*(v0_'*Hr_n(:,:,n)*v0_)+derta3n_2)];
%                     end
%                     B_=sum(B11(1:N));
%                     SS_=A_+Edt+Eeh+t0*(v0_'*G0*v0_)-t0*yita*B_;
%                     SSS=[];
%                 end
%             end
            ASS1=[];
            for k=1:Kcluster
                ASS1=[ASS1 (t1*(((derta1_2*((ak(:,k)).'*G(:,:,k)*ak(:,k))+derta2_2*wk1(:,k))/((abs(abs(hdk_(:,k))+abs((bk(:,k))')*ak(:,k)))^2))*SNR+...
                    ((derta1_2*((ak(:,k)).'*G(:,:,k)*ak(:,k))+derta2_2*wk1(:,k))/((abs(abs(hdk_(:,k))+abs((bk(:,k))')*ak(:,k)))^2))*SNR*((ak(:,k)).'*Hr_k(:,:,k)*ak(:,k))+...
                    derta1_2*((ak(:,k)).'*eye(M)*ak(:,k))+M*Pirs))];
            end
            ASS=sum(ASS1(1:Kcluster));
            BSS1=[];
            for n=1:N
                BSS1=[BSS1 ((PS*(abs(hdn_(:,n)+(bn(:,n))'*v0))^2+derta1_2*(v0'*Hr_n(:,:,n)*v0))+derta3n_2)];
            end
            BSS=sum(BSS1(1:N));
            SS=ASS+Edt+Eeh+t0*(v0'*G0*v0)-t0*yita*BSS;
            %             SS=ASS+Edt+Eeh-t0*yita*BSS;
            %             if mean(abs((SS-SS_)/SS_))<1e-7 %1e-8
            if mean(abs(SS-SS_))<1e-3 %1e-8
                break
            else
                v0_=v0;
                SS_=SS;
                for k=1:Kcluster
                    ak_(:,k)=ak(:,k);
                    tk_(:,k)=(derta1_2*((ak_(:,k)).'*G(:,:,k)*ak_(:,k))+derta2_2*wk1(:,k))/((abs(abs(hdk_(:,k))+abs((bk(:,k))')*ak_(:,k)))^2);
                    uk_(:,k)=tk_(:,k)*((ak_(:,k)).'*Hr_k(:,:,k)*ak_(:,k));
                end
            end
            SSS=[SSS SS];
        end
        
        

SS1(count)=SS;

        
        for k=1:Kcluster
            vk(:,k)=ak(:,k).*exp(1j.*theta(:,k));
            phik(:,:,k)=diag((vk(:,k)).');
        end
        phi0=diag((v0)');
        %SDR优化波束赋形
 %%%%%%%%%%%%%%%%%%%%       %%%%%%%%%^^5%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        p2_juzhen=[];
for k=1:Kcluster
            hk(:,k)=hd_k(:,k)+g*phik(:,:,k)*hr_k(:,k);  %Nt*1
            Gk(:,:,k)=g*phik(:,:,k);   %Nt*M
            hrk(:,k)=(norm(phik(:,:,k)*hr_k(:,k)))^2;   %1*1
            Ik(:,k)=derta1_2*(norm(phik(:,:,k)*eye(M)))^2;   %1*1
        end
        G1=phi0*g';  %M*Nt
        I0=derta1_2*(norm(phi0*eye(M)))^2;  %1*1
        for n=1:N
            hrn(:,n)=derta1_2*(norm((hr_n(:,n))'*phi0))^2;  %1*1
        end
        hn=[];
        for n=1:N
            hn=[hn ; ((hd_n(:,n))'+(hr_n(:,n))'*phi0*g')];  %1*Nt
        end
       
        for k=1:Kcluster
            Ak(:,:,k)=derta1_2*(Gk(:,:,k)*(Gk(:,:,k))')+derta2_2*eye(Nt);
            Hk(:,:,k)=hk(:,k)*(hk(:,k))';
        end
        C1=0;
        for n=1:N
            Cn1(:,:,n)=PS*((hn(n,:))'*hn(n,:));
            C1=C1+Cn1(:,:,n);
        end
        C=t0*yita*C1;
        HZ1=0;
        for n=1:N
            Hz1(:,n)=hrn(:,n)+derta3n_2;
            HZ1=HZ1+Hz1(:,n);
        end
        HZ=t0*yita*HZ1;
        BB=PS*(G1'*G1);  %BB为原文的B 

      EE_old=EE;
        EE1=[];
%         Ef=[];%%%%%%%%%%%%%
%         Efuzhu=[];%%%%%%%%%%%%%%%%%%%%
%         Efangda=[];%%%%%%%%%%%%


% hd_k=hd_k_1-sqrt(xindaopiancha)*abs(hd_k).*(sqrt(1/2)*(randn(Nt,Kcluster)+1j*randn(Nt,Kcluster)));
        % hr_k= hr_k_1-sqrt(xindaopiancha)*abs(hr_k).*(sqrt(1/2)*(randn(M,Kcluster)+1j*randn(M,Kcluster)));
        % sqrt(C0.*(((dIC(1,n))./D0).^(-alpha_IC)))*(sqrt(beta_IC/(beta_IC+1))*ones(M,1)+sqrt(1/(beta_IC+1))
 % 
%  r_4 = abs(hd_k-sqrt(C0.*((dCS(:,k)./D0).^(-alpha_SC)))*(sqrt(beta_IC/(beta_IC+1))*ones(Nt,Kcluster)));
%  theta_4 = angle(hd_k-sqrt(C0.*((dCS(:,k)./D0).^(-alpha_SC)))*(sqrt(beta_IC/(beta_IC+1))*ones(Nt,Kcluster)));
%  r_5 = abs(hr_k-sqrt(C0.*(((dCI(1,k))./D0).^(-alpha_IC)))*(sqrt(beta_IC/(beta_IC+1))*ones(M,Kcluster)));
%  theta_5 = angle(hr_k-sqrt(C0.*(((dCI(1,k))./D0).^(-alpha_IC)))*(sqrt(beta_IC/(beta_IC+1))*ones(M,Kcluster)));
%     hd_k=sqrt(C0.*((dCS(:,k)./D0).^(-alpha_SC)))*(sqrt(beta_IC/(beta_IC+1))*ones(Nt,Kcluster))+r_4.*exp(1i.*theta_4).*exp(1i.*rand(Nt,Kcluster) * 2*xindaopiancha*pi);
%    hr_k=sqrt(C0.*(((dCI(1,k))./D0).^(-alpha_IC)))*(sqrt(beta_IC/(beta_IC+1))*ones(M,Kcluster))+r_5.*exp(1i.*theta_5).*exp(1i.*rand(M,Kcluster) * 2*xindaopiancha*pi);
% r_3 = abs(g);
% theta_3 = angle(g);
% g=r_3.*exp(1i.*theta_3).*exp(1i.*rand(Nt,M) * 2*xindaopiancha*pi);
       % for k=1:Kcluster
       %      hr_k(:,k)=hr_k(:,k)-sqrt(xindaopiancha)*sqrt(C0.*(((dCI(1,k))./D0).^(-alpha_IC)))*sqrt((beta_IC+1)/(beta_IC+1))*(sqrt(1/2)*(randn(M,1)+1j*randn(M,1))); %上行CH到IRS信道M*1
       %  end
       %  for k=1:Kcluster
       %      hd_k(:,k)=hd_k(:,k)-sqrt(xindaopiancha)*sqrt(C0.*((dCS(:,k)./D0).^(-alpha_SC)))*sqrt((beta_IC+1)/(beta_IC+1))*(sqrt(1/2)*(randn(Nt,1)+1j*randn(Nt,1))); %上行CH到sink信道Nt*1
       %  end


        for k=1:Kcluster
            EE1=[EE1 (t1*(((derta1_2*(norm((wk(:,k))'*g*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k(:,k)+g*phik(:,:,k)*hr_k(:,k))))^2))*SNR+...
                ((derta1_2*(norm((wk(:,k))'*g*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k(:,k)+g*phik(:,:,k)*hr_k(:,k))))^2))*SNR*(norm(phik(:,:,k)*hr_k(:,k)))^2+...
                derta1_2*(norm(phik(:,:,k)*eye(M)))^2+M*Pirs)+(Eelec+EDA)*L)]; %Eelec*L是电子电路能耗，EDA*L是CHk聚合自身的能耗。
%             Ef=[Ef (t1*((derta2_2*(norm(wk(:,k)))^2)/(abs((wk(:,k))'*hd_k(:,k)))^2)*SNR)];%%%%%%%%%%%%%%%%%
%             Efuzhu=[Efuzhu (t1*(((derta1_2*(norm((wk(:,k))'*g*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k(:,k)+g*phik(:,:,k)*hr_k(:,k))))^2))*SNR))];%%%%%%%%%%%%%%%%
%             Efangda=[Efangda (t1*(((derta1_2*(norm((wk(:,k))'*g*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k(:,k)+g*phik(:,:,k)*hr_k(:,k))))^2))*SNR*(norm(phik(:,:,k)*hr_k(:,k)))^2+...
%                 derta1_2*(norm(phik(:,:,k)*eye(M)))^2))];%%%%%%%%%%%%%%%
        end
        EE1_10(count,:)=EE1
        EE2=sum(EE1(1:Kcluster));
%         Ef2=sum(Ef(1:Kcluster));%%%%%%%%%%%%%%%%%
%         Efuzhu2=sum(Efuzhu(1:Kcluster));%%%%%%%%%%%%%%%%%
%         Efangda2=sum(Efangda(1:Kcluster));%%%%%%%%%%%%%%%%%
%         Ezuocha=Ef2-Efuzhu2;%%%%%%%%%%%%%
        Etotal_=EE2+Esink+ECM+ECH_intra+t0*(PS*(norm(w0))^2+M*Pirs+PS*(norm(phi0*g'*w0))^2+derta1_2*(norm(phi0*eye(M)))^2);
        Ex1=t0*(PS*(norm(w0))^2+M*Pirs+PS*(norm(phi0*g'*w0))^2+derta1_2*(norm(phi0*eye(M)))^2);
        HH1=[];

%  hd_n=hd_n_1-sqrt(xindaopiancha)*abs(hd_n).*(sqrt(1/2)*(randn(Nt,N)+1j*randn(Nt,N)));
% hr_n=hr_n_1-sqrt(xindaopiancha)*abs(hr_n).*(sqrt(1/2)*(randn(M,N)+1j*randn(M,N)));


% r_1 = abs(hd_n);
% theta_1 = angle(hd_n);
% r_2 = abs(hr_n);
% theta_2 = angle(hr_n);
%  hd_n=r_1.*exp(1i.*theta_1).*exp(1i.*rand(Nt, N) * 2*xindaopiancha*pi);
%   hr_n=r_2.*exp(1i.*theta_2).*exp(1i.*rand(M, N) * 2*xindaopiancha*pi);

% for n=1:N
%             hr_n(:,n)=hr_n(:,n)-sqrt(xindaopiancha)*sqrt(C0.*(((dIC(1,n))./D0).^(-alpha_IC)))*sqrt((beta_IC+1)/(beta_IC+1))*(sqrt(1/2)*(randn(M,1)+1j*randn(M,1))); %hr,n维度M*1
%         end
%         for n=1:N
%             hd_n(:,n)=hd_n(:,n)-sqrt(xindaopiancha)*sqrt(C0.*((dSC(1,n)./D0).^(-alpha_SC)))*sqrt((beta_IC+1)/(beta_IC+1))*(sqrt(1/2)*(randn(Nt,1)+1j*randn(Nt,1)));
%         end


% g=g_1-sqrt(xindaopiancha)*sqrt(C0*((dIS/D0).^(-alpha_SI)))*sqrt(1/(beta_SI+1))*(sqrt(1/2)*(randn(Nt,M)+1j*randn(Nt,M))); 
EEe1=[];
        for n=1:N
            HH1=[HH1 (PS*(abs(((hd_n(:,n))'+(hr_n(:,n))'*phi0*g')*w0)).^2+derta1_2*(norm((hr_n(:,n))'*phi0))^2+derta3n_2)];
        end
        HH1_10(count,:)=t0*yita*HH1;
          % HH1_10=  t0*yita*HH1_10
        HH2=sum(HH1(1:N));
        for k=1:Kcluster
            EEe1=[EEe1 (t1*((derta1_2*(norm((wk(:,k))'*g*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k(:,k)+g*phik(:,:,k)*hr_k(:,k))))^2))*SNR)];
        end
        EEe1_10(count,:)=EEe1;
        Eharvesting_=t0*yita*HH2;
        EE=Rtotal/(Etotal_-Eharvesting_);
        Ex=Ex1-Eharvesting_;
        Ex_10(count,:)=Ex;
%         HHm=t0*yita*HH1;
        AO=[AO EE]; %看交替优化收敛性
        AO1=[AO1 Etotal_];
        AO2=[AO2 Eharvesting_];





         cvx_begin 
        cvx_solver mosek
        variable Wk1(Nt,Nt,Kcluster) hermitian semidefinite;%此处的Wk1是原文的Wk~,即pk*Wk,非负常数乘以半正定阵仍是半正定的
        variable W0(Nt,Nt) hermitian semidefinite;
        variable pk(1,Kcluster);
        expression Y;
        Y=[];
        for k=1:Kcluster
            Y=[Y (t1*((trace(Ak(:,:,k)*Wk1(:,:,k)))*SNR+(trace(Ak(:,:,k)*Wk1(:,:,k)))*SNR*hrk(:,k)+Ik(:,k)+M*Pirs))];
        end
        %             Y1=sum(Y(1:K));
        %             minimize real(Y1+Edt+t0*(PS*trace(W0)+M*PIRS+trace(BB*W0)+I0)-t0*yita*Z1);
        maximize real(trace(C*W0)+HZ-sum(Y(1:Kcluster))-Edt-t0*(PS*trace(W0)+M*Pirs+trace(BB*W0)+I0));
        %             maximize real(trace(C*W0)+HZ-sum(Y(1:Kcluster))-Edt);
        subject to
        for k=1:Kcluster
            real(trace(Hk(:,:,k)*Wk1(:,:,k)))==1;
            real((trace(Ak(:,:,k)*Wk1(:,:,k)))*SNR*hrk(:,k)+Ik(:,k))<=pout;
            real(trace(Wk1(:,:,k)))<=pk(:,k);
            pk(:,k)>=0;
            Wk1(:,:,k)==hermitian_semidefinite(Nt);
        end
        real(trace(BB*W0)+I0)<=pout;
        real(trace(W0))<=1;
        W0==hermitian_semidefinite(Nt);
        cvx_end
        %恢复秩1解
        % 基于惩罚的算法恢复秩1解
        % 参数初始化
        epsilon1 = 1e-3;    % 收敛精度1
        epsilon2 = 1e-3;    % 收敛精度2
        % p1 = p_k(10);  
        p1 = 0.1;
        p2=[]% 惩罚参数1
for ko=1:Kcluster
        % p2(ko) = p_k(10);  
        p2(ko) = 0.1;% 惩罚参数2
end
        max_iter = 100;      % 最大迭代次数

        % 保存第一次CVX求解的结果
        Wk_current = Wk1;
        W0_current = W0;
        pk_current = pk;

        % 主循环 - 基于惩罚的秩1恢复
        iter = 0;
        converged = false;
 iter=0;
 iter2=zeros(100,1);
rank1_violationjuzhen=[];
           p2_juzhen=[];
         while iter < max_iter && ~converged
            rank1_violation = zeros(1, Kcluster);
            iter = iter + 1;
            fprintf('惩罚算法迭代 %d:\n', iter);

            % 检查所有Wk的秩1条件

            for k = 1:Kcluster
                % [V, D] = eig(Wk_current(:,:,k)/pk_current(k));
                [V, D] = eig(Wk_current(:,:,k))
                eigenvals = diag(D);
                max_eigval = max(eigenvals);
                trace_Wk = trace(Wk_current(:,:,k));
                % trace_Wk = trace(Wk_current(:,:,k)/pk_current(k));
                rank1_violation(k) = abs(trace_Wk - max_eigval);
            end
  rank1_violationjuzhen(iter,:)=rank1_violation ;
%             % 如果所有Wk都满足秩1条件，则收敛
            if all(rank1_violation <= epsilon2)
                fprintf('所有Wk满足秩1条件，算法收敛\n');
                converged = true;
                break;
            end

            % 对于不满足秩1条件的k，使用惩罚算法更新
            for k = 1:Kcluster
                if rank1_violation(k) > epsilon2
                    % 获取当前Wk的最大特征向量
                    [V, D] = eig(Wk_current(:,:,k));
                    [max_eigval, max_idx] = max(diag(D));
                    u_max = V(:, max_idx);

                    % 求解带惩罚项的问题(P15)
                    cvx_begin 
                    cvx_solver mosek
                        variable Wk_var(Nt, Nt) hermitian semidefinite;
                        variable pk_var(1);

                        % 惩罚项：tr(Wk) - u_max' * Wk * u_max
                        penalty_term = p2(1,k) * (trace(Wk_var) - real(u_max' * Wk_var * u_max));

                        % 目标函数：原始目标 + 惩罚项
                        objective = t1 * (trace(Ak(:,:,k)*Wk_var)*SNR + ...
                            trace(Ak(:,:,k)*Wk_var)*SNR*hrk(:,k) + ...
                            Ik(:,k) + M*Pirs) + penalty_term;

                        minimize real(objective)
        subject to
                        % 约束条件
                        real(trace(Hk(:,:,k)*Wk_var)) == 1;
                        real((trace(Ak(:,:,k)*Wk_var))*SNR*hrk(:,k) + Ik(:,k)) <= pout;
                        real(trace(Wk_var)) <= pk_var;
                        pk_var >= 0;
                        Wk_var == hermitian_semidefinite(Nt);
                    cvx_end



                   
                    if isnan(trace(Wk_var))
                   Wk_var=Wk_current(:,:,k);
pk_var=pk_current(k);
                 end
                 pk_var1(k)=pk_var;

                    % 检查收敛
                    % if norm(Wk_var/pk_var1(k)- Wk_current(:,:,k)/pk_current(k), 'fro') <= epsilon2
                    if norm(Wk_var- Wk_current(:,:,k), 'fro') <= epsilon2
                    % if norm(Wk_var- Wk_current(:,:,k), 'fro') <= epsilon2
                        p2(1,k) =  2*p2(1,k);  % 增加惩罚参数
                        fprintf('k=%d: 增加惩罚参数 p2=%.2f\n', k, p2);
                    else 
                           % iter = iter + 1;
                           iter2(k,:)=iter2(k,:)+1;
                        Wk_current(:,:,k) = Wk_var;
                        pk_current(k) = pk_var;
                        fprintf('k=%d: 更新Wk, 秩1违反度=%.6f\n', k, rank1_violation(k));
                    end
                end

                 objective2(k)=objective; 
                 sum(objective2)
            end
          
           p2_juzhen(iter,:)=p2;
        end

        % 恢复最终的秩1解
        wk = zeros(Nt, Kcluster);
        w0 = zeros(Nt, 1);

for k = 1:Kcluster
                [V, D] = eig(Wk_current(:,:,k)/pk_current(:,k));
                op{k}=D;
eigenvalues = diag(D);

% 找到最大特征值及其索引
[max_eigval, idx] = max(eigenvalues);

% 提取最大特征值对应的特征向量
 max_eigvec = V(:, idx);

op1{k}=Wk_current(:,:,k)/pk_current(:,k)-max_eigval*max_eigvec *max_eigvec';

 wk(:,k) = sqrt(max_eigval)*max_eigvec;
                end










%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%         
%         % 使用高斯随机化从Wk_current恢复秩1解
%         num_rand = 100;  % 随机化次数
% 
%         for k = 1:Kcluster
%             best_obj = -inf;
%             best_w = zeros(Nt, 1);
% 
%             for rand_iter = 1:num_rand
%                 % 特征值分解
%                 for k = 1:Kcluster
%                 [V, D] = eig(Wk_current(:,:,k)/pk(:,k));
%                 op{k}=D;
% eigenvalues = diag(D);
% 
% % 找到最大特征值及其索引
% [max_eigval, idx] = max(eigenvalues);
% 
% % 提取最大特征值对应的特征向量
%  max_eigvec = V(:, idx);
% 
% op1{k}=Wk_current(:,:,k)/pk(:,k)-max_eigval*max_eigvec *max_eigvec';
% wk(:,k) = sqrt(max_eigval)*max_eigvec;
% 
%                 end
%                 % 生成随机向量
%                 r = randn(Nt, 1) + 1i*randn(Nt, 1);
%                 r = r / norm(r);
% 
%                 % 构造候选解
%                 w_candidate = V * sqrt(D) * r;
%                 w_candidate = w_candidate / norm(w_candidate) * sqrt(pk_current(k));
% 
%                 % 验证可行性
%                 W_candidate = w_candidate * w_candidate';
%                 feasible = true;
% 
%                 % 检查约束
%                 if abs(real(trace(Hk(:,:,k)*W_candidate)) - 1) > 1e-3
%                     feasible = false;
%                 end
% 
%                 if real((trace(Ak(:,:,k)*W_candidate))*SNR*hrk(:,k) + Ik(:,k)) > pout + 1e-3
%                     feasible = false;
%                 end
% 
%                 if norm(w_candidate) > sqrt(pk_current(k)) + 1e-3
%                     feasible = false;
%                 end
% 
%                 % 如果可行，计算目标函数
%                 if feasible
%                     obj_candidate = -real(t1*((trace(Ak(:,:,k)*W_candidate))*SNR + ...
%                         (trace(Ak(:,:,k)*W_candidate))*SNR*hrk(:,k) + ...
%                         Ik(:,k) + M*Pirs));
%                     if obj_candidate > best_obj
%                         best_obj = obj_candidate;
%                         best_w = w_candidate;
%                     end
%                 end
%             end
% 
%             wk(:,k) = best_w; %最终wk
%         end

        % 同样方法恢复w0
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%加上
iter1 = 0;
iter3=zeros(1,1);
rank1_violation_0_juzhen=[];
        converged = false;
while iter1 < max_iter && ~converged
    p1_juzhen=[];
            iter1 = iter1 + 1;
            fprintf('惩罚算法迭代 %d:\n', iter1);

            % 检查所有Wk的秩1条件
            rank1_violation_0 = zeros(1, Kcluster);
            for k = 1:1
                [V0, D10] = eig(W0_current);
                eigenvals0 = diag(D10);
                max_eigval0 = max(eigenvals0);
                trace_W0 = trace(W0_current);
                rank1_violation_0(k) = abs(trace_W0 - max_eigval0);
            end
 rank1_violation_0_juzhen(iter1,:)=rank1_violation_0;
            % 如果所有Wk都满足秩1条件，则收敛
            if all(rank1_violation_0 <= epsilon2)
                fprintf('所有W0满足秩1条件，算法收敛\n');
                converged = true;
                break;
            end

            % 对于不满足秩1条件的k，使用惩罚算法更新
            for k = 1:1
                if rank1_violation_0(k) > epsilon2
                    % 获取当前Wk的最大特征向量
                    [V0, D10] = eig(W0_current);
                    [max_eigval0, max_idx] = max(diag(D10));
                    u_max0 = V0(:, max_idx);

                    % 求解带惩罚项的问题(P15)
                    cvx_begin 
                    cvx_solver mosek
                        variable W0_var(Nt, Nt) hermitian semidefinite;
                        % variable pk_var(1);

                        % 惩罚项：tr(Wk) - u_max' * Wk * u_max
                        penalty_term = p1 * (trace(W0_var) - real(u_max0' * W0_var * u_max0));

                        % 目标函数：原始目标 + 惩罚项
                        objective1 = t0*(PS*trace(W0_var)+M*Pirs+trace(BB*W0_var)+I0)-real(trace(C*W0_var))+ penalty_term;

                        minimize real(objective1);
                       subject to
                        % 约束条件
                        real(trace(BB*W0_var)+I0)<=pout;
        real(trace(W0_var))<=1;
                    cvx_end
% if isnan(trace(W0_var))
%                    W0_var=W0_current;
% % p0_var=pk_current(k);
%                  end
                    % 检查收敛
                    if norm(W0_var - W0_current, 'fro') <= epsilon2
                        p1 = 2 * p1;  % 增加惩罚参数
                        fprintf('k=%d: 增加惩罚参数 p2=%.2f\n', k, p1);
                    else
                        iter3(k,:)=iter3(k,:)+1;
                        W0_current= W0_var;
                        % pk_current(k) = pk_var;
                        fprintf('k=%d: 更新Wk, 秩1违反度=%.6f\n', k, rank1_violation_0(k));
                    end
                end
            end
           
            p1_juzhen(iter1,:)=p1;
        end
%%%%%%%%%%%%%%%%%%%%%%%%
for k = 1:1
                [V2, D2] = eig(W0_current);
                op2{k}=D2;
eigenvalues2 = diag(D2);

% 找到最大特征值及其索引
[max_eigval2, idx] = max(eigenvalues2);

% 提取最大特征值对应的特征向量
 max_eigvec2 = V2(:, idx);

op3{k}=W0_current-max_eigval2*max_eigvec2 *max_eigvec2';
w0(:,k) = sqrt(max_eigval2)*max_eigvec2;

                end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %         [wk, w0] = fenkaiSDR_solving(hr_k, g, hd_k, hr_n, hd_n, M, Nt, phi0, phik, Kcluster, N, SNR, PS, Pirs, pout, derta1_2, derta2_2, derta3n_2, Edt, t1, t0, yita);
      

        %%%%%%%%%%%%%%%%%
        % while (size(w0,1)==1 || size(wk,1)==1)
        %     w0c=randn(Nt,1)+1j.*randn(Nt,1);%随机生成发射波束向量
        %     w0_mo=sqrt(sum((abs(w0c)).^2));
        %     w0=w0c./w0_mo;%单位化  w0_为固定波束赋形优化反射因子矩阵的波束赋形向量，即交替优化算法的初始迭代点 Nt*1
        %     wk0=[];
        %     for k=1:Kcluster
        %         wkc=randn(Nt,1)+1j.*randn(Nt,1);%随机生成发射波束向量
        %         wk_mo=sqrt(sum((abs(wkc)).^2));
        %         wk_1=wkc./wk_mo;%单位化
        %         wk0=[wk0  wk_1];  %wk_为固定波束赋形优化反射因子矩阵的波束赋形向量，即交替优化算法的初始迭代点 Nt*1
        %     end
        %     wk=wk0;
        %     [ak, v0, theta] = SCA_solving(hr_k, g, hd_k, hr_n, hd_n, M, Kcluster, N, SNR, PS, Pirs, pout, derta1_2, derta2_2, derta3n_2, w0, wk, Edt, t1, t0, yita);
        %     for k=1:Kcluster
        %         vk(:,k)=ak(:,k).*exp(1j.*theta(:,k));
        %         phik(:,:,k)=diag((vk(:,k)).');
        %     end
        %     phi0=diag((v0)');
        %     [wk, w0] = SDR_solving(hr_k, g, hd_k, hr_n, hd_n, M, Nt, phi0, phik, Kcluster, N, SNR, PS, Pirs, pout, derta1_2, derta2_2, derta3n_2, Edt, t1, t0, yita);
        % end
       
        
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
        
%         EE_old=EE;
%         EE1=[];
% %         Ef=[];%%%%%%%%%%%%%
% %         Efuzhu=[];%%%%%%%%%%%%%%%%%%%%
% %         Efangda=[];%%%%%%%%%%%%
% 
% 
% % hd_k=hd_k_1-sqrt(xindaopiancha)*abs(hd_k).*(sqrt(1/2)*(randn(Nt,Kcluster)+1j*randn(Nt,Kcluster)));
%         % hr_k= hr_k_1-sqrt(xindaopiancha)*abs(hr_k).*(sqrt(1/2)*(randn(M,Kcluster)+1j*randn(M,Kcluster)));
%         % sqrt(C0.*(((dIC(1,n))./D0).^(-alpha_IC)))*(sqrt(beta_IC/(beta_IC+1))*ones(M,1)+sqrt(1/(beta_IC+1))
%  % 
% %  r_4 = abs(hd_k-sqrt(C0.*((dCS(:,k)./D0).^(-alpha_SC)))*(sqrt(beta_IC/(beta_IC+1))*ones(Nt,Kcluster)));
% %  theta_4 = angle(hd_k-sqrt(C0.*((dCS(:,k)./D0).^(-alpha_SC)))*(sqrt(beta_IC/(beta_IC+1))*ones(Nt,Kcluster)));
% %  r_5 = abs(hr_k-sqrt(C0.*(((dCI(1,k))./D0).^(-alpha_IC)))*(sqrt(beta_IC/(beta_IC+1))*ones(M,Kcluster)));
% %  theta_5 = angle(hr_k-sqrt(C0.*(((dCI(1,k))./D0).^(-alpha_IC)))*(sqrt(beta_IC/(beta_IC+1))*ones(M,Kcluster)));
% %     hd_k=sqrt(C0.*((dCS(:,k)./D0).^(-alpha_SC)))*(sqrt(beta_IC/(beta_IC+1))*ones(Nt,Kcluster))+r_4.*exp(1i.*theta_4).*exp(1i.*rand(Nt,Kcluster) * 2*xindaopiancha*pi);
% %    hr_k=sqrt(C0.*(((dCI(1,k))./D0).^(-alpha_IC)))*(sqrt(beta_IC/(beta_IC+1))*ones(M,Kcluster))+r_5.*exp(1i.*theta_5).*exp(1i.*rand(M,Kcluster) * 2*xindaopiancha*pi);
% % r_3 = abs(g);
% % theta_3 = angle(g);
% % g=r_3.*exp(1i.*theta_3).*exp(1i.*rand(Nt,M) * 2*xindaopiancha*pi);
%        % for k=1:Kcluster
%        %      hr_k(:,k)=hr_k(:,k)-sqrt(xindaopiancha)*sqrt(C0.*(((dCI(1,k))./D0).^(-alpha_IC)))*sqrt((beta_IC+1)/(beta_IC+1))*(sqrt(1/2)*(randn(M,1)+1j*randn(M,1))); %上行CH到IRS信道M*1
%        %  end
%        %  for k=1:Kcluster
%        %      hd_k(:,k)=hd_k(:,k)-sqrt(xindaopiancha)*sqrt(C0.*((dCS(:,k)./D0).^(-alpha_SC)))*sqrt((beta_IC+1)/(beta_IC+1))*(sqrt(1/2)*(randn(Nt,1)+1j*randn(Nt,1))); %上行CH到sink信道Nt*1
%        %  end
% 
% 
%         for k=1:Kcluster
%             EE1=[EE1 (t1*(((derta1_2*(norm((wk(:,k))'*g*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k(:,k)+g*phik(:,:,k)*hr_k(:,k))))^2))*SNR+...
%                 ((derta1_2*(norm((wk(:,k))'*g*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k(:,k)+g*phik(:,:,k)*hr_k(:,k))))^2))*SNR*(norm(phik(:,:,k)*hr_k(:,k)))^2+...
%                 derta1_2*(norm(phik(:,:,k)*eye(M)))^2+M*Pirs)+(Eelec+EDA)*L)]; %Eelec*L是电子电路能耗，EDA*L是CHk聚合自身的能耗。
% %             Ef=[Ef (t1*((derta2_2*(norm(wk(:,k)))^2)/(abs((wk(:,k))'*hd_k(:,k)))^2)*SNR)];%%%%%%%%%%%%%%%%%
% %             Efuzhu=[Efuzhu (t1*(((derta1_2*(norm((wk(:,k))'*g*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k(:,k)+g*phik(:,:,k)*hr_k(:,k))))^2))*SNR))];%%%%%%%%%%%%%%%%
% %             Efangda=[Efangda (t1*(((derta1_2*(norm((wk(:,k))'*g*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k(:,k)+g*phik(:,:,k)*hr_k(:,k))))^2))*SNR*(norm(phik(:,:,k)*hr_k(:,k)))^2+...
% %                 derta1_2*(norm(phik(:,:,k)*eye(M)))^2))];%%%%%%%%%%%%%%%
%         end
%         EE1_10(count,:)=EE1
%         EE2=sum(EE1(1:Kcluster));
% %         Ef2=sum(Ef(1:Kcluster));%%%%%%%%%%%%%%%%%
% %         Efuzhu2=sum(Efuzhu(1:Kcluster));%%%%%%%%%%%%%%%%%
% %         Efangda2=sum(Efangda(1:Kcluster));%%%%%%%%%%%%%%%%%
% %         Ezuocha=Ef2-Efuzhu2;%%%%%%%%%%%%%
%         Etotal_=EE2+Esink+ECM+ECH_intra+t0*(PS*(norm(w0))^2+M*Pirs+PS*(norm(phi0*g'*w0))^2+derta1_2*(norm(phi0*eye(M)))^2);
%         Ex1=t0*(PS*(norm(w0))^2+M*Pirs+PS*(norm(phi0*g'*w0))^2+derta1_2*(norm(phi0*eye(M)))^2);
%         HH1=[];
% 
% %  hd_n=hd_n_1-sqrt(xindaopiancha)*abs(hd_n).*(sqrt(1/2)*(randn(Nt,N)+1j*randn(Nt,N)));
% % hr_n=hr_n_1-sqrt(xindaopiancha)*abs(hr_n).*(sqrt(1/2)*(randn(M,N)+1j*randn(M,N)));
% 
% 
% % r_1 = abs(hd_n);
% % theta_1 = angle(hd_n);
% % r_2 = abs(hr_n);
% % theta_2 = angle(hr_n);
% %  hd_n=r_1.*exp(1i.*theta_1).*exp(1i.*rand(Nt, N) * 2*xindaopiancha*pi);
% %   hr_n=r_2.*exp(1i.*theta_2).*exp(1i.*rand(M, N) * 2*xindaopiancha*pi);
% 
% % for n=1:N
% %             hr_n(:,n)=hr_n(:,n)-sqrt(xindaopiancha)*sqrt(C0.*(((dIC(1,n))./D0).^(-alpha_IC)))*sqrt((beta_IC+1)/(beta_IC+1))*(sqrt(1/2)*(randn(M,1)+1j*randn(M,1))); %hr,n维度M*1
% %         end
% %         for n=1:N
% %             hd_n(:,n)=hd_n(:,n)-sqrt(xindaopiancha)*sqrt(C0.*((dSC(1,n)./D0).^(-alpha_SC)))*sqrt((beta_IC+1)/(beta_IC+1))*(sqrt(1/2)*(randn(Nt,1)+1j*randn(Nt,1)));
% %         end
% 
% 
% % g=g_1-sqrt(xindaopiancha)*sqrt(C0*((dIS/D0).^(-alpha_SI)))*sqrt(1/(beta_SI+1))*(sqrt(1/2)*(randn(Nt,M)+1j*randn(Nt,M))); 
% EEe1=[];
%         for n=1:N
%             HH1=[HH1 (PS*(abs(((hd_n(:,n))'+(hr_n(:,n))'*phi0*g')*w0)).^2+derta1_2*(norm((hr_n(:,n))'*phi0))^2+derta3n_2)];
%         end
%         HH1_10(count,:)=t0*yita*HH1;
%           % HH1_10=  t0*yita*HH1_10
%         HH2=sum(HH1(1:N));
%         for k=1:Kcluster
%             EEe1=[EEe1 (t1*((derta1_2*(norm((wk(:,k))'*g*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k(:,k)+g*phik(:,:,k)*hr_k(:,k))))^2))*SNR)];
%         end
%         EEe1_10(count,:)=EEe1;
%         Eharvesting_=t0*yita*HH2;
%         EE=Rtotal/(Etotal_-Eharvesting_);
%         Ex=Ex1-Eharvesting_;
%         Ex_10(count,:)=Ex;
% %         HHm=t0*yita*HH1;
%         AO=[AO EE]; %看交替优化收敛性
%         AO1=[AO1 Etotal_];
%         AO2=[AO2 Eharvesting_];
% 
% 
% 
%         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        end
        HH3=t0*yita*HH1;
 EEe1=[];

  % akio11{it}=wk;
  %       akio12{it}=w0;
  %       akio13{it}=ak;
  %       akio14{it}=v0;
  %       akio15{it}=theta;

  akio11{it}=rank1_violationjuzhen;
        akio12{it}=iter2;
        akio13{it}=iter;
        akio14{it}=p2_juzhen;
        akio15{it}=rank1_violation_0_juzhen;
akio16{it}=iter3;
akio17{it}=p1;
akio17{it}=p1_juzhen;


        for k=1:Kcluster
            EEe1=[EEe1 (t1*((derta1_2*(norm((wk(:,k))'*g*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k(:,k)+g*phik(:,:,k)*hr_k(:,k))))^2))*SNR)];
        end
%         HHM=[HHM ; HHm];
%         AO=[AO EE];
%         end
%         figure
%         plot(1:length(AO),real(AO));
        weizhi=[weizhi EE]; %IRS不同位置的能效
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%所有CHs上行数据传输阶段消耗的总能量%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     
       
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%信道误差%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      
        % akio1{it}=hd_k_1;
        % akio2{it}=hr_k_1;
        % akio3{it}=g;
        % akio4{it}=hd_n_1;
        % akio5{it}=hr_n_1;
        
        for io_1=1:1
           % for io_1=1:1
           for io=1:1
        % for io=1:1
xindaopiancha_1=[0,0.02,0.04,0.06,0.08,0.1,0.12,0.14,0.16,0.18,0.2];
xindaopiancha=xindaopiancha_1(io_1);
        EE_old=EE;
        EE1_1=[];


hd_k_2=hd_k_1-sqrt(xindaopiancha)*abs(hd_k_1).*(sqrt(1/2)*(randn(Nt,Kcluster)+1j*randn(Nt,Kcluster)));
        hr_k_2= hr_k_1-sqrt(xindaopiancha)*abs(hr_k_1).*(sqrt(1/2)*(randn(M,Kcluster)+1j*randn(M,Kcluster)));
        % sqrt(C0.*(((dIC(1,n))./D0).^(-alpha_IC)))*(sqrt(beta_IC/(beta_IC+1))*ones(M,1)+sqrt(1/(beta_IC+1))
 % 
 % r_4 = abs(hd_k-sqrt(C0.*((dCS(:,k)./D0).^(-alpha_SC)))*(sqrt(beta_IC/(beta_IC+1))*ones(Nt,Kcluster)));
 % theta_4 = angle(hd_k-sqrt(C0.*((dCS(:,k)./D0).^(-alpha_SC)))*(sqrt(beta_IC/(beta_IC+1))*ones(Nt,Kcluster)));
 % r_5 = abs(hr_k-sqrt(C0.*(((dCI(1,k))./D0).^(-alpha_IC)))*(sqrt(beta_IC/(beta_IC+1))*ones(M,Kcluster)));
 % theta_5 = angle(hr_k-sqrt(C0.*(((dCI(1,k))./D0).^(-alpha_IC)))*(sqrt(beta_IC/(beta_IC+1))*ones(M,Kcluster)));
 %    hd_k_2=sqrt(C0.*((dCS(:,k)./D0).^(-alpha_SC)))*(sqrt(beta_IC/(beta_IC+1))*ones(Nt,Kcluster))+r_4.*exp(1i.*theta_4).*exp(1i.*rand(Nt,Kcluster) * 2*xindaopiancha*pi);
 %   hr_k_2=sqrt(C0.*(((dCI(1,k))./D0).^(-alpha_IC)))*(sqrt(beta_IC/(beta_IC+1))*ones(M,Kcluster))+r_5.*exp(1i.*theta_5).*exp(1i.*rand(M,Kcluster) * 2*xindaopiancha*pi);
r_3 = abs(g);
theta_3 = angle(g);
% g_3=r_3.*exp(1i.*theta_3).*exp(1i.*rand(Nt,M) * 2*xindaopiancha*pi);
% g_3=g_1-sqrt(xindaopiancha)*sqrt(C0*((dIS/D0).^(-alpha_SI)))*sqrt(1/(beta_SI+1))*(sqrt(1/2)*(randn(Nt,M)+1j*randn(Nt,M))); 
 g_3=g-sqrt(xindaopiancha)*abs(g).*(sqrt(1/2)*(randn(Nt,M)+1j*randn(Nt,M))); 

       % for k=1:Kcluster
       %      hr_k_2(:,k)=hr_k_2(:,k)-sqrt(xindaopiancha)*sqrt(C0.*(((dCI(1,k))./D0).^(-alpha_IC)))*sqrt((beta_IC+1)/(beta_IC+1))*(sqrt(1/2)*(randn(M,1)+1j*randn(M,1))); %上行CH到IRS信道M*1
       %  end
       %  for k=1:Kcluster
       %      hd_k_2(:,k)=hd_k_2(:,k)-sqrt(xindaopiancha)*sqrt(C0.*((dCS(:,k)./D0).^(-alpha_SC)))*sqrt((beta_IC+1)/(beta_IC+1))*(sqrt(1/2)*(randn(Nt,1)+1j*randn(Nt,1))); %上行CH到sink信道Nt*1
       %  end


        for k=1:Kcluster
            EE1_1=[EE1_1 (t1*(((derta1_2*(norm((wk(:,k))'*g_3*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k_2(:,k)+g_3*phik(:,:,k)*hr_k_2(:,k))))^2))*SNR+...
                ((derta1_2*(norm((wk(:,k))'*g_3*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k_2(:,k)+g_3*phik(:,:,k)*hr_k_2(:,k))))^2))*SNR*(norm(phik(:,:,k)*hr_k_2(:,k)))^2+...
                derta1_2*(norm(phik(:,:,k)*eye(M)))^2+M*Pirs)+(Eelec+EDA)*L)]; %Eelec*L是电子电路能耗，EDA*L是CHk聚合自身的能耗。
%             Ef=[Ef (t1*((derta2_2*(norm(wk(:,k)))^2)/(abs((wk(:,k))'*hd_k_2(:,k)))^2)*SNR)];%%%%%%%%%%%%%%%%%
%             Efuzhu=[Efuzhu (t1*(((derta1_2*(norm((wk(:,k))'*g_3*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k_2(:,k)+g_3*phik(:,:,k)*hr_k_2(:,k))))^2))*SNR))];%%%%%%%%%%%%%%%%
%             Efangda=[Efangda (t1*(((derta1_2*(norm((wk(:,k))'*g_3*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k_2(:,k)+g_3*phik(:,:,k)*hr_k_2(:,k))))^2))*SNR*(norm(phik(:,:,k)*hr_k_2(:,k)))^2+...
%                 derta1_2*(norm(phik(:,:,k)*eye(M)))^2))];%%%%%%%%%%%%%%%
        end
        EE2=sum(EE1_1(1:Kcluster));
%         Ef2=sum(Ef(1:Kcluster));%%%%%%%%%%%%%%%%%
%         Efuzhu2=sum(Efuzhu(1:Kcluster));%%%%%%%%%%%%%%%%%
%         Efangda2=sum(Efangda(1:Kcluster));%%%%%%%%%%%%%%%%%
%         Ezuocha=Ef2-Efuzhu2;%%%%%%%%%%%%%
        Etotal_1=EE2+Esink+ECM+ECH_intra+t0*(PS*(norm(w0))^2+M*Pirs+PS*(norm(phi0*g_3'*w0))^2+derta1_2*(norm(phi0*eye(M)))^2);
        Ex1=t0*(PS*(norm(w0))^2+M*Pirs+PS*(norm(phi0*g_3'*w0))^2+derta1_2*(norm(phi0*eye(M)))^2);
        HH1_1=[];
% 
hd_n_3=hd_n_1-sqrt(xindaopiancha)*abs(hd_n).*(sqrt(1/2)*(randn(Nt,N)+1j*randn(Nt,N)));
hr_n_3=hr_n_1-sqrt(xindaopiancha)*abs(hr_n).*(sqrt(1/2)*(randn(M,N)+1j*randn(M,N)));
% 
% akio6{io_1,io}=hd_k_2;
% akio7{io_1,io}=hr_k_2;
% akio8{io_1,io}=g_3;
% akio9{io_1,io}=hd_n_3;
% akio10{io_1,io}=hr_n_3;

% 
% r_1 = abs(hd_n);
% theta_1 = angle(hd_n);
% r_2 = abs(hr_n);
% theta_2 = angle(hr_n);
%  hd_n_3=r_1.*exp(1i.*theta_1).*exp(1i.*rand(Nt, N) * 2*xindaopiancha*pi);
%   hr_n_3=r_2.*exp(1i.*theta_2).*exp(1i.*rand(M, N) * 2*xindaopiancha*pi);

% for n=1:N
%             hr_n_3(:,n)=hr_n(:,n)-sqrt(xindaopiancha)*sqrt(C0.*(((dIC(1,n))./D0).^(-alpha_IC)))*sqrt((beta_IC+1)/(beta_IC+1))*(sqrt(1/2)*(randn(M,1)+1j*randn(M,1))); %hr,n维度M*1
%         end
%         for n=1:N
%             hd_n_3(:,n)=hd_n(:,n)-sqrt(xindaopiancha)*shr_nqrt(C0.*((dSC(1,n)./D0).^(-alpha_SC)))*sqrt((beta_IC+1)/(beta_IC+1))*(sqrt(1/2)*(randn(Nt,1)+1j*randn(Nt,1)));
%         end
        

% g_3=g_1-sqrt(xindaopiancha)*sqrt(C0*((dIS/D0).^(-alpha_SI)))*sqrt(1/(beta_SI+1))*(sqrt(1/2)*(randn(Nt,M)+1j*randn(Nt,M))); 

        for n=1:N
            HH1_1=[HH1_1 (PS*(abs(((hd_n_3(:,n))'+(hr_n_3(:,n))'*phi0*g_3')*w0))^2+derta1_2*(norm((hr_n_3(:,n))'*phi0))^2+derta3n_2)];
        end
        HH2=sum(HH1_1(1:N));
        Eharvesting_=t0*yita*HH2;
        EE_1=Rtotal/(Etotal_1-Eharvesting_);
        % EE_wucha(io,io)=EE_1;
         weizhi_2=[weizhi_2 EE_1]; %IRS不同位置的能效
        Ex_1=Ex1-Eharvesting_;
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%误差结束%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        EEe1_1=[];
        for k=1:Kcluster
            EEe1_1=[EEe1_1 (t1*((derta1_2*(norm((wk(:,k))'*g_3*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k_2(:,k)+g_3*phik(:,:,k)*hr_k_2(:,k))))^2))*SNR)];
        end
%         EEe2=sum(EEe1(1:Kcluster));
%         Eee=[Eee EEe2];
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%EH-CRSNs总功耗%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%         Egonghao=Etotal_; %CHs向sink传输数据的功耗，上下行主动IRS的功耗，sink的功耗

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%所有CRSNs节点收集的总能量%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%         Eeh1=Eharvesting_; %所有CRSNs节点收集的总能量
%         HHm=t0*yita*HH1; %每个CRSNs节点收集的能量
%         Eeh=[Eeh Eeh1];
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%CHk上行数据传输的发送功率%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%         pk=[];
%         for k=1:Kcluster
%             pk=[pk ((derta1_2*(norm((wk(:,k))'*g_3*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k_2(:,k)+g_3*phik(:,:,k)*hr_k_2(:,k))))^2))*SNR];
%         end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
       EE_2(io)=EE_1;
HH12(io,:)=HH1_1;
Etotal_2(io,:)=Etotal_1;
EEe12(io,:)=EEe1_1;
Ex_2(io,:)=Ex_1;
EE1_2(io,:)=EE1_1;
end
EE_3(io_1,:)=sum(EE_2)/io;
HH13(io_1,:)=sum(HH12,1)/io;
Etotal_3(io_1,:)=sum(Etotal_2,1)/io;
EEe13(io_1,:)=sum(EEe12,1)/io;
Ex_3(io_1,:)=sum(Ex_2,1)/io;
EE1_3(io_1,:)=sum(EE1_2,1)/io;
% EE_3(ioi,:)=sum(EE_2)/io;
% HH13(ioi,:)=sum(HH12,1)/io;
% Etotal_3(ioi,:)=sum(Etotal_2,1)/io;
% EEe13(ioi,:)=sum(EEe12,1)/io;
% Ex_3(ioi,:)=sum(Ex_2,1)/io;
% EE1_3(ioi,:)=sum(EE1_2,1)/io;


           end
           
        
    end
%     EE_4=EE_4+EE_3;
% HH14=HH13+HH14;
% Etotal_4=Etotal_3+Etotal_4;
% EEe14=EEe13+EEe14;
% Ex_4=Ex_3+Ex_4;
% EE1_4=EE1_3+EE1_4;
% HH4=HH3+HH4;
EE_4(it,:)=EE_3;
HH14(it,:)=t0*yita*HH13;
Etotal_4(it,:)=Etotal_3;
EEe14(it,:)=EEe13;
Ex_4(it,:)=Ex_3;
EE1_4(it,:)=EE1_3;
HH4=HH3+HH4;
%     figure
%     plot(1:length(weizhi),real(weizhi));
     eee1=[eee1 ; EEe1];
    ES=[ES ; EE1];
    Exx=[Exx ; Ex];
%     eee=[eee ; Eee];
%     hhh=[hhh ; Eeh];
%     HHM=[HHM ; HHm];
%     ppk=[ppk ; pk];
    nengxiao=[nengxiao ; EE]; %it次不同IRS位置能效
    nengxiao1=[nengxiao1 ; weizhi]; %it次不同IRS位置能效
     %it次不同IRS位置能效
   
AO3{it}=AO;
SS11{it}=SS1;
end
EE_5=EE_4/it;
HH15=HH14/it;
HH16=t0*yita*HH15
Etotal_5=Etotal_4/it;
EEe15=EEe14/it;
Ex_5=Ex_4/it;
EE1_5=EE1_4/it;
HH5=HH4/it;

eem=mean(eee1,1);
EEm=mean(nengxiao,1);
ESS=mean(ES,1);
EXX=mean(Exx,1);
% hhm=mean(HHM,1);%求矩阵每一列的均值
% ppkk=mean(ppk,1);
% hhmm=xlswrite('100jiedianECM.xlsx',hhm,'Sheet1','C39:CX39');%将EBUCRP每轮选取的簇头数写入表格
% ppkk1=xlswrite('100jiedianECM.xlsx',ppkk,'Sheet1','C40:CX40');
% rr=[];
% for i=1:100
%     rr=[rr ; i];
% end
% %%%%%%%%%%%%%无IRS
% EUL21=0;
% for k=1:K %代回初始数据传输公式
%     EUL21=EUL21+(L1*(Eelec+Efs*((d01(:,k))^2)));
% end
% Einter1=EUL21;
% Gt=1;
% Gr=1;
% sum21=0;
% for n=1:N %代回初始能量收集公式
%     YY(:,n)=(PA*Gt*Gr*lamuda^2)/(16*pi^2*(d0(:,n))^2);
%     sum21=sum21+YY(:,n);
% end
% Eharvesting1=t0*yita*sum21;
% Ebenefit1=Eharvesting1-Einter1;
% yIRS_irs=[];
% for ii=-50:0.1:50 %%%%%%%%%%%%%%%%%%%%%%%%%
%     yIRS_irs=[yIRS_irs ii];
% end
% aveintra=mean(eee,1);%求矩阵每一列的均值
% aveharvesting=mean(hhh,1);
% aveweizhi=mean(nengxiao,1);
% plot(yIRS_irs, aveweizhi,'b-o','LineWidth',2)
% grid on  %显示网格线
% xlabel('Iteration Number (m)') 
% ylabel('Energy Efficiency (Bits/Joule/Hz)')
% legend('Nt=4')
% % sum=[];
% % for i=-50:0.1:50
% %     sum=[sum ; i];
% % end
% i=0;
% as=0;
% ass=xlsread('C:\Users\亚楠\Desktop\仿真结果.xlsx','Sheet2','D4:D1004');
% for j=1:length(ass)
%     if ass(j)>as
%         as=ass(j);
%         i=j;
%     end
% end
% aaa=3567245.597./[2.91533E8	711629.0019	712411.9286	1.56525E8	1.97154E8	2.69181E8	2.63411E8	2.65775E8	1.69416E8
% ]
% 
% 
% EH=[4.0003E-10	6.57718E-5	1.42588E-4	7.7016E-16	1.06301E-15	4E-10	4.0003E-10	4E-10	4.0003E-10
% ]
% 
% nenghao=aaa+EH
% 
% PC=db2pow(-10)/1000;
% 
% PDC=db2pow(-10)/1000;
% Pirs=PC+PDC;
% for aoo=1:20
% PC1=db2pow(-10+aoo/2)/1000;
% PDC1=db2pow(-5)/1000;
% Pirs1=PC1+PDC1;
% aa=0.525*10*(Pirs1-Pirs)+aaa;
% aaaa(aoo,:)=3567245.597./aa
% end
% io=-10:0.5:0
% aio=io'
% AU=[23.94769478
% 10.66186114
% 24.50363265
% 20.94542306
% 24.44427958
% 22.44533678
% 22.62831552
% 21.9998803
% 21.44849066
% ]';
% aao=sum([291533177.5	319672006.8	268625047.3	276230928.6	301928861.5	350835506	287700843.4	343145750.4	290677401.2	282657571.2	337734540.8	339477416.7	211934434.9	264560287.4	378630405	395852472.7	339492219.1	339554678.2	350905460.7	284898856.7
% ])/20-([1.97652E8
% 2.60004E8
% 1.83881E8
% 1.61922E8])./[1.97652E8
% 2.60004E8
% 1.83881E8
% 1.61922E8]
% 
% aao=sum([291533177.5	319672006.8	268625047.3	276230928.6	301928861.5	350835506	287700843.4	343145750.4	290677401.2	282657571.2	337734540.8	339477416.7	211934434.9	264560287.4	378630405	395852472.7	339492219.1	339554678.2	350905460.7	284898856.7
% ])/20
% aaao=sum([711629.0019	780394.4983	656212.895	675923.6269	738879.7358	856484.2294	703313.732	839157.5649	711452.1469	689074.0826	830192.8587	830203.3359	517629.3619	645446.2162	937490.485	963938.0039	830784.8143	830203.7978	865638.7181	697391.6199
% ])/20
% aao/aaao
% 
% [2.79568E8
% 3.36957E8
% 2.60127E8
% 2.28941E8]./[2.47381E8
% 3.10093E8
% 2.30165E8
% 2.02613E8]
% abb=[361.4405																																												
% 	0.88331																																											
% 		0.88728																																										
% 			350.34036																																									
% 				335.72283																																								
% 					327.23072																																							
% 						248.10559																																						
% 							252.48027																																					
% 								236.41453																																				
% 									427.81017																																			
% 										1.04795																																		
% 											1.05265																																	
% 												422.29035																																
% 													412.39155																															
% 														404.33241																														
% 															345.71767																													
% 																320.14185																												
% 																	339.97872																											
% 																		322.13626																										
% 																			0.78795																									
% 																				0.79149																								
% 																					312.07961																							
% 																						298.0204																						
% 																							290.72871																					
% 																								218.74545																				
% 																									224.20837																			
% 																										205.89942																		
% 																											305.70032																	
% 																												0.74833																
% 																													0.7517															
% 																														295.7252														
% 																															280.53542													
% 																																272.00183												
% 																																	197.38479											
% 																																		208.78551										
% 																																			188.0012									
% 																																				297.25286								
% 																																					0.72611							
% 																																						0.72938						
% 																																							286.44438					
% 																																								266.08793				
% 																																									258.86681			
% 																																										183.13086		
% 																																											199.61494	
% 																																								172.44414]
% 
% 
% 
% 
% 
% for o=1:5
% aab(o)=(abb((o-1)*9+1)-abb((o-1)*9+4))/abb((o-1)*9+4);
%     end


% ([2.91533E8
% 2.91493E8
% 2.91445E8
% 2.91399E8
% 2.91379E8
% 2.91325E8
% 2.91261E8
% 2.91194E8
% 2.91185E8
% 2.91079E8
% 2.91073E8]-[1.97154E8
% 1.96974E8
% 1.96581E8
% 1.96423E8
% 1.96114E8
% 1.96024E8
% 1.9526E8
% 1.94372E8
% 1.95E8
% 1.93404E8
% 1.92513E8])./[1.97154E8
% 1.96974E8
% 1.96581E8
% 1.96423E8
% 1.96114E8
% 1.96024E8
% 1.9526E8
% 1.94372E8
% 1.95E8
% 1.93404E8
% 1.92513E8];


