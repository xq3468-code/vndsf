function [S4,MCogLEACH_TotalEnergyConsumption1,MCogLEACH_Clusterhead1,MCogLEACH_Numberoflive1,MCogLEACH_EnergyEfficiency1,MCogLEACH_Numberoflivenirs1,MCogLEACH_EnergyEfficiencyNIRS1,MCogLEACH_Numberofliveab1,MCogLEACH_EnergyEfficiencyEb1,MCogLEACH_Numberoflivep1,MCogLEACH_EnergyEfficiencyP1,MCogLEACH_Numberoflives1,MCogLEACH_EnergyEfficiencyS1,MCogLEACH_Numberofliveu1,MCogLEACH_EnergyEfficiencyU1,MCogLEACH_Numberoflived1,MCogLEACH_EnergyEfficiencyD1,MCogLEACH_Numberofliver1,MCogLEACH_EnergyEfficiencyR1,MCogLEACH_Numberofliveg1,MCogLEACH_EnergyEfficiencyG1]=IRSCogLEACH(S,S4,c,n,r,occupy,willoccupy,nodetransmissionrange,L,L1,MCogLEACH_flag_first_dead,MCogLEACH_flag_last_dead,MCogLEACH_flag_first_deadnirs,MCogLEACH_flag_last_deadnirs,MCogLEACH_flag_first_deadab,MCogLEACH_flag_last_deadab,MCogLEACH_flag_first_deadp,MCogLEACH_flag_last_deadp,MCogLEACH_flag_first_deads,MCogLEACH_flag_last_deads,MCogLEACH_flag_first_deadu,MCogLEACH_flag_last_deadu,MCogLEACH_flag_first_deadd,MCogLEACH_flag_last_deadd,MCogLEACH_flag_first_deadr,MCogLEACH_flag_last_deadr,MCogLEACH_flag_first_deadg,MCogLEACH_flag_last_deadg,EH_in,EH_innirs,EH_inab,EH_inp,EH_ins,EH_inu,EH_ind,EH_inr,EH_ing)
%能耗模型
ETX=50*0.000000001; %发送和接收数据时电路能耗Eelec=50nJ/b
Efs=10*0.000000000001; %发送时功率放大器功耗取决于距离，当小于参考距离d0时为10pJ/b/m2;大于参考距离d0时为0.0013pJ/b/m4
Emp=0.0013*0.000000000001;
EDA=5*0.000000001; %聚合数据时消耗能量为5nJ/b/包
d0=sqrt(Efs/Emp);%计算参考距离d0=87.7m
%,MCogLEACH_Residualenergy1,MCogLEACH_Residualenergynirs1,MCogLEACH_Residualenergyab1,MCogLEACH_Residualenergyp1,MCogLEACH_Residualenergys1,MCogLEACH_Residualenergyu1,MCogLEACH_Residualenergyd1,MCogLEACH_Residualenergyr1,MCogLEACH_Residualenergyg1
%把返回参数都初始化，防止当所有节点的能量都为0时，返回值不正确-2019-2-19
MCogLEACH_Clusterhead1=0; %返回的簇头数
MCogLEACH_overheadofCH1=0; %返回选取簇头的开销
MCogLEACH_overheadofcluster1=0; %返回的簇构建开销
MCogLEACH_NumberofAcquisiton1=0; %返回的有效收集数据的节点数目
MCogLEACH_RatioofAcquisiton1=0; %返回的有效收集数据的节点比例
MCogLEACH_TotalEnergyConsumption1=0;%返回每轮所有节点总能耗-2022-5-19

% MCogLEACH_Residualenergy1=0;%返回剩余能量
% MCogLEACH_EnergyEfficiency=0; %返回系统能效
% MCogLEACH_Timedelay1=0;
% %*********************************************返回有效节点的平均时延-2021-12-14*****************************************************************
% %用来存储当前轮所有活着的节点位置，方便计算簇头选取和簇构建时延；或簇头节点的横纵坐标，方便计算稳态传输阶段的平均时延
% MCogLEACH_Acx=zeros(1,n); %用于存放当前活着节点的横纵坐标，以便调用delay函数计算平均时延
% MCogLEACH_Acy=zeros(1,n);
%最优簇数不从main函数传递过来，而是在MCogLEACH子函数中设置-2019-8-5
K=20;

% for i=1:1:n
%     MCogLEACH_Previousenergy(i)=S4(i).e;  %记录本轮起始时各节点的能量值，减去本轮结束时的S1(i).e，得到本轮节点的能耗
% end


if r==1
   for i=1:1:n
       S4(i).enirs=S4(i).e; %无IRS
       S4(i).eab=S4(i).e; %净能量收益
       S4(i).ep=S4(i).e; %被动
       S4(i).es=S4(i).e; %单天线
       S4(i).eu=S4(i).e; %仅优化上行
       S4(i).ed=S4(i).e; %仅优化下行
       S4(i).er=S4(i).e; %随机
       S4(i).eg=S4(i).e; %共用
   end
else
    for i=1:1:n
        S4(i).enirs=S4(i).enirs;
        S4(i).eab=S4(i).eab;
        S4(i).ep=S4(i).ep;
        S4(i).es=S4(i).es;
        S4(i).eu=S4(i).eu;
        S4(i).ed=S4(i).ed;
        S4(i).er=S4(i).er;
        S4(i).eg=S4(i).eg;
    end
end
%将本轮起始时的死亡节点数记录下来dead1
dead1=0;
for i=1:1:n
    MCogLEACH_Previousenergy(i)=S4(i).e+EH_in(i);%每轮开始每个节点在能量收集阶段收集能量，起始的S4(i).e=0.5J
    if (S4(i).e<=0)
       dead1=dead1+1; 
       MCogLEACH_Previousenergy(i)=S4(i).e;%如果节点死亡，则不收集能量
    end
    if (S4(i).e>0)&&(MCogLEACH_Previousenergy(i)>1)%节点电池能量最大不超过1J
       MCogLEACH_Previousenergy(i)=1; 
    end       
end
for i=1:1:n
    S4(i).e=MCogLEACH_Previousenergy(i);  %本轮起始时各节点的能量值，包括起始的能量和收集的能量
    S4(i).echu=S4(i).e;
end
%%*******************************************************NIRS的************************************************************************
deadnirs1=0;
for i=1:1:n
    MCogLEACH_Previousenergynirs(i)=S4(i).enirs+EH_innirs(i);%每轮开始每个节点在能量收集阶段收集能量，起始的S4(i).e=0.5J
    if (S4(i).enirs<=0)
       deadnirs1=deadnirs1+1; 
       MCogLEACH_Previousenergynirs(i)=S4(i).enirs;%如果节点死亡，则不收集能量
    end
    if (S4(i).enirs>0)&&(MCogLEACH_Previousenergynirs(i)>1)%节点电池能量最大不超过1J
       MCogLEACH_Previousenergynirs(i)=1; 
    end       
end
for i=1:1:n
    S4(i).enirs=MCogLEACH_Previousenergynirs(i);  %本轮起始时各节点的能量值，包括起始的能量和收集的能量
end
%%*********************************************************AEbenefit的******************************************************************
deadab1=0;
for i=1:1:n
    MCogLEACH_Previousenergyab(i)=S4(i).eab+EH_inab(i);%每轮开始每个节点在能量收集阶段收集能量，起始的S4(i).e=0.5J
    if (S4(i).eab<=0)
       deadab1=deadab1+1; 
       MCogLEACH_Previousenergyab(i)=S4(i).eab;%如果节点死亡，则不收集能量
    end
    if (S4(i).eab>0)&&(MCogLEACH_Previousenergyab(i)>1)%节点电池能量最大不超过1J
       MCogLEACH_Previousenergyab(i)=1; 
    end       
end
for i=1:1:n
    S4(i).eab=MCogLEACH_Previousenergyab(i);  %本轮起始时各节点的能量值，包括起始的能量和收集的能量
end
%%******************************************************被动的**********************************************
deadp1=0;
for i=1:1:n
    MCogLEACH_Previousenergyp(i)=S4(i).ep+EH_inp(i);%每轮开始每个节点在能量收集阶段收集能量，起始的S4(i).e=0.5J
    if (S4(i).ep<=0)
       deadp1=deadp1+1; 
       MCogLEACH_Previousenergyp(i)=S4(i).ep;%如果节点死亡，则不收集能量
    end
    if (S4(i).ep>0)&&(MCogLEACH_Previousenergyp(i)>1)%节点电池能量最大不超过1J
       MCogLEACH_Previousenergyp(i)=1; 
    end       
end
for i=1:1:n
    S4(i).ep=MCogLEACH_Previousenergyp(i);  %本轮起始时各节点的能量值，包括起始的能量和收集的能量
end
%%**************************************************单天线******************************************************
deads1=0;
for i=1:1:n
    MCogLEACH_Previousenergys(i)=S4(i).es+EH_ins(i);%每轮开始每个节点在能量收集阶段收集能量，起始的S4(i).e=0.5J
    if (S4(i).es<=0)
       deads1=deads1+1; 
       MCogLEACH_Previousenergys(i)=S4(i).es;%如果节点死亡，则不收集能量
    end
    if (S4(i).es>0)&&(MCogLEACH_Previousenergys(i)>1)%节点电池能量最大不超过1J
       MCogLEACH_Previousenergys(i)=1; 
    end       
end
for i=1:1:n
    S4(i).es=MCogLEACH_Previousenergys(i);  %本轮起始时各节点的能量值，包括起始的能量和收集的能量
end
%%*****************************************************仅优化上行***********************************************************
deadu1=0;
for i=1:1:n
    MCogLEACH_Previousenergyu(i)=S4(i).eu+EH_inu(i);%每轮开始每个节点在能量收集阶段收集能量，起始的S4(i).e=0.5J
    if (S4(i).eu<=0)
       deadu1=deadu1+1; 
       MCogLEACH_Previousenergyu(i)=S4(i).eu;%如果节点死亡，则不收集能量
    end
    if (S4(i).eu>0)&&(MCogLEACH_Previousenergyu(i)>1)%节点电池能量最大不超过1J
       MCogLEACH_Previousenergyu(i)=1; 
    end       
end
for i=1:1:n
    S4(i).eu=MCogLEACH_Previousenergyu(i);  %本轮起始时各节点的能量值，包括起始的能量和收集的能量
end
%%*****************************************************仅优化下行***********************************************************
deadd1=0;
for i=1:1:n
    MCogLEACH_Previousenergyd(i)=S4(i).ed+EH_ind(i);%每轮开始每个节点在能量收集阶段收集能量，起始的S4(i).e=0.5J
    if (S4(i).ed<=0)
       deadd1=deadd1+1; 
       MCogLEACH_Previousenergyd(i)=S4(i).ed;%如果节点死亡，则不收集能量
    end
    if (S4(i).ed>0)&&(MCogLEACH_Previousenergyd(i)>1)%节点电池能量最大不超过1J
       MCogLEACH_Previousenergyd(i)=1; 
    end       
end
for i=1:1:n
    S4(i).ed=MCogLEACH_Previousenergyd(i);  %本轮起始时各节点的能量值，包括起始的能量和收集的能量
end
%%*****************************************************随机反射因子矩阵***********************************************************
deadr1=0;
for i=1:1:n
    MCogLEACH_Previousenergyr(i)=S4(i).er+EH_inr(i);%每轮开始每个节点在能量收集阶段收集能量，起始的S4(i).e=0.5J
    if (S4(i).er<=0)
       deadr1=deadr1+1; 
       MCogLEACH_Previousenergyr(i)=S4(i).er;%如果节点死亡，则不收集能量
    end
    if (S4(i).er>0)&&(MCogLEACH_Previousenergyr(i)>1)%节点电池能量最大不超过1J
       MCogLEACH_Previousenergyr(i)=1; 
    end       
end
for i=1:1:n
    S4(i).er=MCogLEACH_Previousenergyr(i);  %本轮起始时各节点的能量值，包括起始的能量和收集的能量
end
%%*****************************************************共用反射因子矩阵***********************************************************
deadg1=0;
for i=1:1:n
    MCogLEACH_Previousenergyg(i)=S4(i).eg+EH_ing(i);%每轮开始每个节点在能量收集阶段收集能量，起始的S4(i).e=0.5J
    if (S4(i).eg<=0)
       deadg1=deadg1+1; 
       MCogLEACH_Previousenergyg(i)=S4(i).eg;%如果节点死亡，则不收集能量
    end
    if (S4(i).eg>0)&&(MCogLEACH_Previousenergyg(i)>1)%节点电池能量最大不超过1J
       MCogLEACH_Previousenergyg(i)=1; 
    end       
end
for i=1:1:n
    S4(i).eg=MCogLEACH_Previousenergyg(i);  %本轮起始时各节点的能量值，包括起始的能量和收集的能量
end
% %每个节点在一轮开始时进行能量收集
% load('EHrmax.mat');
% for i=1:n
%     if S4(i).e>0
%        S4(i).e=min(S4(i).e+EHrmax(i,r)*0.2,1);%节点最大能量不超过1J
%     end
% end
%***************************************************时延计算第一部分-簇构建引入的时延:每个活着的节点都要向外广播消息，CH广播通告，其他节点广播加入请求***********************************************************
% clusterconstructiondelay=0;
% for i=1:1:n
%     jump=0;
%     if S4(i).e>0
%        for j=1:1:n
%            if MCogLEACH_Acx(j)==0
%               jump=j;
%               break;
%            end
%        end
%        MCogLEACH_Acx(jump)=S4(i).xd;
%        MCogLEACH_Acy(jump)=S4(i).yd;
%     end
% end
% if dead1<n
%    DELAY=zeros(1,n-dead1);
%    DELAY=delay(n-dead1,ones(1,n-dead1),MCogLEACH_Acx,MCogLEACH_Acy,0.2,nodetransmissionrange); %控制信道上竞争时每个时隙长度为390微秒，取0.4ms(改：控制包传输速率512kbps,时隙长度0.2ms;数据包传输速率1Mbps,时延长度1ms)
%    clusterconstructiondelay=max(DELAY)*2;  %簇构建的总时延：最大的竞争时延加上每个节点在竞争到时隙后都要发送控制包的1个时隙  %%*2为控制开销数量
% end
%***************************************第一部分时延计算结束***********************************************************************************

for i=1:1:n
    S4(i).type='N'; %节点i的类型初始化为普通簇成员节点，因为此时还没有分簇，没有选簇头
    if S4(i).e>0
       S4(i).t=0; %节点当前可用信道数初始化为0
       S4(i).ch=0; %将节点所属的CH号初始化为0-2018.8.4
    end
end

%计算网络中所有节点的可用信道总数
Totalchannel=0;  %网络中所有节点的可用信道数总和，实际上MCogLEACH使用空间和频谱相似性模型对所有节点总的可用信道数进行估计，不需要sink节点来统计并广播该信息-2019-1-2
for i=1:1:n
    if S4(i).e>0
       for j=1:1:c
           if occupy(i,j,r)==0  %表示第i个SUs的第j条信道在第r轮起始时没有被占用，则总的可用信道数加1-2019-4-24
              Totalchannel=Totalchannel+1;
           end
       end
    end
end

%初始化每轮选取的簇头数初始化为0
cluster=1;

%对于每个节点计算节点成为簇头的概率权重，然后与生成的随机数进行比较，如果大于等于随机数，则该节点成为CH
for i=1:1:n
    if S4(i).e>0
       temp_rand=rand; %产生0~1之间的随机数用于与节点的门限进行比较，当该随机数小于门限时，节点成为CH
       for j=1:1:c  %计算节点i当前可用的信道数
           if occupy(i,j,r)==0  %表示第i个SUs的第j条信道在第r轮起始时没有被占用，则节点的可用信道数加1-2019-4-24
              S4(i).t=S4(i).t+1;
           end
       end
       if (temp_rand<=min(1,K*S4(i).t/Totalchannel))
           S4(i).type='C';
           S4(i).ch=101;  %将CH与普通节点区分开来-2018-8-5
           C(cluster).xd=S4(i).xd;
           C(cluster).yd=S4(i).yd;
           C(cluster).id=i; %记录CH节点号
           cluster=cluster+1;
           if nodetransmissionrange>=d0  %加一个节点传输范围与d0之间关系的判断-2019-4-24
              S4(i).e=S4(i).e-(ETX+Emp*nodetransmissionrange^4)*L1*3; %每个CH节点都要向传输范围内的节点广播簇头临时通告消息、最终通告消息及向簇成员广播TDMA调度-2019-1-2
           else
               S4(i).e=S4(i).e-(ETX+Efs*nodetransmissionrange^2)*L1*3; %每个CH节点都要向传输范围内的节点广播簇头临时通告消息、最终通告消息及向簇成员广播TDMA调度-2019-1-2
           end
           MCogLEACH_overheadofcluster1=MCogLEACH_overheadofcluster1+2; %每个簇头都会向外广播临时CH通告和最终CH通告，开销加2-2019-2-19
           for j=1:1:n
               if S4(j).e>0 && j~=i
                   if sqrt((S4(i).xd-S4(j).xd)^2+(S4(i).yd-S4(j).yd)^2)<=nodetransmissionrange
                      S4(j).e=S4(j).e-ETX*L1*2; %簇头传输范围内的所有节点都会接收到簇头临时通告消息和最终通告消息，因为所有消息都是在CCC上传输的-2019-1-17
                   end
               end
           end
       end
    end
end
MCogLEACH_Clusterhead1=cluster-1;  %最终形成的簇数为cluster-1

if cluster-1>=1  %至少有一个簇存在时，才能进行下面的操作
   %对属于每个簇的成员节点号、簇信道等进行初始化-2018-8-5
   for i=1:1:cluster-1
       avae(i)=0;  %将CH最终选取的簇信道初始化为0
       for j=1:1:n
           cm(i,j)=0;  %将属于CH i 的簇成员号初始化为0，最多可以有100个成员
           cme(i,j)=0; %将最终属于CH i 的簇成员号初始化为0，最多可以有100个成员
       end
       for j=1:1:c
           ava(i,j)=0;  %将运行在簇头的各可用信道上的簇成员数初始化为0
           if occupy(C(i).id,j,r)==0  %后补充，防止有孤立CH出现情况，该簇可能会没有的信道-2019-12-15
              ava(i,j)=ava(i,j)+1;
           end
       end
   end  
   %为各普通节点寻找可能的CH
   for i=1:1:n
       if S4(i).e>0
          if S4(i).ch==0  %说明是普通CRSNs节点
             distance1=2000;  %计算节点与CH之间的距离
             for j=1:1:cluster-1
                 if S4(C(j).id).e>0
                    for f=1:1:c
                        if occupy(i,f,r)+occupy(C(j).id,f,r)==0   %说明节点与CH之间有公共信道，则计算两者间的距离-2019-4-24
                           if sqrt((S4(i).xd-C(j).xd)^2+(S4(i).yd-C(j).yd)^2)<distance1
                              S4(i).ch=C(j).id;
                              distance1=sqrt((S4(i).xd-C(j).xd)^2+(S4(i).yd-C(j).yd)^2);
                           end
                           break;
                        end
                     end
                 end
             end
             if distance1<=nodetransmissionrange %说明找到了CH-补充：簇内通信距离必须小于等于节点传输范围-2019-1-3
                if distance1>=d0  %加一个节点传输范围与d0之间关系的判断-2019-4-24
                   S4(i).e=S4(i).e-(ETX+Emp*distance1^4)*L1; %非簇头节点向有公共信道且距离最近的CH发送临时加入请求-2019-1-2
                else
                    S4(i).e=S4(i).e-(ETX+Efs*distance1^2)*L1; %非簇头节点向有公共信道且距离最近的CH发送临时加入请求-2019-1-2
                end
                MCogLEACH_overheadofcluster1=MCogLEACH_overheadofcluster1+1; %非CH节点向CH发送临时加入请求，开销加1-2019-2-19
                S4(S4(i).ch).e=S4(S4(i).ch).e-ETX*L1;  %CH接收节点的临时加入请求-219-1-2 
                for j=1:1:cluster-1
                    if C(j).id==S4(i).ch
                       for t=1:1:n    %将该节点记为CH的成员
                           if cm(j,t)==0
                              cm(j,t)=i;
                              break;   
                           end
                       end
                       for f=1:1:c
                           if occupy(i,f,r)==0 && occupy(S4(i).ch,f,r)==0 %表示该节点和CH的公共信道空闲-2019-4-24
                              ava(j,f)=ava(j,f)+1;
                           end
                       end
                       break;
                    end
                end
             end
          end
       end
   end

  %为每个CH选取簇信道，若在上面运行的簇成员数相等，则从这些信道中随机选取一条
  for j=1:1:cluster-1
      Tsu=0;  %记录可用信道向量中拥有某信道的成员节点数
      channel=zeros(1,c);
      no=0;  %记录拥有最多成员节点数的信道数量
      ce=0;
      for f=1:1:c
          if ava(j,f)>0
             if ava(j,f)>Tsu
                for t=1:1:c
                    channel(t)=0;
                end
                channel(1)=f;
                Tsu=ava(j,f);
             else
                 if ava(j,f)==Tsu
                    for t=1:1:c
                        if channel(t)==0
                           channel(t)=f;
                           break;
                        end
                    end
                 end
             end
          end
      end
      for f=1:1:c
          if channel(f)~=0
             no=no+1;
          end
      end
      if no==1
         avae(j)=channel(1);
      else
          if no>1
             ce=randi(no,1,1);
             avae(j)=channel(ce);
          end
      end
  end
  
  %初步确定各簇的成员节点
  for j=1:1:cluster-1
      if avae(j)~=0  %必须是有可用信道的簇才行-2019-5-28
         for g=1:1:n
             if cm(j,g)~=0 && S4(cm(j,g)).e>0
                if occupy(cm(j,g),avae(j),r)==0  %说明该节点是有效的簇成员-2019-4-24
                   for h=1:1:n
                       if cme(j,h)==0
                          cme(j,h)=cm(j,g);
                          break;
                       end
                   end
                end
             end
         end
      end
  end

  %寻找没有找到CH的节点
  found=zeros(1,n);
  for i=1:1:n
      if S4(i).type=='C' && S4(i).e>0
         found(i)=1;
      else
          for j=1:1:cluster-1
              for g=1:1:n
                  if cme(j,g)==i && S4(i).e>0
                     found(i)=1;
                     break;   
                  end
              end
          end
      end
  end

  %统计找到CH的节点数
  findch=0;
  for i=1:1:n
      if found(i)==1
         findch=findch+1;
      end
  end
  %findch
  %如果存在没有找到CH的节点，则为其进行二次CH选取
  if findch~=n-dead1
     for i=1:1:n
         if found(i)==0 && S4(i).e>0
            che=0;
            distance2=2000;
            for j=1:1:cluster-1
                if avae(j)~=0 && S4(C(j).id).e>0
                   if occupy(i,avae(j),r)==0  %说明该节点的该信道可用，则可以进行距离的判断-2019-4-24
                      if sqrt((S4(i).xd-C(j).xd)^2+(S4(i).yd-C(j).yd)^2)<distance2
                         distance2=sqrt((S4(i).xd-C(j).xd)^2+(S4(i).yd-C(j).yd)^2);
                         che=j; %记录所属簇的簇号
                      end
                   end
               end
            end
            if che~=0 && distance2<=nodetransmissionrange  %补充：必须保证簇内通信距离小于等于节点的传输范围-2019-1-3
               found(i)=1;
               for g=1:1:n
                   if cme(che,g)==0
                      cme(che,g)=i;
                      break;
                   end
               end
            end
         end
     end
  end
  
  %计算各节点的剩余能量
  for j=1:1:cluster-1
      for g=1:1:n
          if cme(j,g)~=0 && S4(cme(j,g)).e>0
             MCogLEACH_overheadofcluster1=MCogLEACH_overheadofcluster1+1; %每个最终的簇成员都会向CH发送确认请求消息，开销加1-2019-2-19
             S4(cme(j,g)).e=S4(cme(j,g)).e-ETX*L1; %成员节点要接收CH发送的TDMA调度-2019-1-2
             d=sqrt((S4(cme(j,g)).xd-C(j).xd)^2+(S4(cme(j,g)).yd-C(j).yd)^2);  %计算节点与CH间的距离
             if d>=d0
                S4(cme(j,g)).e=S4(cme(j,g)).e-(ETX+Emp*d^4)*(L+L1); %最终的簇成员向CH发送最终的加入请求及数据-2019-1-2
                S4(cme(j,g)).ex=(ETX+Emp*d^4)*(L+L1);%CMs向所属CH传输数据消耗的能量
             else
                 S4(cme(j,g)).e=S4(cme(j,g)).e-(ETX+Efs*d^2)*(L+L1);%最终的簇成员向CH发送最终的加入请求及数据-2019-1-2
                 S4(cme(j,g)).ex=(ETX+Efs*d^2)*(L+L1);
             end
             S4(C(j).id).e=S4(C(j).id).e-ETX*L1; %CH接收簇成员的最终加入请求-2019-1-2
             S4(C(j).id).ex=0;
          end
      end
  end   
 for i=1:1:n
     if S4(i).e>=0
        MCogLEACH_EnergyConsumption(i)=MCogLEACH_Previousenergy(i)-S4(i).e; %每个节点的能耗，包括CMs向sink发送加入请求及数据，和CHs接收CMs的加入请求
        MCogLEACH_TotalEnergyConsumption1=MCogLEACH_TotalEnergyConsumption1+MCogLEACH_EnergyConsumption(i);%每轮所有节点总能耗，分簇的能耗，此时CHs还没向sink传输数据
     end
 end
% end%%%%%%%%%%%%%%%%

 for i=1:1:n
     S4(i).enirs=S4(i).enirs-((S4(i).echu)-(S4(i).e));
     S4(i).eab=S4(i).eab-((S4(i).echu)-(S4(i).e));
     S4(i).ep=S4(i).ep-((S4(i).echu)-(S4(i).e));
     S4(i).es=S4(i).es-((S4(i).echu)-(S4(i).e));
     S4(i).eu=S4(i).eu-((S4(i).echu)-(S4(i).e));
     S4(i).ed=S4(i).ed-((S4(i).echu)-(S4(i).e));
     S4(i).er=S4(i).er-((S4(i).echu)-(S4(i).e));
     S4(i).eg=S4(i).eg-((S4(i).echu)-(S4(i).e));
 end

 Kcluster=cluster-1;
 CHpositionx=[];
 CHpositiony=[];
 ECM1=[];
 ECM=0;
 CRSNspositionx=[];
 CRSNspositiony=[];
 for i=1:1:n
     if S4(i).type=='C'
         CHpositionx=[CHpositionx S4(i).xd];%CH节点坐标
         CHpositiony=[CHpositiony S4(i).yd];
     else 
         ECM1=[ECM1 S4(i).ex];
         ECM=ECM+S4(i).ex;
     end
 end
 for i=1:1:n
      CRSNspositionx=[CRSNspositionx S4(i).xd];%CRSNs坐标
      CRSNspositiony=[CRSNspositiony S4(i).yd];
      N=length(CRSNspositionx);
 end
 Esink=Kcluster*ETX*L;
 ECH_intra=(N-Kcluster)*(ETX+EDA)*L; 
 t0=0.5;%sink辐射时间1s
 t1=0.001;%CH k上行数据传输时长0.01s  此处的t1为原文的taok  taok=L/Rs=1000/10^6=0.001s
 SNR=db2pow(30);%30dB
 Bt=100000; %信道带宽  Rb=Blog2(1+SNR),Rb=1Mbps,SNR=30dB,推出B=1.0033e+05
 R=Bt*log2(1+SNR);
 tintra=(N/Kcluster-1)*(L/(Bt*log2(1+SNR)));
 T=Kcluster*t1+t0+tintra;
 Rtotal=((Bt*log2(1+SNR))*Kcluster*tintra+(t1*Kcluster)*R)/(T-t0);
 %***************各CHs上行数据传输的能耗*********************
 eem=xlsread('data.xlsx','B15:CW15');
 eemNIRS=xlsread('data.xlsx','B16:CW16');
 eemEb=xlsread('data.xlsx','B17:CW17');
 eemP=xlsread('data.xlsx','B18:CW18');
 eemS=xlsread('data.xlsx','B19:CW19');
 eemU=xlsread('data.xlsx','B20:CW20');
 eemD=xlsread('data.xlsx','B21:CW21');
 eemR=xlsread('data.xlsx','B22:CW22');
 eemG=xlsread('data.xlsx','B23:CW23');
 %*************上行数据传输阶段总功耗****************************
 ESS=xlsread('data.xlsx','B28:CW28');
 ESSNIRS=xlsread('data.xlsx','B29:CW29');
 ESSEb=xlsread('data.xlsx','B30:CW30');
 ESSP=xlsread('data.xlsx','B31:CW31');
 ESSS=xlsread('data.xlsx','B32:CW32');
 ESSU=xlsread('data.xlsx','B33:CW33');
 ESSD=xlsread('data.xlsx','B34:CW34');
 ESSR=xlsread('data.xlsx','B35:CW35');
 ESSG=xlsread('data.xlsx','B36:CW36');
 %如果簇信道在本轮结束前被PUs索回，则数据收集失败-2019-4-24;

% for i=1:1:cluster-1
%     distance(i)=sqrt((C(i).xd-S(n+1).xd)^2+(C(i).yd-S(n+1).yd)^2);  %看CHs和sink间的距离
% end

 ES=0;
 ESNIRS=0;
 ESEb=0;
 ESP=0;
 ESSI=0;
 ESU=0;
 ESD=0;
 ESR=0;
 ESG=0;
  for i=1:1:cluster-1
      if avae(i)~=0 && S4(C(i).id).e>0
         %CH向sink发送数据
         distance=sqrt((C(i).xd-S(n+1).xd)^2+(C(i).yd-S(n+1).yd)^2); %计算簇头到sink节点的距离
%          if distance<=nodetransmissionrange%如果CH到sink的距离在节点传输范围内，则按实际距离来计算能耗；否则按照传输范围来计算能耗-2019-12-8
%             if (distance>=d0)
%                 S4(C(i).id).e=S4(C(i).id).e-((ETX+EDA)*L+Emp*L*distance^4);%向sink传输数据
%             else
%                 S4(C(i).id).e=S4(C(i).id).e-((ETX+EDA)*L+Efs*L*distance^2);
%             end
            S4(C(i).id).e=S4(C(i).id).e-((ETX+EDA)*L+eem(i));%CHs向sink传输数据
            ES=ES+ESS(i);
%          else
%              if nodetransmissionrange>=d0
%                 S4(C(i).id).e=S4(C(i).id).e-((ETX+EDA)*L+Emp*L*nodetransmissionrange^4);
%              else
%                  S4(C(i).id).e=S4(C(i).id).e-((ETX+EDA)*L+Efs*L*nodetransmissionrange^2);
%              end
%              S4(C(i).id).e=S4(C(i).id).e-((ETX+EDA)*L+Efs*L*nodetransmissionrange^2);
%          end
         if willoccupy(C(i).id,avae(i),r)==1 || distance>nodetransmissionrange %如果CH的簇信道会被PUs索回或CH到sink的距离大于节点的传输范围，则整个簇内的传输都是失败的-2019-12-8
            for k=1:1:n
                if cme(i,k)~=0
                   found(cme(i,k))=0;
                end
            end
            found(C(i).id)=0;  %簇头的数据收集也是无效的-2019-1-2
         else
             for k=1:1:n
                 if cme(i,k)~=0
                    if S4(cme(i,k)).e>0
                       if willoccupy(cme(i,k),avae(i),r)==0 %如果簇成员的簇信道会被PUs索回，则该节点向CH的传输都是失败的-2019-4-24
                          found(cme(i,k))=1;
                       else
                           found(cme(i,k))=0;
                       end
                    else
                        found(cme(i,k))=0;
                    end
                 end
             end
         end
         if willoccupy(C(i).id,avae(i),r)==0
            for k=1:1:n
                 if cme(i,k)~=0 && S4(cme(i,k)).e>0
                    if willoccupy(cme(i,k),avae(i),r)==0 %如果信道没有被PU索回，则CH接收并聚合来自CM的数据包-2019-12-8
                       S4(C(i).id).e=S4(C(i).id).e-(ETX+EDA)*L;
                    end
                 end
            end
         end
      end
      if avae(i)~=0 && S4(C(i).id).enirs>0  %%****************************无IRS**********************************
         %CH向sink发送数据
         distance=sqrt((C(i).xd-S(n+1).xd)^2+(C(i).yd-S(n+1).yd)^2); %计算簇头到sink节点的距离
         S4(C(i).id).enirs=S4(C(i).id).enirs-((ETX+EDA)*L+eemNIRS(i));
         ESNIRS=ESNIRS+ESSNIRS(i);
         if willoccupy(C(i).id,avae(i),r)==1 || distance>nodetransmissionrange %如果CH的簇信道会被PUs索回或CH到sink的距离大于节点的传输范围，则整个簇内的传输都是失败的-2019-12-8
            for k=1:1:n
                if cme(i,k)~=0
                   found(cme(i,k))=0;
                end
            end
            found(C(i).id)=0;  %簇头的数据收集也是无效的-2019-1-2
         else
             for k=1:1:n
                 if cme(i,k)~=0
                    if S4(cme(i,k)).enirs>0
                       if willoccupy(cme(i,k),avae(i),r)==0 %如果簇成员的簇信道会被PUs索回，则该节点向CH的传输都是失败的-2019-4-24
                          found(cme(i,k))=1;
                       else
                           found(cme(i,k))=0;
                       end
                    else
                        found(cme(i,k))=0;
                    end
                 end
             end
         end
         if willoccupy(C(i).id,avae(i),r)==0
            for k=1:1:n
                 if cme(i,k)~=0 && S4(cme(i,k)).enirs>0
                    if willoccupy(cme(i,k),avae(i),r)==0 %如果信道没有被PU索回，则CH接收并聚合来自CM的数据包-2019-12-8
                       S4(C(i).id).enirs=S4(C(i).id).enirs-(ETX+EDA)*L;
                    end
                 end
            end
         end
      end
      if avae(i)~=0 && S4(C(i).id).eab>0  %%*****************************净能量收益*****************************************
         %CH向sink发送数据
         distance=sqrt((C(i).xd-S(n+1).xd)^2+(C(i).yd-S(n+1).yd)^2); %计算簇头到sink节点的距离
         S4(C(i).id).eab=S4(C(i).id).eab-((ETX+EDA)*L+eemEb(i));
         ESEb=ESEb+ESSEb(i);
         if willoccupy(C(i).id,avae(i),r)==1 || distance>nodetransmissionrange %如果CH的簇信道会被PUs索回或CH到sink的距离大于节点的传输范围，则整个簇内的传输都是失败的-2019-12-8
            for k=1:1:n
                if cme(i,k)~=0
                   found(cme(i,k))=0;
                end
            end
            found(C(i).id)=0;  %簇头的数据收集也是无效的-2019-1-2
         else
             for k=1:1:n
                 if cme(i,k)~=0
                    if S4(cme(i,k)).eab>0
                       if willoccupy(cme(i,k),avae(i),r)==0 %如果簇成员的簇信道会被PUs索回，则该节点向CH的传输都是失败的-2019-4-24
                          found(cme(i,k))=1;
                       else
                           found(cme(i,k))=0;
                       end
                    else
                        found(cme(i,k))=0;
                    end
                 end
             end
         end
         if willoccupy(C(i).id,avae(i),r)==0
            for k=1:1:n
                 if cme(i,k)~=0 && S4(cme(i,k)).eab>0
                    if willoccupy(cme(i,k),avae(i),r)==0 %如果信道没有被PU索回，则CH接收并聚合来自CM的数据包-2019-12-8
                       S4(C(i).id).eab=S4(C(i).id).eab-(ETX+EDA)*L;
                    end
                 end
            end
         end
      end
      if avae(i)~=0 && S4(C(i).id).ep>0  %%*****************************被动*****************************************
         %CH向sink发送数据
         distance=sqrt((C(i).xd-S(n+1).xd)^2+(C(i).yd-S(n+1).yd)^2); %计算簇头到sink节点的距离
         S4(C(i).id).ep=S4(C(i).id).ep-((ETX+EDA)*L+eemP(i));
         ESP=ESP+ESSP(i);
         if willoccupy(C(i).id,avae(i),r)==1 || distance>nodetransmissionrange %如果CH的簇信道会被PUs索回或CH到sink的距离大于节点的传输范围，则整个簇内的传输都是失败的-2019-12-8
            for k=1:1:n
                if cme(i,k)~=0
                   found(cme(i,k))=0;
                end
            end
            found(C(i).id)=0;  %簇头的数据收集也是无效的-2019-1-2
         else
             for k=1:1:n
                 if cme(i,k)~=0
                    if S4(cme(i,k)).ep>0
                       if willoccupy(cme(i,k),avae(i),r)==0 %如果簇成员的簇信道会被PUs索回，则该节点向CH的传输都是失败的-2019-4-24
                          found(cme(i,k))=1;
                       else
                           found(cme(i,k))=0;
                       end
                    else
                        found(cme(i,k))=0;
                    end
                 end
             end
         end
         if willoccupy(C(i).id,avae(i),r)==0
            for k=1:1:n
                 if cme(i,k)~=0 && S4(cme(i,k)).ep>0
                    if willoccupy(cme(i,k),avae(i),r)==0 %如果信道没有被PU索回，则CH接收并聚合来自CM的数据包-2019-12-8
                       S4(C(i).id).ep=S4(C(i).id).ep-(ETX+EDA)*L;
                    end
                 end
            end
         end
      end
      if avae(i)~=0 && S4(C(i).id).es>0  %%*****************************单天线*****************************************
         %CH向sink发送数据
         distance=sqrt((C(i).xd-S(n+1).xd)^2+(C(i).yd-S(n+1).yd)^2); %计算簇头到sink节点的距离
         S4(C(i).id).es=S4(C(i).id).es-((ETX+EDA)*L+eemS(i));
         ESSI=ESSI+ESSS(i);
         if willoccupy(C(i).id,avae(i),r)==1 || distance>nodetransmissionrange %如果CH的簇信道会被PUs索回或CH到sink的距离大于节点的传输范围，则整个簇内的传输都是失败的-2019-12-8
            for k=1:1:n
                if cme(i,k)~=0
                   found(cme(i,k))=0;
                end
            end
            found(C(i).id)=0;  %簇头的数据收集也是无效的-2019-1-2
         else
             for k=1:1:n
                 if cme(i,k)~=0
                    if S4(cme(i,k)).es>0
                       if willoccupy(cme(i,k),avae(i),r)==0 %如果簇成员的簇信道会被PUs索回，则该节点向CH的传输都是失败的-2019-4-24
                          found(cme(i,k))=1;
                       else
                           found(cme(i,k))=0;
                       end
                    else
                        found(cme(i,k))=0;
                    end
                 end
             end
         end
         if willoccupy(C(i).id,avae(i),r)==0
            for k=1:1:n
                 if cme(i,k)~=0 && S4(cme(i,k)).es>0
                    if willoccupy(cme(i,k),avae(i),r)==0 %如果信道没有被PU索回，则CH接收并聚合来自CM的数据包-2019-12-8
                       S4(C(i).id).es=S4(C(i).id).es-(ETX+EDA)*L;
                    end
                 end
            end
         end
      end
      if avae(i)~=0 && S4(C(i).id).eu>0  %%*****************************仅优化上行*****************************************
         %CH向sink发送数据
         distance=sqrt((C(i).xd-S(n+1).xd)^2+(C(i).yd-S(n+1).yd)^2); %计算簇头到sink节点的距离        
         S4(C(i).id).eu=S4(C(i).id).eu-((ETX+EDA)*L+eemU(i));
         ESU=ESU+ESSU(i);
         if willoccupy(C(i).id,avae(i),r)==1 || distance>nodetransmissionrange %如果CH的簇信道会被PUs索回或CH到sink的距离大于节点的传输范围，则整个簇内的传输都是失败的-2019-12-8
            for k=1:1:n
                if cme(i,k)~=0
                   found(cme(i,k))=0;
                end
            end
            found(C(i).id)=0;  %簇头的数据收集也是无效的-2019-1-2
         else
             for k=1:1:n
                 if cme(i,k)~=0
                    if S4(cme(i,k)).eu>0
                       if willoccupy(cme(i,k),avae(i),r)==0 %如果簇成员的簇信道会被PUs索回，则该节点向CH的传输都是失败的-2019-4-24
                          found(cme(i,k))=1;
                       else
                           found(cme(i,k))=0;
                       end
                    else
                        found(cme(i,k))=0;
                    end
                 end
             end
         end
         if willoccupy(C(i).id,avae(i),r)==0
            for k=1:1:n
                 if cme(i,k)~=0 && S4(cme(i,k)).eu>0
                    if willoccupy(cme(i,k),avae(i),r)==0 %如果信道没有被PU索回，则CH接收并聚合来自CM的数据包-2019-12-8
                       S4(C(i).id).eu=S4(C(i).id).eu-(ETX+EDA)*L;
                    end
                 end
            end
         end
      end
      if avae(i)~=0 && S4(C(i).id).ed>0  %%*****************************仅优化下行*****************************************
         %CH向sink发送数据
         distance=sqrt((C(i).xd-S(n+1).xd)^2+(C(i).yd-S(n+1).yd)^2); %计算簇头到sink节点的距离        
         S4(C(i).id).ed=S4(C(i).id).ed-((ETX+EDA)*L+eemD(i));
         ESD=ESD+ESSD(i);
         if willoccupy(C(i).id,avae(i),r)==1 || distance>nodetransmissionrange %如果CH的簇信道会被PUs索回或CH到sink的距离大于节点的传输范围，则整个簇内的传输都是失败的-2019-12-8
            for k=1:1:n
                if cme(i,k)~=0
                   found(cme(i,k))=0;
                end
            end
            found(C(i).id)=0;  %簇头的数据收集也是无效的-2019-1-2
         else
             for k=1:1:n
                 if cme(i,k)~=0
                    if S4(cme(i,k)).ed>0
                       if willoccupy(cme(i,k),avae(i),r)==0 %如果簇成员的簇信道会被PUs索回，则该节点向CH的传输都是失败的-2019-4-24
                          found(cme(i,k))=1;
                       else
                           found(cme(i,k))=0;
                       end
                    else
                        found(cme(i,k))=0;
                    end
                 end
             end
         end
         if willoccupy(C(i).id,avae(i),r)==0
            for k=1:1:n
                 if cme(i,k)~=0 && S4(cme(i,k)).ed>0
                    if willoccupy(cme(i,k),avae(i),r)==0 %如果信道没有被PU索回，则CH接收并聚合来自CM的数据包-2019-12-8
                       S4(C(i).id).ed=S4(C(i).id).ed-(ETX+EDA)*L;
                    end
                 end
            end
         end
      end
      if avae(i)~=0 && S4(C(i).id).er>0  %%*****************************随机*****************************************
         %CH向sink发送数据
         distance=sqrt((C(i).xd-S(n+1).xd)^2+(C(i).yd-S(n+1).yd)^2); %计算簇头到sink节点的距离        
         S4(C(i).id).er=S4(C(i).id).er-((ETX+EDA)*L+eemR(i));
         ESR=ESR+ESSR(i);
         if willoccupy(C(i).id,avae(i),r)==1 || distance>nodetransmissionrange %如果CH的簇信道会被PUs索回或CH到sink的距离大于节点的传输范围，则整个簇内的传输都是失败的-2019-12-8
            for k=1:1:n
                if cme(i,k)~=0
                   found(cme(i,k))=0;
                end
            end
            found(C(i).id)=0;  %簇头的数据收集也是无效的-2019-1-2
         else
             for k=1:1:n
                 if cme(i,k)~=0
                    if S4(cme(i,k)).er>0
                       if willoccupy(cme(i,k),avae(i),r)==0 %如果簇成员的簇信道会被PUs索回，则该节点向CH的传输都是失败的-2019-4-24
                          found(cme(i,k))=1;
                       else
                           found(cme(i,k))=0;
                       end
                    else
                        found(cme(i,k))=0;
                    end
                 end
             end
         end
         if willoccupy(C(i).id,avae(i),r)==0
            for k=1:1:n
                 if cme(i,k)~=0 && S4(cme(i,k)).er>0
                    if willoccupy(cme(i,k),avae(i),r)==0 %如果信道没有被PU索回，则CH接收并聚合来自CM的数据包-2019-12-8
                       S4(C(i).id).er=S4(C(i).id).er-(ETX+EDA)*L;
                    end
                 end
            end
         end
      end
      if avae(i)~=0 && S4(C(i).id).eg>0  %%*****************************共用*****************************************
         %CH向sink发送数据
         distance=sqrt((C(i).xd-S(n+1).xd)^2+(C(i).yd-S(n+1).yd)^2); %计算簇头到sink节点的距离        
         S4(C(i).id).eg=S4(C(i).id).eg-((ETX+EDA)*L+eemG(i));
         ESG=ESG+ESSG(i);
         if willoccupy(C(i).id,avae(i),r)==1 || distance>nodetransmissionrange %如果CH的簇信道会被PUs索回或CH到sink的距离大于节点的传输范围，则整个簇内的传输都是失败的-2019-12-8
            for k=1:1:n
                if cme(i,k)~=0
                   found(cme(i,k))=0;
                end
            end
            found(C(i).id)=0;  %簇头的数据收集也是无效的-2019-1-2
         else
             for k=1:1:n
                 if cme(i,k)~=0
                    if S4(cme(i,k)).eg>0
                       if willoccupy(cme(i,k),avae(i),r)==0 %如果簇成员的簇信道会被PUs索回，则该节点向CH的传输都是失败的-2019-4-24
                          found(cme(i,k))=1;
                       else
                           found(cme(i,k))=0;
                       end
                    else
                        found(cme(i,k))=0;
                    end
                 end
             end
         end
         if willoccupy(C(i).id,avae(i),r)==0
            for k=1:1:n
                 if cme(i,k)~=0 && S4(cme(i,k)).eg>0
                    if willoccupy(cme(i,k),avae(i),r)==0 %如果信道没有被PU索回，则CH接收并聚合来自CM的数据包-2019-12-8
                       S4(C(i).id).eg=S4(C(i).id).eg-(ETX+EDA)*L;
                    end
                 end
            end
         end
      end
  end

%   for i=1:1:n
%       if S4(i).e>=0
%          MCogLEACH_EnergyConsumptionCH(i)=MCogLEACH_Previousenergy(i)-MCogLEACH_EnergyConsumption(i)-S4(i).e; %每个节点的能耗，包括CMs向sink发送加入请求及数据，和CHs接收CMs的加入请求还有CH向sink传输数据，这个公式算的是CHs聚合及向sink传输数据的能耗
%          MCogLEACH_TotalEnergyConsumptionCH1=MCogLEACH_TotalEnergyConsumptionCH1+MCogLEACH_EnergyConsumptionCH(i);%CHs聚合及向sink传输数据的总能耗
%       end
%   end
%   MCogLEACH_TotalEnergyConsumptionCH2=MCogLEACH_TotalEnergyConsumptionCH1+MCogLEACH_TotalEnergyConsumption1;%每轮所有节点总能耗，分簇的能耗，此时CHs已向sink传输数据

  findch=0;
  for i=1:1:n
      if found(i)==1 %节点i成功传输
         findch=findch+1;
      end
  end
  MCogLEACH_NumberofAcquisiton1=findch; %本轮能进行有效数据搜集的节点数量-2019-1-2
  if dead1~=n   %dead1不等于n
     MCogLEACH_RatioofAcquisiton1=MCogLEACH_NumberofAcquisiton1/(n-dead1); %包递交率
  end

  if deadnirs1~=n
     MCogLEACH_RatioofAcquisitonnirs1=MCogLEACH_NumberofAcquisiton1/(n-deadnirs1); %包递交率***无IRS******************
  end

  if deadab1~=n
     MCogLEACH_RatioofAcquisitonab1=MCogLEACH_NumberofAcquisiton1/(n-deadab1); %包递交率***净能量收益*******************
  end

  if deadp1~=n
     MCogLEACH_RatioofAcquisitonp1=MCogLEACH_NumberofAcquisiton1/(n-deadp1); %包递交率***被动IRS*******************
  end

  if deads1~=n
     MCogLEACH_RatioofAcquisitons1=MCogLEACH_NumberofAcquisiton1/(n-deads1); %包递交率***单天线*******************
  end

  if deadu1~=n
     MCogLEACH_RatioofAcquisitonu1=MCogLEACH_NumberofAcquisiton1/(n-deadu1); %包递交率***仅优化上行*******************
  end

  if deadd1~=n
     MCogLEACH_RatioofAcquisitond1=MCogLEACH_NumberofAcquisiton1/(n-deadd1); %包递交率***仅优化下行*******************
  end

  if deadr1~=n
     MCogLEACH_RatioofAcquisitonr1=MCogLEACH_NumberofAcquisiton1/(n-deadr1); %包递交率***随机*******************
  end

  if deadg1~=n
     MCogLEACH_RatioofAcquisitong1=MCogLEACH_NumberofAcquisiton1/(n-deadg1); %包递交率***共用*******************
  end
  %**********************************************下行EH阶段系统功耗**********************************************
  EXX=xlsread('data.xlsx','B40:B40');
  EXXNIRS=xlsread('data.xlsx','B41:B41');
  EXXEb=xlsread('data.xlsx','B42:B42');
  EXXP=xlsread('data.xlsx','B43:B43');
  EXXS=xlsread('data.xlsx','B44:B44');
  EXXU=xlsread('data.xlsx','B45:B45');
  EXXD=xlsread('data.xlsx','B46:B46');
  EXXR=xlsread('data.xlsx','B47:B47');
  EXXG=xlsread('data.xlsx','B48:B48');
  %******************************************************能效***************************************************
  EEm=Rtotal/((ES+Esink+ECM+ECH_intra+EXX)-(sum(EH_in)));
  EEmNIRS=Rtotal/((ESNIRS+Esink+ECM+ECH_intra+EXXNIRS)-(sum(EH_innirs)));
  EEmEb=Rtotal/((ESEb+Esink+ECM+ECH_intra+EXXEb)-(sum(EH_inab)));
  EEmP=Rtotal/((ESP+Esink+ECM+ECH_intra+EXXP)-(sum(EH_inp)));
  EEmS=Rtotal/((ESSI+Esink+ECM+ECH_intra+EXXS)-(sum(EH_ins)));
  EEmU=Rtotal/((ESU+Esink+ECM+ECH_intra+EXXU)-(sum(EH_inu)));
  EEmD=Rtotal/((ESD+Esink+ECM+ECH_intra+EXXD)-(sum(EH_ind)));
  EEmR=Rtotal/((ESR+Esink+ECM+ECH_intra+EXXR)-(sum(EH_inr)));
  EEmG=Rtotal/((ESG+Esink+ECM+ECH_intra+EXXG)-(sum(EH_ing)));
  %**********************************************EH-CRSNs系统的能效乘包递交率**************************************
  MCogLEACH_EnergyEfficiency1=MCogLEACH_RatioofAcquisiton1*EEm; 
  MCogLEACH_EnergyEfficiencyNIRS1=MCogLEACH_RatioofAcquisitonnirs1*EEmNIRS;
  MCogLEACH_EnergyEfficiencyEb1=MCogLEACH_RatioofAcquisitonab1*EEmEb; 
  MCogLEACH_EnergyEfficiencyP1=MCogLEACH_RatioofAcquisitonp1*EEmP;  
  MCogLEACH_EnergyEfficiencyS1=MCogLEACH_RatioofAcquisitons1*EEmS;
  MCogLEACH_EnergyEfficiencyU1=MCogLEACH_RatioofAcquisitonu1*EEmU;
  MCogLEACH_EnergyEfficiencyD1=MCogLEACH_RatioofAcquisitond1*EEmD;
  MCogLEACH_EnergyEfficiencyR1=MCogLEACH_RatioofAcquisitonr1*EEmR;
  MCogLEACH_EnergyEfficiencyG1=MCogLEACH_RatioofAcquisitong1*EEmG; 
  %********************************************************时延的第二部分——稳态传输时延-2021-12-14***************************
%   steadystatedelay=0;
%   MCogLEACH_Acx1=zeros(1,n); %用于存放当前活着的CH节点的横纵坐标，以便调用delay函数计算平均时延
%   MCogLEACH_Acy1=zeros(1,n);
%   MCogLEACH_effectiveCH=zeros(1,n); %用来存放有效收集数据的CH标志，如果是有效收集数据的CH，则相应标志位置1——2021-12-14
%   NumberofCMs=zeros(1,n);%用于存放簇成员数
%   NumberofeffectiveCMs=zeros(1,n);%用于存放能有效收集数据的簇成员数
%   NofCH=0;  %记录所有当前活着的CH数目
%   NofeffectiveCH=0; %记录有效收集数据的CH数目-后加—2021-12-14
%   achannel=zeros(1,n);
%   for i=1:1:cluster-1
%       jump1=0;
%       if avae(i)~=0
%          NofCH=NofCH+1;
%          for j=1:1:n
%              if MCogLEACH_Acx1(j)==0
%                 jump1=j;
%                 break;
%              end
%          end
%          MCogLEACH_Acx1(jump1)=S4(C(i).id).xd;
%          MCogLEACH_Acy1(jump1)=S4(C(i).id).yd;
%          achannel(jump1)=avae(i);
%          if found(C(i).id)==1
%             MCogLEACH_effectiveCH(jump1)=1; %后加***
%             NofeffectiveCH=NofeffectiveCH+1;
%             for j=1:1:n
%                 if cme(i,j)~=0
%                    NumberofCMs(jump1)=NumberofCMs(jump1)+1;
%                    if found(cme(i,j))==1
%                       NumberofeffectiveCMs(jump1)=NumberofeffectiveCMs(jump1)+1;
%                    end
%                 end
%             end
%          end
%       end
%   end
%   if NofeffectiveCH>0 %只有当至少有一个有效收集数据的CH时才需要计算时延，否则不需要—2021-12-14
%      DELAY1=zeros(1,NofCH);
%      DELAY1=delay(NofCH,achannel,MCogLEACH_Acx1,MCogLEACH_Acy1,1,nodetransmissionrange);%传输1个数据包的时延是1ms
%      for i=1:1:NofCH
%          if MCogLEACH_effectiveCH(i)==1  %1ms时延
%             steadystatedelay=steadystatedelay+(DELAY1(i)+NumberofCMs(i))*(NumberofeffectiveCMs(i)+1);
%          end
%      end
%      if MCogLEACH_NumberofAcquisiton1~=0
%         MCogLEACH_Timedelay1=steadystatedelay/MCogLEACH_NumberofAcquisiton1+50+clusterconstructiondelay;  %每个包的平均时延包括频谱感知50ms，能量收集的时间0.2s，簇构建的时延和稳态传输的时延(200为能量收集时延，50为频谱感知)
%      end
%   end
  %*************************************************************第二部分时延计算完毕************************************************************************************
end
% for i=1:1:n
%     S4(i).e1=S4(i).e;
% end

dead=0;
for i=1:1:n
    if (S4(i).e<=0)
        dead=dead+1;
    end
end

MCogLEACH_Numberoflive1=n-dead;  %记录当前轮活着的节点总数-2018-8-5
% MCogLEACH_overheadofCH1=0; %本轮CH选取的开销等于0，因为所有节点的可用信道数总和是估计出来的，不需要统计确切值-2018-8-5

if (dead>=1)
    if (MCogLEACH_flag_first_dead==0)
        MCogLEACH_flag_first_dead=1;
        MCogLEACH_first_dead=r; 
    end
end
if (dead==n)
    if (MCogLEACH_flag_last_dead==0)
        MCogLEACH_flag_last_dead=1;
        MCogLEACH_last_dead=r; 
    end
end 
  
%%****************************************************无IRS******************************************************
deadnirs=0;
for i=1:1:n
    if (S4(i).enirs<=0)
        deadnirs=deadnirs+1;
    end
end

MCogLEACH_Numberoflivenirs1=n-deadnirs;  %记录当前轮活着的节点总数-2018-8-5
% MCogLEACH_overheadofCH1=0; %本轮CH选取的开销等于0，因为所有节点的可用信道数总和是估计出来的，不需要统计确切值-2018-8-5

if (deadnirs>=1)
    if (MCogLEACH_flag_first_deadnirs==0)
        MCogLEACH_flag_first_deadnirs=1;
        MCogLEACH_first_deadnirs=r; 
    end
end
if (deadnirs==n)
    if (MCogLEACH_flag_last_deadnirs==0)
        MCogLEACH_flag_last_deadnirs=1;
        MCogLEACH_last_deadnirs=r; 
    end
end 
%%****************************************************净能量收益******************************************************
deadab=0;
for i=1:1:n
    if (S4(i).eab<=0)
        deadab=deadab+1;
    end
end

MCogLEACH_Numberofliveab1=n-deadab;  %记录当前轮活着的节点总数-2018-8-5
% MCogLEACH_overheadofCH1=0; %本轮CH选取的开销等于0，因为所有节点的可用信道数总和是估计出来的，不需要统计确切值-2018-8-5

if (deadab>=1)
    if (MCogLEACH_flag_first_deadab==0)
        MCogLEACH_flag_first_deadab=1;
        MCogLEACH_first_deadab=r; 
    end
end
if (deadab==n)
    if (MCogLEACH_flag_last_deadab==0)
        MCogLEACH_flag_last_deadab=1;
        MCogLEACH_last_deadab=r; 
    end
end 
%%****************************************************被动IRS******************************************************
deadp=0;
for i=1:1:n
    if (S4(i).ep<=0)
        deadp=deadp+1;
    end
end

MCogLEACH_Numberoflivep1=n-deadp;  %记录当前轮活着的节点总数-2018-8-5
% MCogLEACH_overheadofCH1=0; %本轮CH选取的开销等于0，因为所有节点的可用信道数总和是估计出来的，不需要统计确切值-2018-8-5

if (deadp>=1)
    if (MCogLEACH_flag_first_deadp==0)
        MCogLEACH_flag_first_deadp=1;
        MCogLEACH_first_deadp=r; 
    end
end
if (deadp==n)
    if (MCogLEACH_flag_last_deadp==0)
        MCogLEACH_flag_last_deadp=1;
        MCogLEACH_last_deadp=r; 
    end
end 
%%****************************************************单天线******************************************************
deads=0;
for i=1:1:n
    if (S4(i).es<=0)
        deads=deads+1;
    end
end

MCogLEACH_Numberoflives1=n-deads;  %记录当前轮活着的节点总数-2018-8-5
% MCogLEACH_overheadofCH1=0; %本轮CH选取的开销等于0，因为所有节点的可用信道数总和是估计出来的，不需要统计确切值-2018-8-5

if (deads>=1)
    if (MCogLEACH_flag_first_deads==0)
        MCogLEACH_flag_first_deads=1;
        MCogLEACH_first_deads=r; 
    end
end
if (deads==n)
    if (MCogLEACH_flag_last_deads==0)
        MCogLEACH_flag_last_deads=1;
        MCogLEACH_last_deads=r; 
    end
end 
%%*******************************************************仅优化上行**************************************************
deadu=0;
for i=1:1:n
    if (S4(i).eu<=0)
        deadu=deadu+1;
    end
end
MCogLEACH_Numberofliveu1=n-deadu;  %记录当前轮活着的节点总数-2018-8-5
% MCogLEACH_overheadofCH1=0; %本轮CH选取的开销等于0，因为所有节点的可用信道数总和是估计出来的，不需要统计确切值-2018-8-5

if (deadu>=1)
    if (MCogLEACH_flag_first_deadu==0)
        MCogLEACH_flag_first_deadu=1;
        MCogLEACH_first_deadu=r; 
    end
end
if (deadu==n)
    if (MCogLEACH_flag_last_deadu==0)
        MCogLEACH_flag_last_deadu=1;
        MCogLEACH_last_deadu=r; 
    end
end
%%*******************************************************仅优化下行**************************************************
deadd=0;
for i=1:1:n
    if (S4(i).ed<=0)
        deadd=deadd+1;
    end
end
MCogLEACH_Numberoflived1=n-deadd;  %记录当前轮活着的节点总数-2018-8-5
% MCogLEACH_overheadofCH1=0; %本轮CH选取的开销等于0，因为所有节点的可用信道数总和是估计出来的，不需要统计确切值-2018-8-5

if (deadd>=1)
    if (MCogLEACH_flag_first_deadd==0)
        MCogLEACH_flag_first_deadd=1;
        MCogLEACH_first_deadd=r; 
    end
end
if (deadd==n)
    if (MCogLEACH_flag_last_deadd==0)
        MCogLEACH_flag_last_deadd=1;
        MCogLEACH_last_deadd=r; 
    end
end 
%%*******************************************************随机**************************************************
deadr=0;
for i=1:1:n
    if (S4(i).er<=0)
        deadr=deadr+1;
    end
end
MCogLEACH_Numberofliver1=n-deadr;  %记录当前轮活着的节点总数-2018-8-5
% MCogLEACH_overheadofCH1=0; %本轮CH选取的开销等于0，因为所有节点的可用信道数总和是估计出来的，不需要统计确切值-2018-8-5

if (deadr>=1)
    if (MCogLEACH_flag_first_deadr==0)
        MCogLEACH_flag_first_deadr=1;
        MCogLEACH_first_deadr=r; 
    end
end
if (deadr==n)
    if (MCogLEACH_flag_last_deadr==0)
        MCogLEACH_flag_last_deadr=1;
        MCogLEACH_last_deadr=r; 
    end
end 
%%*******************************************************共用**************************************************
deadg=0;
for i=1:1:n
    if (S4(i).eg<=0)
        deadg=deadg+1;
    end
end
MCogLEACH_Numberofliveg1=n-deadg;  %记录当前轮活着的节点总数-2018-8-5
% MCogLEACH_overheadofCH1=0; %本轮CH选取的开销等于0，因为所有节点的可用信道数总和是估计出来的，不需要统计确切值-2018-8-5

if (deadg>=1)
    if (MCogLEACH_flag_first_deadg==0)
        MCogLEACH_flag_first_deadg=1;
        MCogLEACH_first_deadg=r; 
    end
end
if (deadg==n)
    if (MCogLEACH_flag_last_deadg==0)
        MCogLEACH_flag_last_deadg=1;
        MCogLEACH_last_deadg=r; 
    end
end 
for i=1:1:n
    S4(i).ehou=S4(i).e;
    S4(i).enirshou=S4(i).enirs;
    S4(i).eabhou=S4(i).eab;
    S4(i).ephou=S4(i).ep;
    S4(i).eshou=S4(i).es;
    S4(i).euhou=S4(i).eu;
    S4(i).edhou=S4(i).ed;
    S4(i).erhou=S4(i).er;
    S4(i).eghou=S4(i).eg;
end

for i=1:1:n
    S4(i).typehou=S4(i).type;
end

for i=1:1:n
    S4(i).chhou=S4(i).ch;
end