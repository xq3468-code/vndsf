function [v0] = hSCA_solving(g, hr_n, hd_n, M,  N, PS, Pirs, pout, derta1_2, derta3n_2, w0, t0, yita)
        phi0_=unifrnd(0,2*pi,M,1);
        v0_=cos(phi0_)+sin(phi0_)*1j;  %v0_为原文的v0_q-1，即SCA算法的初始迭代点 M*1
        w01=(norm(w0))^2;  %w01为原文的w0_，即||w0||^2
        Eeh=t0*(PS*w01+M*Pirs); 
        g0_=(w0)'*g;  %1*M
        G0=PS*diag((abs(g0_)).^2)+derta1_2*eye(M);   %M*M
        for n=1:N
            hdn_(:,n)=(w0)'*(hd_n(:,n));  %1*1
            bn(:,n)=diag((hr_n(:,n))')*(g0_)';  %M*1
            Hr_n(:,:,n)=diag((abs(hr_n(:,n))).^2);  %M*M
        end
        Sh=0;
        for n=1:N
            Sh1(:,:,n)=bn(:,n)*(bn(:,n))';
            Sh=Sh+Sh1(:,:,n);
        end
        SH=PS*Sh;
        PAI=0;
        for n=1:N
            PAI=PAI+Hr_n(:,:,n);
        end
        PA=derta1_2*PAI;
        Xi=0;
        for n=1:N
            Xi1(:,n)=bn(:,n)*hdn_(:,n);
            Xi=Xi+Xi1(:,n);
        end
        XI=PS*Xi;
        HD1=0;
        for n=1:N
            HD1=HD1+(abs(hdn_(:,n)))^2;
        end
        HD=PS*HD1;
        ZAO=0;
        for n=1:N
            ZAO=ZAO+derta3n_2;
        end
        cvx_begin quiet
            variable v01(M,1) complex
            find v01;
            subject to
            real(v01'*G0*v01)<=pout;
            for m=1:M
                2*real((v01(m))'*v0_(m))-(v0_(m))'*v0_(m)>=1;
            end
        cvx_end
        B11=[];
        for n=1:N
%             B11=[B11 (PS*(abs(hdn_(:,n)+(bn(:,n))'*v0_))^2+derta1_2*(v0_'*Hr_n(:,:,n)*v0_)+derta3n_2)];
            B11=[B11 (PS*(abs(hdn_(:,n)+(bn(:,n))'*v01))^2+derta1_2*(v01'*Hr_n(:,:,n)*v01)+derta3n_2)];
        end
        B_=sum(B11(1:N));
%         SS_=Eeh+t0*(v0_'*G0*v0_)-t0*yita*B_;
        SS_=Eeh+t0*(v01'*G0*v01)-t0*yita*B_;
        SSS=[];
        for Isca=1:10 %1:100  quiet
            cvx_begin quiet
                variable v0(M,1) complex;
%                 minimize real(square_pos(norm((v0'*G0), 2)))   %二范数求模求平方用square_pos(norm(x, 2))：||x||^2
%                 minimize real(t0*(v0'*G0*v0)-t0*yita*real(2*real(v0'*(SH*v0_+XI+PA*v0_))-(v0_)'*SH*v0_-(v0_)'*PA*v0_+HD+ZAO))
                minimize real(t0*(v0'*G0*v0)-t0*yita*real(2*real(v0'*(SH*v01+XI+PA*v01))-(v01)'*SH*v01-(v01)'*PA*v01+HD+ZAO))
                subject to 
                real(v0'*G0*v0)<=pout;
                for m=1:M
%                     2*real((v0(m))'*v0_(m))-(v0_(m))'*v0_(m)>=1;
                    2*real((v0(m))'*v01(m))-(v01(m))'*v01(m)>=1;
                end
            cvx_end
            BSS1=[];
            for n=1:N
                BSS1=[BSS1 ((PS*(abs(hdn_(:,n)+(bn(:,n))'*v0))^2+derta1_2*(v0'*Hr_n(:,:,n)*v0))+derta3n_2)];
            end
            BSS=sum(BSS1(1:N));
            SS=Eeh+t0*(v0'*G0*v0)-t0*yita*BSS;
            if mean(abs(SS-SS_))<1e-3 %1e-8
               break
            else
%                v0_=v0;
               v01=v0;
               SS_=SS;
            end
            SSS=[SSS SS];
        end
%         figure
%         plot(1:length(SSS),real(SSS));
end