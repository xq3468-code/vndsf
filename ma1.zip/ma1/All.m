% function [eem, EEm] = energy_efficiency(Kcluster, CHpositionx, CHpositiony, ECM, CRSNspositionx, CRSNspositiony, N, Esink, ECH_intra, L)
clear all
clc
pout=db2pow(8)/1000;%pout为5dBm 10^-2.5 10dBm:10^-2; PC=PDC=-10dBm=10^-4,pIRS=10dBm=0.01
PC=db2pow(-10)/1000;
PDC=db2pow(-10)/1000;
Pirs=PC+PDC;
PS=10; %PS为30dBm 10^0 , 40dBm:10W , 37dBm:10^0.7,46dBm:40W，此处的PA是原文的PS，下同
M=10; %反射单元数
lamuda=0.3333; %信号传输波长0.325,0.3333
C0=(lamuda/(4*pi))^2; 
Nt=4; %sink天线数量
Kcluster=20;%20个簇,sink(0,0,0),IRS(0,yIRS,dv),CHs(x(k),y(k),0)%%%%%%%%%%改变CHs数，ECM也要改
CHpositionx=xlsread('100jiedianECM.xlsx','C7:V7');%CH节点坐标
CHpositiony=xlsread('100jiedianECM.xlsx','C8:V8');
x=CHpositionx;
y=CHpositiony;
CRSNspositionx=xlsread('100jiedianECM.xlsx','C2:CX2');%CRSNs节点坐标
CRSNspositiony=xlsread('100jiedianECM.xlsx','C3:CX3');
x1=CRSNspositionx;
y1=CRSNspositiony;
Eelec=50*0.000000001;%发送和接收数据时电路能耗Eelec=50nJ/b 
Efs=10*0.000000000001;%发送时功率放大器功耗取决于距离，当小于参考距离d0时为10pJ/b/m2;大于参考距离d0时为0.0013pJ/b/m4
Emp=0.0013*0.000000000001;
EDA=5*0.000000001; %聚合数据时消耗能量为5nJ/b/packet
L=1000;%数据包大小1000bit,控制包大小100bit                              
N=100;%簇内CRSNs节点总数为100
ECM=xlsread('100jiedianECM.xlsx','C10:C10');  %20CHs  %ECM是从CogLEACH中算出来的，此处的ECM为原文的(N-K)*ECM
ECH_intra=((N/Kcluster)-1)*(Eelec+EDA)*L; %从CogLEACH里过来的ECH_intra是原文的K*ECH_intra
Esink=Kcluster*Eelec*L;
% Edt=Kcluster*Eelec*L+ECM+Kcluster*ECH_intra;
Edt=Esink+ECM+ECH_intra;
HIRS = 5; % IRS与平面的垂直距离
D0=1;%参考距离
derta2_2=10^-11; %噪声功率-80dBm:10^-11
derta1_2=10^-11;
derta3n_2=10^-11;
% 路损参数
alpha_SI = 2.3; %级联链路莱斯
alpha_IC = 2.3;
alpha_SC = 2.9; %直接链路自由空间
beta_SI = db2pow(3); %莱斯因子10  db2pow(3)
beta_IC = db2pow(3);
beta_SC = db2pow(3);
% www=[];
t0=0.5;%sink辐射时间1s
t1=0.001;%CH k上行数据传输时长0.01s  此处的t1为原文的taok  taok=L/Rs=1000/10^6=0.001s
SNR=db2pow(30);%30dB
Bt=100000; %信道带宽  Rb=Blog2(1+SNR),Rb=1Mbps,SNR=30dB,推出B=1.0033e+05
R=Bt*log2(1+SNR);
tintra=(N/Kcluster-1)*(L/(Bt*log2(1+SNR)));
T=Kcluster*t1+t0+tintra;
Rtotal=((Bt*log2(1+SNR))*Kcluster*tintra+(t1*Kcluster)*R)/(T-t0);
% Rtotal=R; %Rtotal为R的倍数
yita=0.8; %能量转换效率
epsilon=1e-3;
maxIter=20;
eee1=[];
% eee=[]; %建立空数组，为最后100次取平均值做准备
% hhh=[];
% ppk=[];
nengxiao=[];
% HHM=[];
% yIRS=-50:10:50;   %IRS:(0,yIRS,dv)-50:0.1:50
for it=1 %跑100次取平均值 it=1:100
%     it
%     weizhi=[];
%     Eee=[];
%     Etotal=[];
%     Eeh=[];
    for yIRS=-0.4   %IRS:(0,yIRS,dv)-50:0.1:50
%     for yirs=1:length(yIRS)
%         yirs
%         yIRS_irs = yIRS(yirs);
%         yIRS
        sinkloc=[0;0;0]; %sink坐标[0,0,0]
        CHsloc=[];
        IRSloc=[0;yIRS;HIRS];
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%远场条件下IRS一块板反射信号，不具体表示每个RE的坐标%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        dIS=sqrt(sum((IRSloc-sinkloc).^2)); %IRS到sink之间的距离Nt*M
        for k=1:Kcluster
            CHsloc=[CHsloc [x(:,k);y(:,k);0]];
        end
        dCS=[]; 
        for k=1:Kcluster
            dCS=[dCS sqrt(sum((sinkloc-CHsloc(:,k)).^2))];%sink到CHs距离Nt*1
        end
        dCI=[];
        for k=1:Kcluster
            dCI=[dCI sqrt(sum((CHsloc(:,k)-IRSloc).^2))]; %CHs到IRS距离M*1
        end
        g=sqrt(C0*((dIS/D0).^(-alpha_SI)))*(sqrt(beta_SI/(beta_SI+1))*ones(Nt,M)+sqrt(1/(beta_SI+1))*(sqrt(1/2)*(randn(Nt,M)+1j*randn(Nt,M)))); 
        for k=1:Kcluster
            hr_k(:,k)=sqrt(C0.*(((dCI(1,k))./D0).^(-alpha_IC)))*(sqrt(beta_IC/(beta_IC+1))*ones(M,1)+sqrt(1/(beta_IC+1))*(sqrt(1/2)*(randn(M,1)+1j*randn(M,1)))); %上行CH到IRS信道M*1
        end
        for k=1:Kcluster
            hd_k(:,k)=sqrt(C0.*((dCS(:,k)./D0).^(-alpha_SC)))*(sqrt(beta_SC/(beta_SC+1))*ones(Nt,1)+sqrt(1/(beta_SC+1))*(sqrt(1/2)*(randn(Nt,1)+1j*randn(Nt,1)))); %上行CH到sink信道Nt*1
        end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%上行信道构建完毕，开始构建下行信道%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        CRSNsloc=[];
        for n=1:N
            CRSNsloc=[CRSNsloc [x1(:,n);y1(:,n);0]];
        end
        dSC=[];
        for n=1:N
            dSC=[dSC sqrt(sum((CRSNsloc(:,n)-sinkloc).^2))];%sink到CRSNs距离Nt*1
        end
        dIC=[];
        for n=1:N
            dIC=[dIC sqrt(sum((CRSNsloc(:,n)-IRSloc).^2))]; %IRS到CRSNs距离1*M
        end
        for n=1:N
            hr_n(:,n)=sqrt(C0.*(((dIC(1,n))./D0).^(-alpha_IC)))*(sqrt(beta_IC/(beta_IC+1))*ones(M,1)+sqrt(1/(beta_IC+1))*(sqrt(1/2)*(randn(M,1)+1j*randn(M,1)))); %hr,n维度M*1
        end
        for n=1:N
            hd_n(:,n)=sqrt(C0.*((dSC(1,n)./D0).^(-alpha_SC)))*(sqrt(beta_SC/(beta_SC+1))*ones(Nt,1)+sqrt(1/(beta_SC+1))*(sqrt(1/2)*(randn(Nt,1)+1j*randn(Nt,1))));
        end
        %%%%%%%%%%%%%至此所有信道构建完毕%%%%%%%%%%%%%
        %%**************************************************************************联合**********************************************************************************
        %交替优化算法
        %固定波束赋形优化反射因子矩阵
        w0c=randn(Nt,1)+1j.*randn(Nt,1);%随机生成发射波束向量
        w0_mo=sqrt(sum((abs(w0c)).^2));
        w0=w0c./w0_mo;%单位化  w0_为固定波束赋形优化反射因子矩阵的波束赋形向量，即交替优化算法的初始迭代点 Nt*1
        wk0=[];
        for k=1:Kcluster
            wkc=randn(Nt,1)+1j.*randn(Nt,1);%随机生成发射波束向量
            wk_mo=sqrt(sum((abs(wkc)).^2));
            wk_1=wkc./wk_mo;%单位化
            wk0=[wk0 wk_1];  %wk_为固定波束赋形优化反射因子矩阵的波束赋形向量，即交替优化算法的初始迭代点 Nt*1
        end
        wk=wk0;
        EE_old=0;
        EE=10;
        count=0;
        while (abs((EE_old-EE)/EE)>epsilon && count < maxIter)
            count = count + 1;
%             count
        %SCA优化方法，得到上界
        [ak, v0, theta] = SCA_solving(hr_k, g, hd_k, hr_n, hd_n, M, Kcluster, N, SNR, PS, Pirs, pout, derta1_2, derta2_2, derta3n_2, w0, wk, Edt, t1, t0, yita);
        for k=1:Kcluster
            vk(:,k)=ak(:,k).*exp(1j.*theta(:,k));
            phik(:,:,k)=diag((vk(:,k)).');
        end
        phi0=diag((v0)');
        %SDR优化波束赋形
        [wk, w0] = SDR_solving(hr_k, g, hd_k, hr_n, hd_n, M, Nt, phi0, phik, Kcluster, N, SNR, PS, Pirs, pout, derta1_2, derta2_2, derta3n_2, Edt, t1, t0, yita);
        while (size(w0,1)==1 || size(wk,1)==1)
            w0c=randn(Nt,1)+1j.*randn(Nt,1);%随机生成发射波束向量
            w0_mo=sqrt(sum((abs(w0c)).^2));
            w0=w0c./w0_mo;%单位化  w0_为固定波束赋形优化反射因子矩阵的波束赋形向量，即交替优化算法的初始迭代点 Nt*1
            wk0=[];
            for k=1:Kcluster
                wkc=randn(Nt,1)+1j.*randn(Nt,1);%随机生成发射波束向量
                wk_mo=sqrt(sum((abs(wkc)).^2));
                wk_1=wkc./wk_mo;%单位化
                wk0=[wk0  wk_1];  %wk_为固定波束赋形优化反射因子矩阵的波束赋形向量，即交替优化算法的初始迭代点 Nt*1
            end
            wk=wk0;
            [ak, v0, theta] = SCA_solving(hr_k, g, hd_k, hr_n, hd_n, M, Kcluster, N, SNR, PS, Pirs, pout, derta1_2, derta2_2, derta3n_2, w0, wk, Edt, t1, t0, yita);
            for k=1:Kcluster
                vk(:,k)=ak(:,k).*exp(1j.*theta(:,k));
                phik(:,:,k)=diag((vk(:,k)).');
            end
            phi0=diag((v0)');
            [wk, w0] = SDR_solving(hr_k, g, hd_k, hr_n, hd_n, M, Nt, phi0, phik, Kcluster, N, SNR, PS, Pirs, pout, derta1_2, derta2_2, derta3n_2, Edt, t1, t0, yita);
        end
        EE_old=EE;
        EE1=[];
        for k=1:Kcluster
            EE1=[EE1 (t1*(((derta1_2*(norm((wk(:,k))'*g*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k(:,k)+g*phik(:,:,k)*hr_k(:,k))))^2))*SNR+...
                ((derta1_2*(norm((wk(:,k))'*g*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k(:,k)+g*phik(:,:,k)*hr_k(:,k))))^2))*SNR*(norm(phik(:,:,k)*hr_k(:,k)))^2+...
                derta1_2*(norm(phik(:,:,k)*eye(M)))^2+M*Pirs)+(Eelec+EDA)*L)]; %Eelec*L是电子电路能耗，EDA*L是CHk聚合自身的能耗。
        end
        EE2=sum(EE1(1:Kcluster));
        Etotal_=EE2+Esink+ECM+ECH_intra+t0*(PS*(norm(w0))^2+M*Pirs+PS*(norm(phi0*g'*w0))^2+derta1_2*(norm(phi0*eye(M)))^2);
        HH1=[];
        for n=1:N
            HH1=[HH1 (PS*(abs(((hd_n(:,n))'+(hr_n(:,n))'*phi0*g')*w0))^2+derta1_2*(norm((hr_n(:,n))'*phi0))^2+derta3n_2)];
        end
        HH2=sum(HH1(1:N));
        Eharvesting_=t0*yita*HH2;
        EE=Rtotal/(Etotal_-Eharvesting_);
        end
        EEe1=[];
        for k=1:Kcluster
            EEe1=[EEe1 (t1*((derta1_2*(norm((wk(:,k))'*g*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k(:,k)+g*phik(:,:,k)*hr_k(:,k))))^2))*SNR)];
        end
for io_1=10
xindaopiancha_1=[0.02,0.04,0.06,0.08,0.1,0.12,0.14,0.16,0.18,0.2];
xindaopiancha=xindaopiancha_1(io_1);
for io=1:100

        hd_k_3=hd_k-sqrt(xindaopiancha)*abs(hd_k).*(sqrt(1/2)*(randn(Nt,Kcluster)+1j*randn(Nt,Kcluster)));
        hr_k_3= hr_k-sqrt(xindaopiancha)*abs(hr_k).*(sqrt(1/2)*(randn(M,Kcluster)+1j*randn(M,Kcluster)));
        g_3=g-sqrt(xindaopiancha)*sqrt(C0*((dIS/D0).^(-alpha_SI)))*sqrt(1/(beta_SI+1))*(sqrt(1/2)*(randn(Nt,M)+1j*randn(Nt,M))); 
        hd_n_3=hd_n-sqrt(xindaopiancha)*abs(hd_n).*(sqrt(1/2)*(randn(Nt,N)+1j*randn(Nt,N)));
        hr_n_3=hr_n-sqrt(xindaopiancha)*abs(hr_n).*(sqrt(1/2)*(randn(M,N)+1j*randn(M,N)));
EE_old=EE;
EE11=[];
for k=1:Kcluster
    EE11=[EE11 (t1*(((derta1_2*(norm((wk(:,k))'*g_3*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k_3(:,k)+g_3*phik(:,:,k)*hr_k_3(:,k))))^2))*SNR+...
        ((derta1_2*(norm((wk(:,k))'*g_3*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k_3(:,k)+g_3*phik(:,:,k)*hr_k_3(:,k))))^2))*SNR*(norm(phik(:,:,k)*hr_k_3(:,k)))^2+...
        derta1_2*(norm(phik(:,:,k)*eye(M)))^2+M*Pirs)+(Eelec+EDA)*L)]; %Eelec*L是电子电路能耗，EDA*L是CHk聚合自身的能耗。
end
EE21=sum(EE11(1:Kcluster));
Etotal_1=EE21+Esink+ECM+ECH_intra+t0*(PS*(norm(w0))^2+M*Pirs+PS*(norm(phi0*g_3'*w0))^2+derta1_2*(norm(phi0*eye(M)))^2);
HH11=[];
for n=1:N
    HH11=[HH11 (PS*(abs(((hd_n_3(:,n))'+(hr_n_3(:,n))'*phi0*g_3')*w0))^2+derta1_2*(norm((hr_n_3(:,n))'*phi0))^2+derta3n_2)];
end
HH21=sum(HH11(1:N));
Eharvesting_1=t0*yita*HH21;
EE_1=Rtotal/(Etotal_1-Eharvesting_1);
EEe11=[];
for k=1:Kcluster
    EEe11=[EEe11 (t1*((derta1_2*(norm((wk(:,k))'*g_3*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k_3(:,k)+g_3*phik(:,:,k)*hr_k_3(:,k))))^2))*SNR)];
end
EE_2(io)=EE_1;
HH12(io,:)=HH11;
Etotal_2(io,:)=Etotal_1;
EEe112(io,:)=EEe11;
end
EE_3(io_1,:)=sum(EE_2)/100;
HH13(io_1,:)=sum(HH12,1)/100;
Etotal_3(io_1,:)=sum(Etotal_2,1)/100;
EEe113(io_1,:)=sum(EEe112,1)/100;
end
        %%*****************************************************************净能量收益**************************************************************************
        w0c=randn(Nt,1)+1j.*randn(Nt,1);%随机生成发射波束向量
        w0_mo=sqrt(sum((abs(w0c)).^2));
        w0=w0c./w0_mo;
        wk0=[];
        for k=1:Kcluster
            wkcab=randn(Nt,1)+1j.*randn(Nt,1);%随机生成发射波束向量
            wk_moab=sqrt(sum((abs(wkcab)).^2));
            wk_1ab=wkcab./wk_moab;%单位化
            wk0=[wk0  wk_1ab];  %wk_为固定波束赋形优化反射因子矩阵的波束赋形向量，即交替优化算法的初始迭代点 Nt*1
        end
        wk=wk0;
%         wk=wk0';
        Eb_old=0;
        Eb=10;
%         AOab=[];
        count=0;
        while (abs((Eb_old-Eb)/Eb)>epsilon && count < maxIter)
            count = count + 1;
%             count
        %SCA优化方法，得到上界  
        [ak, v0, theta] = AEbenefitSCA(hr_k, g, hd_k, hr_n, hd_n, M, Kcluster, N, SNR, PS, Pirs, pout, derta1_2, derta2_2, derta3n_2, w0, wk, t1, t0, yita);
        for k=1:Kcluster
            vk(:,k)=ak(:,k).*exp(1j.*theta(:,k));
            phik(:,:,k)=diag((vk(:,k)).');
        end
        phi0=diag((v0)');
        %SDR优化波束赋形
        [wk, w0] = AEbenefitSDR(hr_k, g, hd_k, hr_n, hd_n, M, Nt, phi0, phik, Kcluster, N, SNR, PS, pout, derta1_2, derta2_2, derta3n_2, t1, t0, yita, Eelec, EDA, L);
        while (size(w0,1)==1 || size(wk,1)==1)
            w0c=randn(Nt,1)+1j.*randn(Nt,1);%随机生成发射波束向量
            w0_mo=sqrt(sum((abs(w0c)).^2));
            w0=w0c./w0_mo;%单位化  w0_为固定波束赋形优化反射因子矩阵的波束赋形向量，即交替优化算法的初始迭代点 Nt*1
            wk0=[];
            for k=1:Kcluster
                wkcab=randn(Nt,1)+1j.*randn(Nt,1);%随机生成发射波束向量
                wk_moab=sqrt(sum((abs(wkcab)).^2));
                wk_1ab=wkcab./wk_moab;%单位化
                wk0=[wk0  wk_1ab];  %wk_为固定波束赋形优化反射因子矩阵的波束赋形向量，即交替优化算法的初始迭代点 Nt*1
            end
            wk=wk0;
            [ak, v0, theta] = AEbenefitSCA(hr_k, g, hd_k, hr_n, hd_n, M, Kcluster, N, SNR, PS, Pirs, pout, derta1_2, derta2_2, derta3n_2, w0, wk, t1, t0, yita);
            for k=1:Kcluster
                vk(:,k)=ak(:,k).*exp(1j.*theta(:,k));
                phik(:,:,k)=diag((vk(:,k)).');
            end
            phi0=diag((v0)');
            [wk, w0] = AEbenefitSDR(hr_k, g, hd_k, hr_n, hd_n, M, Nt, phi0, phik, Kcluster, N, SNR, PS, pout, derta1_2, derta2_2, derta3n_2, t1, t0, yita, Eelec, EDA, L);
        end
        Eb_old=Eb;
        Eb1=[];
        for k=1:Kcluster
            Eb1=[Eb1 (t1*((derta1_2*(norm((wk(:,k))'*g*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k(:,k)+g*phik(:,:,k)*hr_k(:,k))))^2))*SNR)];
        end
        Eb2=sum(Eb1(1:Kcluster));  %Eb2=Einter
        Ebdown1=[];
        for n=1:N
            Ebdown1=[Ebdown1 (PS*(abs(((hd_n(:,n))'+(hr_n(:,n))'*phi0*g')*w0))^2+derta1_2*(norm((hr_n(:,n))'*phi0))^2+derta3n_2)];
        end
        Ebdown2=sum(Ebdown1(1:N));
        Ebdown=t0*yita*Ebdown2; %Edown=Eharvesting
        Eb=Ebdown-Eb2;
%         AOab=[AOab Ebab]; %看交替优化收敛性
        end
        %%%%计算能效%%%%%
        EE1=[];
        for k=1:Kcluster
            EE1=[EE1 (t1*(((derta1_2*(norm((wk(:,k))'*g*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k(:,k)+g*phik(:,:,k)*hr_k(:,k))))^2))*SNR+...
                ((derta1_2*(norm((wk(:,k))'*g*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k(:,k)+g*phik(:,:,k)*hr_k(:,k))))^2))*SNR*(norm(phik(:,:,k)*hr_k(:,k)))^2+...
                derta1_2*(norm(phik(:,:,k)*eye(M)))^2+M*Pirs)+(Eelec+EDA)*L)];
        end
        EE2ab=sum(EE1(1:Kcluster));
        Etotalab_=EE2ab+Esink+ECM+ECH_intra+t0*(PS*(norm(w0))^2+M*Pirs+PS*(norm(phi0*g'*w0))^2+derta1_2*(norm(phi0*eye(M)))^2);
        Eharvestingab_=Ebdown;
        EEab=Rtotal/(Etotalab_-Eharvestingab_);
        EEe1ab=[];
        for k=1:Kcluster
            EEe1ab=[EEe1ab (t1*(((derta1_2*(norm((wk(:,k))'*g*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k(:,k)+g*phik(:,:,k)*hr_k(:,k))))^2))*SNR))];
        end

for io_1=10
xindaopiancha_1=[0.02,0.04,0.06,0.08,0.1,0.12,0.14,0.16,0.18,0.2];
xindaopiancha=xindaopiancha_1(io_1);
for io=1:100

        hd_k_3=hd_k-sqrt(xindaopiancha)*abs(hd_k).*(sqrt(1/2)*(randn(Nt,Kcluster)+1j*randn(Nt,Kcluster)));
        hr_k_3= hr_k-sqrt(xindaopiancha)*abs(hr_k).*(sqrt(1/2)*(randn(M,Kcluster)+1j*randn(M,Kcluster)));
        g_3=g-sqrt(xindaopiancha)*sqrt(C0*((dIS/D0).^(-alpha_SI)))*sqrt(1/(beta_SI+1))*(sqrt(1/2)*(randn(Nt,M)+1j*randn(Nt,M))); 
        hd_n_3=hd_n-sqrt(xindaopiancha)*abs(hd_n).*(sqrt(1/2)*(randn(Nt,N)+1j*randn(Nt,N)));
        hr_n_3=hr_n-sqrt(xindaopiancha)*abs(hr_n).*(sqrt(1/2)*(randn(M,N)+1j*randn(M,N)));

   Eb_old=Eb;
Eb11=[];
for k=1:Kcluster
    Eb11=[Eb11 (t1*((derta1_2*(norm((wk(:,k))'*g_3*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k_3(:,k)+g_3*phik(:,:,k)*hr_k_3(:,k))))^2))*SNR)];
end
Eb21=sum(Eb11(1:Kcluster));  %Eb2=Einter
Ebdown11=[];
for n=1:N
    Ebdown11=[Ebdown11 (PS*(abs(((hd_n_3(:,n))'+(hr_n_3(:,n))'*phi0*g_3')*w0))^2+derta1_2*(norm((hr_n_3(:,n))'*phi0))^2+derta3n_2)];
end
Ebdown21=sum(Ebdown11(1:N));
Ebdown_1=t0*yita*Ebdown21; %Edown=Eharvesting
Eb_1=Ebdown_1-Eb21;
%         AOab=[AOab Ebab]; %看交替优化收敛性

%%%%计算能效%%%%%
EE1=[];
for k=1:Kcluster
    EE1=[EE1 (t1*(((derta1_2*(norm((wk(:,k))'*g_3*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k_3(:,k)+g_3*phik(:,:,k)*hr_k_3(:,k))))^2))*SNR+...
        ((derta1_2*(norm((wk(:,k))'*g_3*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k_3(:,k)+g_3*phik(:,:,k)*hr_k_3(:,k))))^2))*SNR*(norm(phik(:,:,k)*hr_k_3(:,k)))^2+...
        derta1_2*(norm(phik(:,:,k)*eye(M)))^2+M*Pirs)+(Eelec+EDA)*L)];
end
EE2ab_1=sum(EE1(1:Kcluster));
Etotalab_1=EE2ab_1+Esink+ECM+ECH_intra+t0*(PS*(norm(w0))^2+M*Pirs+PS*(norm(phi0*g_3'*w0))^2+derta1_2*(norm(phi0*eye(M)))^2);
Eharvestingab_1=Ebdown_1;
EEab_1=Rtotal/(Etotalab_1-Eharvestingab_1);
EEe1ab_1=[];
for k=1:Kcluster
    EEe1ab_1=[EEe1ab_1 (t1*(((derta1_2*(norm((wk(:,k))'*g_3*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k_3(:,k)+g_3*phik(:,:,k)*hr_k_3(:,k))))^2))*SNR))];
end



EEab_2(io)=EEab_1;
Ebdown12(io,:)=Ebdown11;
Etotalab_2(io,:)=Etotalab_1;
EEe1ab_2(io,:)=EEe1ab_1;
end
EEab_3(io_1,:)=sum(EEab_2)/100;
Ebdown13(io_1,:)=sum(Ebdown12,1)/100;
Etotalab_3(io_1,:)=sum(Etotalab_2,1)/100;
EEe1ab_3(io_1,:)=sum(EEe1ab_2,1)/100;
end

        %%**************************************************************被动IRS************************************************************************
        w0c=randn(Nt,1)+1j.*randn(Nt,1);%随机生成发射波束向量
        w0_mo=sqrt(sum((abs(w0c)).^2));
        w0=w0c./w0_mo;%单位化  w0_为固定波束赋形优化反射因子矩阵的波束赋形向量，即交替优化算法的初始迭代点 Nt*1
        wk0=[];
        for k=1:K
            wkcp=randn(Nt,1)+1j.*randn(Nt,1);%随机生成发射波束向量
            wk_mop=sqrt(sum((abs(wkcp)).^2));
            wk_1p=wkcp./wk_mop;%单位化
            wk0=[wk0  wk_1p];  %wk_为固定波束赋形优化反射因子矩阵的波束赋形向量，即交替优化算法的初始迭代点 Nt*1
        end
        wk=wk0;
        EEp_old=0;
        EEp=10;
        count=0;
        while (abs((EEp_old-EEp)/EEp)>epsilon && count < maxIter)
            count = count + 1;
        %SCA优化方法，得到上界
        [v0, theta] = passiveSCA(hr_k, g, hd_k, hr_n, hd_n, M, K, N,  PS, w0, wk);
        for k=1:K
            vk(:,k)=exp(1j.*theta(:,k));
            phik(:,:,k)=diag((vk(:,k)).');
        end
        phi0=diag((v0)');
        %SDR优化波束赋形
        [wk, w0] = passiveSDR(hr_k, g, hd_k, hr_n, hd_n, M, Nt, phi0, phik, K, N, SNR, PS, PC,  derta1_2, derta2_2, Edt, t1, t0, yita);
        while (size(w0,1)==1 || size(wk,1)==1)
            w0c=randn(Nt,1)+1j.*randn(Nt,1);%随机生成发射波束向量
            w0_mo=sqrt(sum((abs(w0c)).^2));
            w0=w0c./w0_mo;%单位化  w0_为固定波束赋形优化反射因子矩阵的波束赋形向量，即交替优化算法的初始迭代点 Nt*1
            wk0=[];
            for k=1:K
                wkcp=randn(Nt,1)+1j.*randn(Nt,1);%随机生成发射波束向量
                wk_mop=sqrt(sum((abs(wkcp)).^2));
                wk_1p=wkcp./wk_mop;%单位化
                wk0=[wk0  wk_1p];  %wk_为固定波束赋形优化反射因子矩阵的波束赋形向量，即交替优化算法的初始迭代点 Nt*1
            end
            wk=wk0;
            [v0, theta] = passiveSCA(hr_k, g, hd_k, hr_n, hd_n, M, K, N,  PS, w0, wk);
            for k=1:K
                vk(:,k)=exp(1j.*theta(:,k));
                phik(:,:,k)=diag((vk(:,k)).');
            end
            phi0=diag((v0)');
            [wk, w0] = passiveSDR(hr_k, g, hd_k, hr_n, hd_n, M, Nt, phi0, phik, K, N, SNR, PS, PC,  derta1_2, derta2_2, Edt, t1, t0, yita);
        end
        EEp_old=EEp;
        EE1p=[];
        for k=1:K
            EE1p=[EE1p (t1*(((derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k(:,k)+g*phik(:,:,k)*hr_k(:,k))))^2))*SNR+M*PC)+(Eelec+EDA)*L1)];
        end
        EE2p=sum(EE1p(1:K));
        Etotalp_=EE2p+Esink+ECM+ECH_intra+t0*(PS*(norm(w0))^2+M*PC);
        HH1p=[];
        for n=1:N
            HH1p=[HH1p (PS*(abs(((hd_n(:,n))'+(hr_n(:,n))'*phi0*g')*w0))^2)];
        end
        HH2p=sum(HH1p(1:N));
        Eharvestingp_=t0*yita*HH2p;
        EEp=Rtotal/(Etotalp_-Eharvestingp_);
        end
        EEe1p=[];
        for k=1:K
            EEe1p=[EEe1p (t1*(((derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k(:,k)+g*phik(:,:,k)*hr_k(:,k))))^2))*SNR))];
        end
        %**************************************************************仅上行**************************************************
        w0c=randn(Nt,1)+1j.*randn(Nt,1);%随机生成发射波束向量
        w0_mo=sqrt(sum((abs(w0c)).^2));
        w0=w0c./w0_mo;%单位化  w0_为固定波束赋形优化反射因子矩阵的波束赋形向量，即交替优化算法的初始迭代点 Nt*1
        wk0=[];
        for k=1:Kcluster
            wkc=randn(Nt,1)+1j.*randn(Nt,1);%随机生成发射波束向量
            wk_mo=sqrt(sum((abs(wkc)).^2));
            wk_1=wkc./wk_mo;%单位化
            wk0=[wk0 wk_1];  %wk_为固定波束赋形优化反射因子矩阵的波束赋形向量，即交替优化算法的初始迭代点 Nt*1
        end
        wk=wk0;
        EEu_old=0;
        EEu=10;
        count=0;
        while (abs((EEu_old-EEu)/EEu)>epsilon && count < maxIter)
            count = count + 1;
%             count
        %SCA优化方法，得到上界
        [ak, v0, theta] = AUplinkSCA(hr_k, g, hd_k, M, Kcluster, SNR, PS, Pirs, pout, derta1_2, derta2_2, w0, wk, Edt, t1);
        for k=1:Kcluster
            vk(:,k)=ak(:,k).*exp(1j.*theta(:,k));
            phik(:,:,k)=diag((vk(:,k)).');
        end
        phi0=diag((v0)');
        %SDR优化波束赋形
        [wk, w0] = SDR_solving(hr_k, g, hd_k, hr_n, hd_n, M, Nt, phi0, phik, Kcluster, N, SNR, PS, Pirs, pout, derta1_2, derta2_2, derta3n_2, Edt, t1, t0, yita);
        while (size(w0,1)==1 || size(wk,1)==1)
            w0c=randn(Nt,1)+1j.*randn(Nt,1);%随机生成发射波束向量
            w0_mo=sqrt(sum((abs(w0c)).^2));
            w0=w0c./w0_mo;%单位化  w0_为固定波束赋形优化反射因子矩阵的波束赋形向量，即交替优化算法的初始迭代点 Nt*1
            wk0=[];
            for k=1:Kcluster
                wkc=randn(Nt,1)+1j.*randn(Nt,1);%随机生成发射波束向量
                wk_mo=sqrt(sum((abs(wkc)).^2));
                wk_1=wkc./wk_mo;%单位化
                wk0=[wk0  wk_1];  %wk_为固定波束赋形优化反射因子矩阵的波束赋形向量，即交替优化算法的初始迭代点 Nt*1
            end
            wk=wk0;
            [ak, v0, theta] = AUplinkSCA(hr_k, g, hd_k, M, Kcluster, SNR, PS, Pirs, pout, derta1_2, derta2_2, w0, wk, Edt, t1);
            for k=1:Kcluster
                vk(:,k)=ak(:,k).*exp(1j.*theta(:,k));
                phik(:,:,k)=diag((vk(:,k)).');
            end
            phi0=diag((v0)');
            [wk, w0] = SDR_solving(hr_k, g, hd_k, hr_n, hd_n, M, Nt, phi0, phik, Kcluster, N, SNR, PS, Pirs, pout, derta1_2, derta2_2, derta3n_2, Edt, t1, t0, yita);
        end
        EEu_old=EEu;
        EE1=[];
        for k=1:Kcluster
            EE1=[EE1 (t1*(((derta1_2*(norm((wk(:,k))'*g*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k(:,k)+g*phik(:,:,k)*hr_k(:,k))))^2))*SNR+...
                ((derta1_2*(norm((wk(:,k))'*g*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k(:,k)+g*phik(:,:,k)*hr_k(:,k))))^2))*SNR*(norm(phik(:,:,k)*hr_k(:,k)))^2+...
                derta1_2*(norm(phik(:,:,k)*eye(M)))^2+M*Pirs)+(Eelec+EDA)*L)]; %Eelec*L是电子电路能耗，EDA*L是CHk聚合自身的能耗。
        end
        EE2=sum(EE1(1:Kcluster));
        Etotalu_=EE2+Esink+ECM+ECH_intra+t0*(PS*(norm(w0))^2+M*Pirs+PS*(norm(phi0*g'*w0))^2+derta1_2*(norm(phi0*eye(M)))^2);
        HH1=[];
        for n=1:N
            HH1=[HH1 (PS*(abs(((hd_n(:,n))'+(hr_n(:,n))'*phi0*g')*w0))^2+derta1_2*(norm((hr_n(:,n))'*phi0))^2+derta3n_2)];
        end
        HH2u=sum(HH1(1:N));
        Eharvestingu_=t0*yita*HH2u;
        EEu=Rtotal/(Etotalu_-Eharvestingu_);
        end
        EEe1u=[];
        for k=1:Kcluster
            EEe1u=[EEe1u (t1*((derta1_2*(norm((wk(:,k))'*g*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k(:,k)+g*phik(:,:,k)*hr_k(:,k))))^2))*SNR)];
        end
        %%*******************************************************************仅下行***************************************************************
        w0c=randn(Nt,1)+1j.*randn(Nt,1);%随机生成发射波束向量
        w0_mo=sqrt(sum((abs(w0c)).^2));
        w0=w0c./w0_mo;%单位化  w0_为固定波束赋形优化反射因子矩阵的波束赋形向量，即交替优化算法的初始迭代点 Nt*1
        wk0=[];
        for k=1:Kcluster
            wkc=randn(Nt,1)+1j.*randn(Nt,1);%随机生成发射波束向量
            wk_mo=sqrt(sum((abs(wkc)).^2));
            wk_1=wkc./wk_mo;%单位化
            wk0=[wk0 wk_1];  %wk_为固定波束赋形优化反射因子矩阵的波束赋形向量，即交替优化算法的初始迭代点 Nt*1
        end
        wk=wk0;
        EEd_old=0;
        EEd=10;
        count=0;
        while (abs((EEd_old-EEd)/EEd)>epsilon && count < maxIter)
            count = count + 1;
%             count
        %SCA优化方法，得到上界
        [ak, v0, theta] = ADownlinkSCA(hr_k, g, hd_k, hr_n, hd_n, M, Kcluster, N, SNR, PS, Pirs, pout, derta1_2, derta2_2, derta3n_2, w0, wk, t0, yita);
        for k=1:Kcluster
            vk(:,k)=ak(:,k).*exp(1j.*theta(:,k));
            phik(:,:,k)=diag((vk(:,k)).');
        end
        phi0=diag((v0)');
        %SDR优化波束赋形
        [wk, w0] = SDR_solving(hr_k, g, hd_k, hr_n, hd_n, M, Nt, phi0, phik, Kcluster, N, SNR, PS, Pirs, pout, derta1_2, derta2_2, derta3n_2, Edt, t1, t0, yita);
        while (size(w0,1)==1 || size(wk,1)==1)
            w0c=randn(Nt,1)+1j.*randn(Nt,1);%随机生成发射波束向量
            w0_mo=sqrt(sum((abs(w0c)).^2));
            w0=w0c./w0_mo;%单位化  w0_为固定波束赋形优化反射因子矩阵的波束赋形向量，即交替优化算法的初始迭代点 Nt*1
            wk0=[];
            for k=1:Kcluster
                wkc=randn(Nt,1)+1j.*randn(Nt,1);%随机生成发射波束向量
                wk_mo=sqrt(sum((abs(wkc)).^2));
                wk_1=wkc./wk_mo;%单位化
                wk0=[wk0  wk_1];  %wk_为固定波束赋形优化反射因子矩阵的波束赋形向量，即交替优化算法的初始迭代点 Nt*1
            end
            wk=wk0;
            [ak, v0, theta] = ADownlinkSCA(hr_k, g, hd_k, hr_n, hd_n, M, Kcluster, N, SNR, PS, Pirs, pout, derta1_2, derta2_2, derta3n_2, w0, wk, t0, yita);
            for k=1:Kcluster
                vk(:,k)=ak(:,k).*exp(1j.*theta(:,k));
                phik(:,:,k)=diag((vk(:,k)).');
            end
            phi0=diag((v0)');
            [wk, w0] = SDR_solving(hr_k, g, hd_k, hr_n, hd_n, M, Nt, phi0, phik, Kcluster, N, SNR, PS, Pirs, pout, derta1_2, derta2_2, derta3n_2, Edt, t1, t0, yita);
        end
        EEd_old=EEd;
        EE1=[];
        for k=1:Kcluster
            EE1=[EE1 (t1*(((derta1_2*(norm((wk(:,k))'*g*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k(:,k)+g*phik(:,:,k)*hr_k(:,k))))^2))*SNR+...
                ((derta1_2*(norm((wk(:,k))'*g*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k(:,k)+g*phik(:,:,k)*hr_k(:,k))))^2))*SNR*(norm(phik(:,:,k)*hr_k(:,k)))^2+...
                derta1_2*(norm(phik(:,:,k)*eye(M)))^2+M*Pirs)+(Eelec+EDA)*L)]; %Eelec*L是电子电路能耗，EDA*L是CHk聚合自身的能耗。
        end
        EE2=sum(EE1(1:Kcluster));
        Etotald_=EE2+Esink+ECM+ECH_intra+t0*(PS*(norm(w0))^2+M*Pirs+PS*(norm(phi0*g'*w0))^2+derta1_2*(norm(phi0*eye(M)))^2);
        HH1=[];
        for n=1:N
            HH1=[HH1 (PS*(abs(((hd_n(:,n))'+(hr_n(:,n))'*phi0*g')*w0))^2+derta1_2*(norm((hr_n(:,n))'*phi0))^2+derta3n_2)];
        end
        HH2=sum(HH1(1:N));
        Eharvestingd_=t0*yita*HH2;
        EEd=Rtotal/(Etotald_-Eharvestingd_);
        end
        EEe1d=[];
        for k=1:Kcluster
            EEe1d=[EEe1d (t1*((derta1_2*(norm((wk(:,k))'*g*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k(:,k)+g*phik(:,:,k)*hr_k(:,k))))^2))*SNR)];
        end
        %%*************************************************************随机相移***********************************************************************
        w0c=randn(Nt,1)+1j.*randn(Nt,1);%随机生成发射波束向量
        w0_mo=sqrt(sum((abs(w0c)).^2));
        w0=w0c./w0_mo;%单位化  w0_为固定波束赋形优化反射因子矩阵的波束赋形向量，即交替优化算法的初始迭代点 Nt*1
        wk0=[];
        for k=1:Kcluster
            wkc=randn(Nt,1)+1j.*randn(Nt,1);%随机生成发射波束向量
            wk_mo=sqrt(sum((abs(wkc)).^2));
            wk_1=wkc./wk_mo;%单位化
            wk0=[wk0 wk_1];  %wk_为固定波束赋形优化反射因子矩阵的波束赋形向量，即交替优化算法的初始迭代点 Nt*1
        end
        wk=wk0;
        EEr_old=0;
        EEr=10;
        count=0;
        while (abs((EEr_old-EEr)/EEr)>epsilon && count < maxIter)
            count = count + 1;
%             count
        %SCA优化方法，得到上界
        [ak, v0, theta] = ARandomSCA(hr_k, g, hd_k, hr_n, hd_n, M, Kcluster, N, SNR, PS, Pirs, pout, derta1_2, derta2_2, derta3n_2, w0, wk, t0);
        for k=1:Kcluster
            vk(:,k)=ak(:,k).*exp(1j.*theta(:,k));
            phik(:,:,k)=diag((vk(:,k)).');
        end
        phi0=diag((v0)');
        %SDR优化波束赋形
        [wk, w0] = SDR_solving(hr_k, g, hd_k, hr_n, hd_n, M, Nt, phi0, phik, Kcluster, N, SNR, PS, Pirs, pout, derta1_2, derta2_2, derta3n_2, Edt, t1, t0, yita);
        while (size(w0,1)==1 || size(wk,1)==1)
            w0c=randn(Nt,1)+1j.*randn(Nt,1);%随机生成发射波束向量
            w0_mo=sqrt(sum((abs(w0c)).^2));
            w0=w0c./w0_mo;%单位化  w0_为固定波束赋形优化反射因子矩阵的波束赋形向量，即交替优化算法的初始迭代点 Nt*1
            wk0=[];
            for k=1:Kcluster
                wkc=randn(Nt,1)+1j.*randn(Nt,1);%随机生成发射波束向量
                wk_mo=sqrt(sum((abs(wkc)).^2));
                wk_1=wkc./wk_mo;%单位化
                wk0=[wk0  wk_1];  %wk_为固定波束赋形优化反射因子矩阵的波束赋形向量，即交替优化算法的初始迭代点 Nt*1
            end
            wk=wk0;
            [ak, v0, theta] = ARandomSCA(hr_k, g, hd_k, hr_n, hd_n, M, Kcluster, N, SNR, PS, Pirs, pout, derta1_2, derta2_2, derta3n_2, w0, wk, t0);
            for k=1:Kcluster
                vk(:,k)=ak(:,k).*exp(1j.*theta(:,k));
                phik(:,:,k)=diag((vk(:,k)).');
            end
            phi0=diag((v0)');
            [wk, w0] = SDR_solving(hr_k, g, hd_k, hr_n, hd_n, M, Nt, phi0, phik, Kcluster, N, SNR, PS, Pirs, pout, derta1_2, derta2_2, derta3n_2, Edt, t1, t0, yita);
        end
        EEr_old=EEr;
        EE1=[];
        for k=1:Kcluster
            EE1=[EE1 (t1*(((derta1_2*(norm((wk(:,k))'*g*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k(:,k)+g*phik(:,:,k)*hr_k(:,k))))^2))*SNR+...
                ((derta1_2*(norm((wk(:,k))'*g*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k(:,k)+g*phik(:,:,k)*hr_k(:,k))))^2))*SNR*(norm(phik(:,:,k)*hr_k(:,k)))^2+...
                derta1_2*(norm(phik(:,:,k)*eye(M)))^2+M*Pirs)+(Eelec+EDA)*L)]; %Eelec*L是电子电路能耗，EDA*L是CHk聚合自身的能耗。
        end
        EE2=sum(EE1(1:Kcluster));
        Etotalr_=EE2+Esink+ECM+ECH_intra+t0*(PS*(norm(w0))^2+M*Pirs+PS*(norm(phi0*g'*w0))^2+derta1_2*(norm(phi0*eye(M)))^2);
        HH1=[];
        for n=1:N
            HH1=[HH1 (PS*(abs(((hd_n(:,n))'+(hr_n(:,n))'*phi0*g')*w0))^2+derta1_2*(norm((hr_n(:,n))'*phi0))^2+derta3n_2)];
        end
        HH2=sum(HH1(1:N));
        Eharvestingr_=t0*yita*HH2;
        EEr=Rtotal/(Etotalr_-Eharvestingr_);
        end
        EEe1r=[];
        for k=1:Kcluster
            EEe1r=[EEe1r (t1*((derta1_2*(norm((wk(:,k))'*g*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k(:,k)+g*phik(:,:,k)*hr_k(:,k))))^2))*SNR)];
        end
        %%*************************************************************共用***************************************************************
        w0c=randn(Nt,1)+1j.*randn(Nt,1);%随机生成发射波束向量
        w0_mo=sqrt(sum((abs(w0c)).^2));
        w0=w0c./w0_mo;%单位化  w0_为固定波束赋形优化反射因子矩阵的波束赋形向量，即交替优化算法的初始迭代点 Nt*1
        wk0=[];
        for k=1:Kcluster
            wkc=randn(Nt,1)+1j.*randn(Nt,1);%随机生成发射波束向量
            wk_mo=sqrt(sum((abs(wkc)).^2));
            wk_1=wkc./wk_mo;%单位化
            wk0=[wk0 wk_1];  %wk_为固定波束赋形优化反射因子矩阵的波束赋形向量，即交替优化算法的初始迭代点 Nt*1
        end
        wk=wk0;
        EEg_old=0;
        EEg=10;
        count=0;
        while (abs((EEg_old-EEg)/EEg)>epsilon && count < maxIter)
            count = count + 1;
%             count
        %SCA优化方法，得到上界
        [vk, v0] = GongyongSCA(g, hr_n, hd_n, M, Kcluster, N, PS, Pirs, pout, derta1_2, derta3n_2, w0, t0, yita);
        for k=1:Kcluster
            phik(:,:,k)=diag((vk(:,k)).');
        end
        phi0=diag((v0)');
        %SDR优化波束赋形
        [wk, w0] = SDR_solving(hr_k, g, hd_k, hr_n, hd_n, M, Nt, phi0, phik, Kcluster, N, SNR, PS, Pirs, pout, derta1_2, derta2_2, derta3n_2, Edt, t1, t0, yita);
        while (size(w0,1)==1 || size(wk,1)==1)
            w0c=randn(Nt,1)+1j.*randn(Nt,1);%随机生成发射波束向量
            w0_mo=sqrt(sum((abs(w0c)).^2));
            w0=w0c./w0_mo;%单位化  w0_为固定波束赋形优化反射因子矩阵的波束赋形向量，即交替优化算法的初始迭代点 Nt*1
            wk0=[];
            for k=1:Kcluster
                wkc=randn(Nt,1)+1j.*randn(Nt,1);%随机生成发射波束向量
                wk_mo=sqrt(sum((abs(wkc)).^2));
                wk_1=wkc./wk_mo;%单位化
                wk0=[wk0  wk_1];  %wk_为固定波束赋形优化反射因子矩阵的波束赋形向量，即交替优化算法的初始迭代点 Nt*1
            end
            wk=wk0;
            [vk, v0] = GongyongSCA(g, hr_n, hd_n, M, Kcluster, N, PS, Pirs, pout, derta1_2, derta3n_2, w0, t0, yita);
            for k=1:Kcluster
                phik(:,:,k)=diag((vk(:,k)).');
            end
            phi0=diag((v0)');
            [wk, w0] = SDR_solving(hr_k, g, hd_k, hr_n, hd_n, M, Nt, phi0, phik, Kcluster, N, SNR, PS, Pirs, pout, derta1_2, derta2_2, derta3n_2, Edt, t1, t0, yita);
        end
        EEg_old=EEg;
        EE1=[];
        for k=1:Kcluster
            EE1=[EE1 (t1*(((derta1_2*(norm((wk(:,k))'*g*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k(:,k)+g*phik(:,:,k)*hr_k(:,k))))^2))*SNR+...
                ((derta1_2*(norm((wk(:,k))'*g*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k(:,k)+g*phik(:,:,k)*hr_k(:,k))))^2))*SNR*(norm(phik(:,:,k)*hr_k(:,k)))^2+...
                derta1_2*(norm(phik(:,:,k)*eye(M)))^2+M*Pirs)+(Eelec+EDA)*L)]; %Eelec*L是电子电路能耗，EDA*L是CHk聚合自身的能耗。
        end
        EE2=sum(EE1(1:Kcluster));
        Etotalg_=EE2+Esink+ECM+ECH_intra+t0*(PS*(norm(w0))^2+M*Pirs+PS*(norm(phi0*g'*w0))^2+derta1_2*(norm(phi0*eye(M)))^2);
        HH1=[];
        for n=1:N
            HH1=[HH1 (PS*(abs(((hd_n(:,n))'+(hr_n(:,n))'*phi0*g')*w0))^2+derta1_2*(norm((hr_n(:,n))'*phi0))^2+derta3n_2)];
        end
        HH2=sum(HH1(1:N));
        Eharvestingg_=t0*yita*HH2;
        EEg=Rtotal/(Etotalg_-Eharvestingg_);
        end
        EEe1g=[];
        for k=1:Kcluster
            EEe1g=[EEe1g (t1*((derta1_2*(norm((wk(:,k))'*g*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k(:,k)+g*phik(:,:,k)*hr_k(:,k))))^2))*SNR)];
        end
    end
    eee1=[eee1 ; EEe1]; %**********************联合
    nengxiao=[nengxiao ; EE];  
    eee1ab=[eee1ab ; EEe1ab]; %****************净能量收益
    nengxiaoab=[nengxiaoab ; EEab]; 
    eee1p=[eee1p ; EEe1p]; %*******************被动
    nengxiaop=[nengxiaop ; EEp];
    eee1u=[eee1u ; EEe1u]; %*******************仅上行
    nengxiaou=[nengxiaou ; EEu];
    eee1d=[eee1d ; EEe1d]; %*******************仅上行
    nengxiaod=[nengxiaod ; EEd];
    eee1r=[eee1r ; EEe1r]; %*******************随机
    nengxiaor=[nengxiaor ; EEr];
    eee1g=[eee1g ; EEe1g]; %*******************随机
    nengxiaog=[nengxiaog ; EEg];
end
eem=mean(eee1,1); %**********************联合
EEm=mean(nengxiao,1);
eemEb=mean(eee1ab,1); %****************净能量收益
EEmEb=mean(nengxiaoab,1);
eemP=mean(eee1p,1); %*******************被动
EEmP=mean(nengxiaop,1);
eemU=mean(eee1u,1); %*******************仅上行
EEmU=mean(nengxiaou,1);
eemD=mean(eee1d,1); %*******************仅下行
EEmD=mean(nengxiaod,1);
eemR=mean(eee1r,1); %*******************随机
EEmR=mean(nengxiaor,1);
eemG=mean(eee1g,1); %*******************共用
EEmG=mean(nengxiaog,1);



