function [g,hd_k,hr_k,hd_n,hr_n]=xindao(Kcluster,CHpositionx,CHpositiony,CRSNspositionx,CRSNspositiony,N)
% pout=db2pow(8)/1000;%pout为5dBm 10^-2.5 10dBm:10^-2; PC=PDC=-10dBm=10^-4,pIRS=10dBm=0.01
% PC=db2pow(-10)/1000;
% PDC=db2pow(-10)/1000;
% Pirs=PC+PDC;
% PS=10; %PS为30dBm 10^0 , 40dBm:10W , 37dBm:10^0.7,46dBm:40W，此处的PA是原文的PS，下同
M=10; %反射单元数
lamuda=0.3333; %信号传输波长0.325,0.3333
C0=(lamuda/(4*pi))^2; 
Nt=4; %sink天线数量
% dsink=lamuda/2; %天线之间的间隔半波长
% dx=lamuda/2;%每个RE的dx,相邻RE之间假定半波长间隔
% dy=lamuda/2;%每个RE的dy
% Kcluster=20;%20个簇,sink(0,0,0),IRS(0,yIRS,dv),CHs(x(k),y(k),0)%%%%%%%%%%改变CHs数，ECM也要改
% CHpositionx=xlsread('100jiedianECM.xlsx','C7:V7');%CH节点坐标
% CHpositiony=xlsread('100jiedianECM.xlsx','C8:V8');
x=CHpositionx;
y=CHpositiony;
% CRSNspositionx=xlsread('100jiedianECM.xlsx','C2:CX2');%CRSNs节点坐标
% CRSNspositiony=xlsread('100jiedianECM.xlsx','C3:CX3');
x1=CRSNspositionx;
y1=CRSNspositiony;
% Eelec=50*0.000000001;%发送和接收数据时电路能耗Eelec=50nJ/b 
% Efs=10*0.000000000001;%发送时功率放大器功耗取决于距离，当小于参考距离d0时为10pJ/b/m2;大于参考距离d0时为0.0013pJ/b/m4
% Emp=0.0013*0.000000000001;
% EDA=5*0.000000001; %聚合数据时消耗能量为5nJ/b/packet
% L=1000;%数据包大小1000bit,控制包大小100bit                              
% N=100;%簇内CRSNs节点总数为100
% R_=2;%簇半径为2m
% dCMtoCH=(2*R_)/3;
% ECM=L1*(Eelec+Efs*(dCMtoCH)^2);
% ECM=xlsread('100jiedianECM.xlsx','C10:C10');  %20CHs  %ECM是从CogLEACH中算出来的，此处的ECM为原文的(N-K)*ECM
% ECM=xlsread('100jiedianECM.xlsx','C14:C14');  %15CHs
% ECM=xlsread('100jiedianECM.xlsx','C18:C18');  %10CHs
% ECM=xlsread('100jiedianECM.xlsx','C22:C22');  %5CHs
% ECH_intra=((N/Kcluster)-1)*(Eelec+EDA)*L; %从CogLEACH里过来的ECH_intra是原文的K*ECH_intra
% Esink=Kcluster*Eelec*L;
% Edt=Kcluster*Eelec*L+ECM+Kcluster*ECH_intra;
% Edt=Esink+ECM+ECH_intra;
HIRS = 5; % IRS与平面的垂直距离
D0=1;%参考距离
% derta2_2=10^-11; %噪声功率-80dBm:10^-11
% derta1_2=10^-11;
% derta3n_2=10^-11;
% 路损参数
alpha_SI = 2.3; %级联链路莱斯
alpha_IC = 2.3;
alpha_SC = 2.9; %直接链路自由空间
% beta_SI = 10; %莱斯因子10  db2pow(3)
% beta_IC = 10;
% beta_SC = 10;
beta_SI = db2pow(3); %莱斯因子10  db2pow(3)
beta_IC = db2pow(3);
beta_SC = db2pow(3);
% www=[];
% t0=0.5;%sink辐射时间1s
% t1=0.001;%CH k上行数据传输时长0.01s  此处的t1为原文的taok  taok=L/Rs=1000/10^6=0.001s
% SNR=db2pow(30);%30dB
% Bt=100000; %信道带宽  Rb=Blog2(1+SNR),Rb=1Mbps,SNR=30dB,推出B=1.0033e+05
% R=Bt*log2(1+SNR);
% tintra=(N/Kcluster-1)*(L/(Bt*log2(1+SNR)));
% T=Kcluster*t1+t0+tintra;
% Rtotal=((Bt*log2(1+SNR))*Kcluster*tintra+(t1*Kcluster)*R)/(T-t0);
% Rtotal=R; %Rtotal为R的倍数
% yita=0.8; %能量转换效率
% epsilon=1e-3;
% maxIter=20;
% eee1=[];
% eee=[]; %建立空数组，为最后100次取平均值做准备
% hhh=[];
% ppk=[];
% nengxiao=[];
yIRS=-0.4;   %IRS:(0,yIRS,dv)-50:0.1:50
sinkloc=[0;0;0]; %sink坐标[0,0,0]
CHsloc=[];
IRSloc=[0;yIRS;HIRS];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%远场条件下IRS一块板反射信号，不具体表示每个RE的坐标%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
dIS=sqrt(sum((IRSloc-sinkloc).^2)); %IRS到sink之间的距离Nt*M
for k=1:Kcluster
    CHsloc=[CHsloc [x(:,k);y(:,k);0]];
end
dCS=[];
for k=1:Kcluster
    dCS=[dCS sqrt(sum((sinkloc-CHsloc(:,k)).^2))];%sink到CHs距离Nt*1
end
dCI=[];
for k=1:Kcluster
    dCI=[dCI sqrt(sum((CHsloc(:,k)-IRSloc).^2))]; %CHs到IRS距离M*1
end
g=sqrt(C0*((dIS/D0).^(-alpha_SI)))*(sqrt(beta_SI/(beta_SI+1))*ones(Nt,M)+sqrt(1/(beta_SI+1))*(sqrt(1/2)*(randn(Nt,M)+1j*randn(Nt,M))));
for k=1:Kcluster
    hr_k(:,k)=sqrt(C0.*(((dCI(1,k))./D0).^(-alpha_IC)))*(sqrt(beta_IC/(beta_IC+1))*ones(M,1)+sqrt(1/(beta_IC+1))*(sqrt(1/2)*(randn(M,1)+1j*randn(M,1)))); %上行CH到IRS信道M*1
end
for k=1:Kcluster
    hd_k(:,k)=sqrt(C0.*((dCS(:,k)./D0).^(-alpha_SC)))*(sqrt(beta_SC/(beta_SC+1))*ones(Nt,1)+sqrt(1/(beta_SC+1))*(sqrt(1/2)*(randn(Nt,1)+1j*randn(Nt,1)))); %上行CH到sink信道Nt*1
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%上行信道构建完毕，开始构建下行信道%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
CRSNsloc=[];
for n=1:N
    CRSNsloc=[CRSNsloc [x1(:,n);y1(:,n);0]];
end
dSC=[];
for n=1:N
    dSC=[dSC sqrt(sum((CRSNsloc(:,n)-sinkloc).^2))];%sink到CRSNs距离Nt*1
end
dIC=[];
for n=1:N
    dIC=[dIC sqrt(sum((CRSNsloc(:,n)-IRSloc).^2))]; %IRS到CRSNs距离1*M
end
for n=1:N
    hr_n(:,n)=sqrt(C0.*(((dIC(1,n))./D0).^(-alpha_IC)))*(sqrt(beta_IC/(beta_IC+1))*ones(M,1)+sqrt(1/(beta_IC+1))*(sqrt(1/2)*(randn(M,1)+1j*randn(M,1)))); %hr,n维度M*1
end
for n=1:N
    hd_n(:,n)=sqrt(C0.*((dSC(1,n)./D0).^(-alpha_SC)))*(sqrt(beta_SC/(beta_SC+1))*ones(Nt,1)+sqrt(1/(beta_SC+1))*(sqrt(1/2)*(randn(Nt,1)+1j*randn(Nt,1))));
end