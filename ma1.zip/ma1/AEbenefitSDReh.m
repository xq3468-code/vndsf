function [w0] = AEbenefitSDReh(g, hr_n, hd_n, M, Nt, phi0, N, PS, pout, derta1_2, derta3n_2, t0, yita)
        G1=phi0*g';  %M*Nt
        I0=derta1_2*(norm(phi0*eye(M)))^2;  %1*1
        for n=1:N
            hrn(:,n)=derta1_2*(norm((hr_n(:,n))'*phi0))^2;  %1*1
        end
        hn=[];
        for n=1:N
            hn=[hn ; ((hd_n(:,n))'+(hr_n(:,n))'*phi0*g')];  %1*Nt
        end
        C1=0;
        for n=1:N
            Cn1(:,:,n)=PS*((hn(n,:))'*hn(n,:));
            C1=C1+Cn1(:,:,n);
        end
        C=t0*yita*C1;
        HZ1=0;
        for n=1:N
            Hz1(:,n)=hrn(:,n)+derta3n_2;
            HZ1=HZ1+Hz1(:,n);
        end
        HZ=t0*yita*HZ1;
        BB=PS*(G1'*G1);  %BB为原文的B 
        cvx_begin sdp quiet
            variable W0(Nt,Nt) hermitian semidefinite; 
%             minimize real(Y1+Edt+t0*(PS*trace(W0)+M*PIRS+trace(BB*W0)+I0)-t0*yita*Z1);
            maximize real(trace(C*W0)+HZ);
            subject to
            real(trace(BB*W0)+I0)<=pout;
            real(trace(W0))<=1;
            W0==hermitian_semidefinite(Nt);
       cvx_end
       %恢复秩1解
       max_F=-10;
       max_w2=0;
       L=10000;
       [U2, Sigma2] = eig(W0);
       for l = 1 : L
%            w1=[];
%            r1=sqrt(2)/2*(randn(Nt,1)+1j*randn(Nt,1));
%            w1=conj(w11);
           r2=sqrt(2)/2*(randn(Nt,1)+1j*randn(Nt,1));
           w2=U2 * (Sigma2)^(0.5) * r2;  %构造秩1矩阵解
%            ss=[];
           F=w2'*C*w2+HZ;
           if (F > max_F && w2'*BB*w2+I0<=pout && w2'*w2<=1 )
              max_F = F;
              max_w2 = w2;
           end
       end
       w0=max_w2;
%        wk=conj(wkg);
%%******************验证矩阵的秩是否为1****************
%        [U, S, V] = svd(W0);
%        r = rank(W0);
%        if r == 1
%            disp('矩阵W0的秩为1');
%        else
%            disp('矩阵W0的秩不为1');
%        end 
%%************************************************
%        for k=1:K
%            if ((((w1(:,k))'*Ak(:,:,k)*(w1(:,k)))/((w1(:,k))'*Hk(:,:,k)*(w1(:,k))))*SNR*hrk(:,k)+Ik(:,k)<=pout && (w1(:,k))'*(w1(:,k))<=1)
%               ttt(k)=1;
%            else
%                ttt(k)=0;
%            end
%        end
%%************************************************
end