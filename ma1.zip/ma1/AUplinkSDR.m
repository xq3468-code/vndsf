function [wk] = AUplinkSDR(hr_k, g, hd_k, M, Nt, phik, Kcluster, SNR, Pirs, pout, derta1_2, derta2_2, Edt, t1)
       for k=1:Kcluster
            hk(:,k)=hd_k(:,k)+g*phik(:,:,k)*hr_k(:,k);  %Nt*1
            Gk(:,:,k)=g*phik(:,:,k);   %Nt*M
            hrk(:,k)=(norm(phik(:,:,k)*hr_k(:,k)))^2;   %1*1
            Ik(:,k)=derta1_2*(norm(phik(:,:,k)*eye(M)))^2;   %1*1
       end
%        G1=phi0*g';  %M*Nt
%        I0=derta1_2*(norm(phi0*eye(M)))^2;  %1*1
%        for n=1:N
%            hrn(:,n)=derta1_2*(norm((hr_n(:,n))'*phi0))^2;  %1*1
%        end
%        hn=[];
%        for n=1:N
%            hn=[hn ; ((hd_n(:,n))'+(hr_n(:,n))'*phi0*g')];  %1*Nt
%        end
       
       for k=1:Kcluster
           Ak(:,:,k)=derta1_2*(Gk(:,:,k)*(Gk(:,:,k))')+derta2_2*eye(Nt);
           Hk(:,:,k)=hk(:,k)*(hk(:,k))';
       end
%        C1=0;
%        for n=1:N
%            Cn1(:,:,n)=PS*((hn(n,:))'*hn(n,:));
%            C1=C1+Cn1(:,:,n);
%        end
%        C=t0*yita*C1;
%        HZ1=0;
%        for n=1:N
%            Hz1(:,n)=hrn(:,n)+derta3n_2;
%            HZ1=HZ1+Hz1(:,n);
%        end
%        HZ=t0*yita*HZ1;
%        BB=PS*(G1'*G1);  %BB为原文的B 
       max_w1=0;
       while (size(max_w1,1)==1)
        cvx_begin sdp quiet
            variable Wk1(Nt,Nt,Kcluster) hermitian semidefinite;%此处的Wk1是原文的Wk~,即pk*Wk,非负常数乘以半正定阵仍是半正定的 
            variable pk(1,Kcluster);
            expression Y;
            Y=[];
            for k=1:Kcluster
                Y=[Y (t1*((trace(Ak(:,:,k)*Wk1(:,:,k)))*SNR+(trace(Ak(:,:,k)*Wk1(:,:,k)))*SNR*hrk(:,k)+Ik(:,k)+M*Pirs))];
            end
            maximize real(-sum(Y(1:Kcluster))-Edt);
            subject to
            for k=1:Kcluster
                real(trace(Hk(:,:,k)*Wk1(:,:,k)))==1;
                real((trace(Ak(:,:,k)*Wk1(:,:,k)))*SNR*hrk(:,k)+Ik(:,k))<=pout;
                real(trace(Wk1(:,:,k)))<=pk(:,k);
                pk(:,k)>=0;
                Wk1(:,:,k)==hermitian_semidefinite(Nt);
            end
       cvx_end
       %恢复秩1解
       for k=1:Kcluster
           WK(:,:,k)=Wk1(:,:,k)/pk(:,k);
       end
       max_F=-10;
       for k=1:Kcluster
           max_w1(:,k)=0;
       end
       L2=10000;
       for l = 1 : L2
           w1=[];
           r1=sqrt(2)/2*(randn(Nt,1)+1j*randn(Nt,1));
           for k=1:Kcluster
               [U1,Sigma1]=eig(WK(:,:,k));%对每一个WK特征值分解
               s_=U1 * (Sigma1)^(0.5) * r1;
               w1=[w1 s_];%用U*sqrt(Sigma)*r表示每个时隙生成的是，并放在同一个数组中,构造K个秩1矩阵解
           end
           ss=[];
           for k=1:Kcluster
               ss=[ss (t1*((((w1(:,k))'*Ak(:,:,k)*(w1(:,k)))/((w1(:,k))'*Hk(:,:,k)*(w1(:,k))))*SNR+...
                  (((w1(:,k))'*Ak(:,:,k)*(w1(:,k)))/((w1(:,k))'*Hk(:,:,k)*(w1(:,k))))*SNR*hrk(:,k)+Ik(:,k)+M*Pirs))];
           end
           F=-sum(ss(1:Kcluster))-Edt;
           for k=1:Kcluster
               if (((((w1(:,k))'*Ak(:,:,k)*(w1(:,k)))/((w1(:,k))'*Hk(:,:,k)*(w1(:,k))))*SNR*hrk(:,k)+Ik(:,k))<=pout && ((w1(:,k)).'*(w1(:,k)))<=1)
                   ttt(k)=1;
               else
                   ttt(k)=0;
               end
           end
           if (F > max_F && all(ttt)==1)
               max_F = F;
              max_w1 = w1;
           end
       end
      end
      wk=max_w1;
end