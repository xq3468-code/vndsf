function [wk, w0] = SDR_solving(hr_k, g, hd_k, hr_n, hd_n, M, Nt, phi0, phik, Kcluster, N, SNR, PS, Pirs, pout, derta1_2, derta2_2, derta3n_2, Edt, t1, t0, yita)
        for k=1:Kcluster
            hk(:,k)=hd_k(:,k)+g*phik(:,:,k)*hr_k(:,k);  %Nt*1
            Gk(:,:,k)=g*phik(:,:,k);   %Nt*M
            hrk(:,k)=(norm(phik(:,:,k)*hr_k(:,k)))^2;   %1*1
            Ik(:,k)=derta1_2*(norm(phik(:,:,k)*eye(M)))^2;   %1*1
        end
        G1=phi0*g';  %M*Nt
        I0=derta1_2*(norm(phi0*eye(M)))^2;  %1*1
        for n=1:N
            hrn(:,n)=derta1_2*(norm((hr_n(:,n))'*phi0))^2;  %1*1
        end
        hn=[];
        for n=1:N
            hn=[hn ; ((hd_n(:,n))'+(hr_n(:,n))'*phi0*g')];  %1*Nt
        end
       
        for k=1:Kcluster
            Ak(:,:,k)=derta1_2*(Gk(:,:,k)*(Gk(:,:,k))')+derta2_2*eye(Nt);
            Hk(:,:,k)=hk(:,k)*(hk(:,k))';
        end
        C1=0;
        for n=1:N
            Cn1(:,:,n)=PS*((hn(n,:))'*hn(n,:));
            C1=C1+Cn1(:,:,n);
        end
        C=t0*yita*C1;
        HZ1=0;
        for n=1:N
            Hz1(:,n)=hrn(:,n)+derta3n_2;
            HZ1=HZ1+Hz1(:,n);
        end
        HZ=t0*yita*HZ1;
        BB=PS*(G1'*G1);  %BB为原文的B 
        cvx_begin sdp quiet
        variable Wk1(Nt,Nt,Kcluster) hermitian semidefinite;%此处的Wk1是原文的Wk~,即pk*Wk,非负常数乘以半正定阵仍是半正定的
        variable W0(Nt,Nt) hermitian semidefinite;
        variable pk(1,Kcluster);
        expression Y;
        Y=[];
        for k=1:Kcluster
            Y=[Y (t1*((trace(Ak(:,:,k)*Wk1(:,:,k)))*SNR+(trace(Ak(:,:,k)*Wk1(:,:,k)))*SNR*hrk(:,k)+Ik(:,k)+M*Pirs))];
        end
        %             Y1=sum(Y(1:K));
        %             minimize real(Y1+Edt+t0*(PS*trace(W0)+M*PIRS+trace(BB*W0)+I0)-t0*yita*Z1);
        maximize real(trace(C*W0)+HZ-sum(Y(1:Kcluster))-Edt-t0*(PS*trace(W0)+M*Pirs+trace(BB*W0)+I0));
        %             maximize real(trace(C*W0)+HZ-sum(Y(1:Kcluster))-Edt);
        subject to
        for k=1:Kcluster
            real(trace(Hk(:,:,k)*Wk1(:,:,k)))==1;
            real((trace(Ak(:,:,k)*Wk1(:,:,k)))*SNR*hrk(:,k)+Ik(:,k))<=pout;
            real(trace(Wk1(:,:,k)))<=pk(:,k);
            pk(:,k)>=0;
            Wk1(:,:,k)==hermitian_semidefinite(Nt);
        end
        real(trace(BB*W0)+I0)<=pout;
        real(trace(W0))<=1;
        W0==hermitian_semidefinite(Nt);
        cvx_end
        %恢复秩1解
        % 基于惩罚的算法恢复秩1解
        % 参数初始化
%         epsilon1 = 1e-4;    % 收敛精度1
%         epsilon2 = 1e-4;    % 收敛精度2
%         p1 = 10;            % 惩罚参数1
%         p2 = 10;            % 惩罚参数2
%         max_iter = 50;      % 最大迭代次数
% 
%         % 保存第一次CVX求解的结果
%         Wk_current = Wk1;
%         W0_current = W0;
%         pk_current = pk;
% 
%         % 主循环 - 基于惩罚的秩1恢复
%         iter = 0;
%         converged = false;
% 
%         while iter < max_iter && ~converged
%             iter = iter + 1;
%             fprintf('惩罚算法迭代 %d:\n', iter);
% 
%             % 检查所有Wk的秩1条件
%             rank1_violation = zeros(1, Kcluster);
%             for k = 1:Kcluster
%                 [V, D] = eig(Wk_current(:,:,k));
%                 eigenvals = diag(D);
%                 max_eigval = max(eigenvals);
%                 trace_Wk = trace(Wk_current(:,:,k));
%                 rank1_violation(k) = abs(trace_Wk - max_eigval);
%             end
% 
%             % 如果所有Wk都满足秩1条件，则收敛
%             if all(rank1_violation <= epsilon2)
%                 fprintf('所有Wk满足秩1条件，算法收敛\n');
%                 converged = true;
%                 break;
%             end
% 
%             % 对于不满足秩1条件的k，使用惩罚算法更新
%             for k = 1:Kcluster
%                 if rank1_violation(k) > epsilon2
%                     % 获取当前Wk的最大特征向量
%                     [V, D] = eig(Wk_current(:,:,k));
%                     [max_eigval, max_idx] = max(diag(D));
%                     u_max = V(:, max_idx);
% 
%                     % 求解带惩罚项的问题(P15)
%                     cvx_begin sdp quiet
%                         variable Wk_var(Nt, Nt) hermitian semidefinite;
%                         variable pk_var(1);
% 
%                         % 惩罚项：tr(Wk) - u_max' * Wk * u_max
%                         penalty_term = p2 * (trace(Wk_var) - real(u_max' * Wk_var * u_max));
% 
%                         % 目标函数：原始目标 + 惩罚项
%                         objective = t1 * (trace(Ak(:,:,k)*Wk_var)*SNR + ...
%                             trace(Ak(:,:,k)*Wk_var)*SNR*hrk(:,k) + ...
%                             Ik(:,k) + M*Pirs) + penalty_term;
% 
%                         minimize(real(objective));
%         subject to
%                         % 约束条件
%                         real(trace(Hk(:,:,k)*Wk_var)) == 1;
%                         real((trace(Ak(:,:,k)*Wk_var))*SNR*hrk(:,k) + Ik(:,k)) <= pout;
%                         real(trace(Wk_var)) <= pk_var;
%                         pk_var >= 0;
%                         Wk_var == hermitian_semidefinite(Nt);
%                     cvx_end
% 
%                     % 检查收敛
%                     if norm(Wk_var - Wk_current(:,:,k), 'fro') <= epsilon2
%                         p2 = 2 * p2;  % 增加惩罚参数
%                         fprintf('k=%d: 增加惩罚参数 p2=%.2f\n', k, p2);
%                     else
%                         Wk_current(:,:,k) = Wk_var;
%                         pk_current(k) = pk_var;
%                         fprintf('k=%d: 更新Wk, 秩1违反度=%.6f\n', k, rank1_violation(k));
%                     end
%                 end
%             end
%         end
% 
%         % 恢复最终的秩1解
%         wk = zeros(Nt, Kcluster);
%         w0 = zeros(Nt, 1);
% 
%         % 使用高斯随机化从Wk_current恢复秩1解
%         num_rand = 100;  % 随机化次数
% 
%         for k = 1:Kcluster
%             best_obj = -inf;
%             best_w = zeros(Nt, 1);
% 
%             for rand_iter = 1:num_rand
%                 % 特征值分解
%                 [V, D] = eig(Wk_current(:,:,k));
% 
%                 % 生成随机向量
%                 r = randn(Nt, 1) + 1i*randn(Nt, 1);
%                 r = r / norm(r);
% 
%                 % 构造候选解
%                 w_candidate = V * sqrt(D) * r;
%                 w_candidate = w_candidate / norm(w_candidate) * sqrt(pk_current(k));
% 
%                 % 验证可行性
%                 W_candidate = w_candidate * w_candidate';
%                 feasible = true;
% 
%                 % 检查约束
%                 if abs(real(trace(Hk(:,:,k)*W_candidate)) - 1) > 1e-3
%                     feasible = false;
%                 end
% 
%                 if real((trace(Ak(:,:,k)*W_candidate))*SNR*hrk(:,k) + Ik(:,k)) > pout + 1e-3
%                     feasible = false;
%                 end
% 
%                 if norm(w_candidate) > sqrt(pk_current(k)) + 1e-3
%                     feasible = false;
%                 end
% 
%                 % 如果可行，计算目标函数
%                 if feasible
%                     obj_candidate = -real(t1*((trace(Ak(:,:,k)*W_candidate))*SNR + ...
%                         (trace(Ak(:,:,k)*W_candidate))*SNR*hrk(:,k) + ...
%                         Ik(:,k) + M*Pirs));
%                     if obj_candidate > best_obj
%                         best_obj = obj_candidate;
%                         best_w = w_candidate;
%                     end
%                 end
%             end
% 
%             wk(:,k) = best_w; %最终wk
%         end
% 
%         % 同样方法恢复w0
% %%%%%%%%%%%%加上
% while iter < max_iter && ~converged
%             iter = iter + 1;
%             fprintf('惩罚算法迭代 %d:\n', iter);
% 
%             % 检查所有Wk的秩1条件
%             rank1_violation = zeros(1, Kcluster);
%             for k = 1:1
%                 [V0, D0] = eig(W0_current);
%                 eigenvals0 = diag(D0);
%                 max_eigval0 = max(eigenvals0);
%                 trace_W0 = trace(W0_current);
%                 rank1_violation(k) = abs(trace_W0 - max_eigval0);
%             end
% 
%             % 如果所有Wk都满足秩1条件，则收敛
%             if all(rank1_violation <= epsilon2)
%                 fprintf('所有Wk满足秩1条件，算法收敛\n');
%                 converged = true;
%                 break;
%             end
% 
%             % 对于不满足秩1条件的k，使用惩罚算法更新
%             for k = 1:1
%                 if rank1_violation(k) > epsilon2
%                     % 获取当前Wk的最大特征向量
%                     [V0, D0] = eig(W0_current);
%                     [max_eigval0, max_idx] = max(diag(D0));
%                     u_max0 = V0(:, max_idx);
% 
%                     % 求解带惩罚项的问题(P15)
%                     cvx_begin sdp quiet
%                         variable W0_var(Nt, Nt) hermitian semidefinite;
%                         % variable pk_var(1);
% 
%                         % 惩罚项：tr(Wk) - u_max' * Wk * u_max
%                         penalty_term = p1 * (trace(W0_var) - real(u_max0' * W0_var * u_max0));
% 
%                         % 目标函数：原始目标 + 惩罚项
%                         objective = t0*(PS*trace(W0_var)+M*Pirs+trace(BB*W0_var)+I0)-real(trace(C*W0_var));
% 
%                         minimize(real(objective));
%                        subject to
%                         % 约束条件
%                         real(trace(BB*W0)+I0)<=pout;
%         real(trace(W0))<=1;
%                     cvx_end
% 
%                     % 检查收敛
%                     if norm(W0_var - W0_current(:,:,k), 'fro') <= epsilon2
%                         p1 = 2 * p1;  % 增加惩罚参数
%                         fprintf('k=%d: 增加惩罚参数 p2=%.2f\n', k, p1);
%                     else
%                         W0_current(:,:,k) = W0_var;
%                         % pk_current(k) = pk_var;
%                         fprintf('k=%d: 更新Wk, 秩1违反度=%.6f\n', k, rank1_violation(k));
%                     end
%                 end
%             end
%         end
% 
% 
% 
% 
% 
%         best_obj = -inf;
%         best_w0 = zeros(Nt, 1);
% 
%         for rand_iter = 1:num_rand
%             [V0, D0] = eig(W0_current);
% 
%             r0 = randn(Nt, 1) + 1i*randn(Nt, 1);
%             r0 = r0 / norm(r0);
% 
%             w0_candidate = V0 * sqrt(D0) * r0;
%             w0_candidate = w0_candidate / norm(w0_candidate);  % trace(W0) <= 1
% 
%             W0_candidate = w0_candidate * w0_candidate';
%             feasible = true;
% 
%             % 检查W0的约束
%             if real(trace(BB*W0_candidate) + I0) > pout + 1e-3
%                 feasible = false;
%             end
% 
%             if norm(w0_candidate) > 1 + 1e-3
%                 feasible = false;
%             end
% 
%             if feasible
%                 obj_candidate = real(trace(C*W0_candidate));
%                 if obj_candidate > best_obj
%                     best_obj = obj_candidate;
%                     best_w0 = w0_candidate;
%                 end
%             end
%         end
% 
%         w0 = best_w0; %最终w0
% 
%         % 输出结果
%         fprintf('\n基于惩罚的秩1恢复完成:\n');
%         fprintf('迭代次数: %d\n', iter);
%         fprintf('最终惩罚参数 p2: %.2f\n', p2);
%         fprintf('w0 范数: %.6f\n', norm(w0));
%         for k = 1:Kcluster
%             Wk_final = wk(:,k) * wk(:,k)';
%             rank1_quality = trace(Wk_current(:,:,k)) - norm(wk(:,k))^2;
%             fprintf('wk%d 范数: %.6f, 秩1质量: %.6f\n', k, norm(wk(:,k)), rank1_quality);
%         end
% 
%         % 验证约束满足情况
% %         fprintf('\n约束验证:\n');
%         for k = 1:Kcluster
%             Wk_final = wk(:,k) * wk(:,k)';
%             constraint1 = real(trace(Hk(:,:,k)*Wk_final));
%             constraint2 = real((trace(Ak(:,:,k)*Wk_final))*SNR*hrk(:,k) + Ik(:,k));
% %             fprintf('用户%d: 约束1=%.6f(目标1), 约束2=%.6f(<=%.6f)\n', ...
% %                 k, constraint1, constraint2, pout);
%         end
% 
%         W0_final = w0 * w0';
%         constraint_W0 = real(trace(BB*W0_final) + I0);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%         fprintf('W0约束: %.6f(<=%.6f)\n', constraint_W0, pout);
               %恢复秩1解
               for k=1:Kcluster
                   WK(:,:,k)=Wk1(:,:,k)/pk(:,k);
               end
               max_F=-10;
               max_w2=0;
               for k=1:Kcluster
                   max_w1(:,k)=0;
               end
               L2=10000;
               [U2, Sigma2] = eig(W0);
               for l = 1 : L2
                   w1=[];
                   r1=sqrt(2)/2*(randn(Nt,1)+1j*randn(Nt,1));
                   for k=1:Kcluster
                       [U1,Sigma1]=eig(WK(:,:,k));%对每一个WK特征值分解
                       s_=U1 * (Sigma1)^(0.5) * r1;
                       w1=[w1 s_];%用U*sqrt(Sigma)*r表示每个时隙生成的是，并放在同一个数组中,构造K个秩1矩阵解
                   end
                   r2=sqrt(2)/2*(randn(Nt,1)+1j*randn(Nt,1));
                   w2=U2 * (Sigma2)^(0.5) * r2;  %构造秩1矩阵解
                   ss=[];
                   for k=1:Kcluster
                       ss=[ss (t1*((((w1(:,k))'*Ak(:,:,k)*(w1(:,k)))/((w1(:,k))'*Hk(:,:,k)*(w1(:,k))))*SNR+...
                          (((w1(:,k))'*Ak(:,:,k)*(w1(:,k)))/((w1(:,k))'*Hk(:,:,k)*(w1(:,k))))*SNR*hrk(:,k)+Ik(:,k)+M*Pirs))];
                   end
                   F=w2'*C*w2+HZ-sum(ss(1:Kcluster))-Edt-t0*(PS*(w2'*w2)+M*Pirs+(w2'*BB*w2)+I0);
        %            F=w2'*C*w2+HZ-sum(ss(1:Kcluster))-Edt;
                   for k=1:Kcluster
                       if (((((w1(:,k))'*Ak(:,:,k)*(w1(:,k)))/((w1(:,k))'*Hk(:,:,k)*(w1(:,k))))*SNR*hrk(:,k)+Ik(:,k))<=pout && ((w1(:,k)).'*(w1(:,k)))<=1)
                           ttt(k)=1;
                       else
                           ttt(k)=0;
                       end
                   end
                   if (F > max_F && (w2'*BB*w2+I0)<=pout && (w2'*w2)<=1 && all(ttt)==1)
                      max_F = F;
                      max_w1 = w1;
                      max_w2 = w2;
                   end
               end
              w0=max_w2;
              wk=max_w1;
end