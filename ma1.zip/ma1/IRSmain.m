clear;
clc;
%编写主函数，在主函数中调用各种分簇算法，在相同条件下比较各算法性能，性能评价指标包括：
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%第r轮选取的CH数目Clusterhead
%第r轮选取结束时存活的节点数目Numberoflive
%第r轮选取CH的开销OverheadofCH
%第r轮选取构建簇的开销Overheadofcluster
%第r轮能够有效收集数据的节点数目NumberofAcquisition
%第r轮能够有效收集数据的节点比例RatioofAcquisition
%第r轮结束时每个节点的剩余能量Energy
%第r轮各簇头的能耗CHE
%第r轮各簇的能耗ClusterE
%第一个节点死亡的轮数_first_dead
%最后一个节点死亡的轮数_last_dead
%第r轮选取合法节点的开销overheadofeligible
%第r轮路由开销routingoverhead

%最后可能还需要添加：分簇有效覆盖面积；与PUs冲突次数等-2019-12-8
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%定义sink位置
sink.x=0;
sink.y=0;



%定义网络中CRSNs节点数目-100个节点，网络半径50m—1层
n=100;
SUpositionx=xlsread('100jiedianECM.xlsx','C2:CX2');
SUpositiony=xlsread('100jiedianECM.xlsx','C3:CX3');


%能耗模型：感知事件和数据记录能耗是所有节点都要的
E=0.5;  %节点初始能量为0.5J
ETX=50*0.000000001; %发送和接收数据时电路能耗Eelec=50nJ/b
Efs=10*0.000000000001; %发送时功率放大器功耗取决于距离，当小于参考距离d0时为10pJ/b/m2;大于参考距离d0时为0.0013pJ/b/m4
Emp=0.0013*0.000000000001;
EDA=5*0.000000001; %聚合数据时消耗能量为5nJ/b
d0=sqrt(Efs/Emp);%计算参考距离d0=87.7m
ESW=10*0.000000001; %信道转换的能耗10nJ，非常重要，现在要纳入考虑-2021-7-13

%两种包大小：数据包和控制包
L=1000;  %数据包大小，单位bit
L1=100;   %控制包大小，一般用于传输频谱相关的信息，如是否占用、PUs出现概率、信道期望空闲时间等；TDMA调度；CH通告消息；CM加入请求。

%定义节点的传输范围，从50m开始增加直到85m，步长是5m，因为传感节点的最大传输范围不超百米，这么设置保证簇内传输是符合自由空间路径损耗模型-2019-11-27
nodetransmissionrange=50; 

%定义与PUs相关的参数：随机部署的PUs数为5；PUs的干扰保护范围为20m，即与PUs距离小于20m的节点不能使用PUs正在使用的信道；网络中可用信道数为5。
%一般来说PUs数量和可用信道数是相同的
m=5; %PUs数为5
IPR=20; %PUs的干扰保护范围为20m
c=5; %网络中可用信道数为5
PUpositionx=xlsread('100jiedianECM.xlsx','C4:G4');
PUpositiony=xlsread('100jiedianECM.xlsx','C5:G5');
PUchannel=xlsread('100jiedianECM.xlsx','C6:G6');



%产生CRSNs节点信息和PUs相关信息图
figure(1);
%生成CRSNs节点信息
for i=1:1:n
    S(i).xd=SUpositionx(i);  %节点i的横坐标
    S(i).yd=SUpositiony(i); %节点i的纵坐标
    S(i).e=E; %节点i的初始能量
    S(i).type='N'; %节点i的类型初始化为非合法节点
    S(i).diantance=0; %注：只有Fuzzy C-means使用，在选取CH时用来记录CH选取函数的值，用节点能量*节点与FC之间信道的SNR值/(a*路径损耗1+(1-a)*路径损耗2)-2018-11-14
    S(i).t=0; %大多数分簇协议中表示节点当前可用信道数初始化为0，在LEACH、ABCC、Fuzzy C-means这样的分簇协议中表示节点随机选取的信道-2019-12-10
    S(i).ch=0; %将节点所属的CH号初始化为0
    S(i).G=0; %只有LEACH协议使用此参数
    plot(S(i).xd,S(i).yd,'m.');
    %text(S(i).xd,S(i).yd,num2str(i,'SU-%d')); %标出节点号
    hold on;
end

S(n+1).xd=sink.x;
S(n+1).yd=sink.y;
plot(S(n+1).xd,S(n+1).yd,'b*');
hold on;
%生成PUs相关信息
for i=1:1:m
    P(i).xd=PUpositionx(i);
    P(i).yd=PUpositiony(i);  
    plot(P(i).xd,P(i).yd,'gs');
    %text(P(i).xd,P(i).yd,num2str(i,'PU-%d')); %标出节点号
    hold on;
end

for i=1:1:n
    S(i).d=sqrt((S(i).xd-S(n+1).xd)^2+(S(i).yd-S(n+1).yd)^2); %每个CRSNs节点到sink的距离
end

 %定义各分簇算法比较时使用的指标
 rmax=10000;  %算法运行的最大轮数-最大层数为2，即100个节点时-2020-5-19
%  rmax=100;
 Tmax=6000;  %定义PUs活动模型的轮数，可以设置的比rmax略大，防止出现不够用的情况-2018-12-29
 %产生与PUs信道使用模型相关的参数-2018-12-25
 roundtime=0.5; %设置每轮的时长，根据这个时长设置产生对应的on和off序列
 Ron=xlsread('100jiedianECM.xlsx','C25:HVV29');
 Roff=xlsread('100jiedianECM.xlsx','C30:HVV34');
%  PS=10; %sink发送功率
%  [hhm]=Eharvesting(PS); %*******************************联合
%  EH_in=hhm;
%  [ebhhm]=AEbenefit_Eharvesting(PS); %*******************净能量收益
%  EH_inab=ebhhm;
%  [phhm] = passiveEh(PS); %******************************被动
%  EH_inp=phhm;
%  [shhm]=SingleEH(PS); %*********************************单天线
%  EH_ins=shhm;
%  [uhhm]=AUplinkEH(PS);
%  EH_inu=uhhm; %*****************************************仅优化上行
%  EH_ind=EH_in;  %***************************************仅优化下行
%  [hhmr]=ARandomEH(PS);
%  EH_inr=hhmr;%******************************************随机反射因子
%  EH_ing=EH_in;%*****************************************共用
 EH_in=xlsread('data.xlsx','B3:CW3');
 EH_innirs=xlsread('data.xlsx','B4:CW4');
 EH_inab=xlsread('data.xlsx','B5:CW5');
 EH_inp=xlsread('data.xlsx','B6:CW6');
 EH_ins=xlsread('data.xlsx','B7:CW7');
 EH_inu=xlsread('data.xlsx','B8:CW8');
 EH_ind=xlsread('data.xlsx','B9:CW9');
 EH_inr=xlsread('data.xlsx','B10:CW10');
 EH_ing=xlsread('data.xlsx','B11:CW11');
%  EH_in=xlsread('100jiedianECM.xlsx','C37:CX37'); %每个CRSNs节点收集的能量
%  fsamp=xlsread('nodeposition.xlsx','B33:AHQ33');%CPIRSE需要使用的每个节点的能耗系数
  %求信道上的PUs出现概率及信道的期望可用时间
 BUSY=zeros(m,rmax); %指示每轮起始时PU是否占用信道
 WILLBUSY=zeros(m,rmax); %指示的是每轮过程中PUs是否索回信道
 for i=1:1:m
     for r=1:1:rmax
         t1=roundtime*(r-1);
         t2=roundtime*r;
         puround=0; %初始化
         busy=0;    %初始化
         willbusy=0;%初始化
         if t1<=Ron(i,1)+Roff(i,1)  %这是一种特殊的情况，需要考虑PUround可能等于1的情况
            if t1<=Ron(i,1)         %ON状态代表主用户占用
               busy=1;
            else
                if t2<=Ron(i,1)+Roff(i,1)
                   busy=0;
                   willbusy=0;
                else
                    busy=0;
                    willbusy=1;
                end
            end
         else
             for k=1:1:Tmax-1
                 z1=0;   %每次循环时z1和z2的值都要重新归零
                 z2=0;
                 for j=1:1:k
                     z1=z1+Ron(i,j)+Roff(i,j);
                 end
                 z2=z1+Ron(i,k+1);
                 if t1>z1
                    if t1<=z2
                       busy=1;
                       puround=k+1;
                    else
                        if t1>z2 && t1<=z2+Roff(i,k+1)
                           puround=k+1;
                           if t2<=z2+Roff(i,k+1)
                              busy=0;
                              willbusy=0;
                           else
                               busy=0;
                               willbusy=1;
                           end
                        end
                    end
                 end
                 if puround~=0
                    break;
                 end
             end
         end
         BUSY(i,r)=busy;
         WILLBUSY(i,r)=willbusy;
     end
 end
 
  %为各SUs计算可用信道及PUs出现概率、信道期望可用时间
 for i=1:1:n
     for j=1:1:c
         for k=1:1:rmax
             occupy(i,j,k)=0; %记录第i个SU的第j条信道在第k轮起始时是否被占用，被占用则occupy(i,j,k)=1，否则，occupy(i,j,k)=0
             willoccupy(i,j,k)=0; %记录第i个SU的第j条信道在第k轮是否会被PU索回，被索回则willoccupy(i,j,k)=1，否则，willoccupy(i,j,k)=0
             availabletime(i,j,k)=0; %记录第i个SU的第j条信道在第k轮的期望可用时间
             probabilityPUappear(i,j,k)=0; %记录第i个SU的第j条信道在第k轮的PUs出现概率预测值
         end
     end
 end
 
 %计算信道是否被占用及是否被索回
 for i=1:1:n
     for j=1:1:m
         if sqrt((S(i).xd-P(j).xd)^2+(S(i).yd-P(j).yd)^2)<=IPR
            for k=1:1:rmax
                occupy(i,PUchannel(j),k)=max(occupy(i,PUchannel(j),k),BUSY(j,k));
                willoccupy(i,PUchannel(j),k)=max(willoccupy(i,PUchannel(j),k),WILLBUSY(j,k));
            end
         end
     end
 end
 
%计算信道的期望可用时间
 for i=1:1:n
     for k=1:1:rmax
         for j=1:1:c
             if k==1
                if occupy(i,j,k)==1
                   availabletime(i,j,k)=0;
                else
                    availabletime(i,j,k)=roundtime*0.5;
                end
             else
                 if occupy(i,j,k)==1
                    availabletime(i,j,k)=availabletime(i,j,k-1)*0.5;
                 else
                     availabletime(i,j,k)=availabletime(i,j,k-1)*0.5+roundtime*0.5; %通过指数加权得到
                 end
             end
         end
     end
 end
 
 %计算信道上的PUs出现概率
 for i=1:1:n
     for k=2:1:rmax
         for j=1:1:c
             Onetimes=0; %将过去r-1轮中PUs出现的次数记为Onetimes
             for s=1:1:k-1
                 if (occupy(i,j,s)+willoccupy(i,j,s))~=0
                    Onetimes=Onetimes+1;
                 end
             end
             probabilityPUappear(i,j,k)=Onetimes/(k-1);
         end
     end
 end
 
 %%将产生的CRSNs节点相关信息赋值给对应的结构体变量以方便后面每种分簇算法进行独立调用
 for i=1:1:n
%       %CPIRSE协议使用S2作为输入
%      S2(i).xd=S(i).xd;  %节点i的横坐标
%      S2(i).yd=S(i).yd; %节点i的纵坐标
%      S2(i).e=S(i).e; %节点i的初始能量
%      S2(i).d=S(i).d;
%      S2(i).type=S(i).type; %节点i的类型
%           
%      %EBUCRP协议使用S1作为输入
%      S1(i).xd=S(i).xd;  %节点i的横坐标
%      S1(i).yd=S(i).yd; %节点i的纵坐标
%      S1(i).e=S(i).e; %节点i的初始能量
%      S1(i).d=S(i).d;
%      S1(i).type=S(i).type; %节点i的类型
%      
%  
     %考虑CH到sink传输范围的IRSCogLEACH协议使用S4作为输入-2019-12-8
     S4(i).xd=S(i).xd;  %节点i的横坐标
     S4(i).yd=S(i).yd; %节点i的纵坐标
     S4(i).e=S(i).e; %节点i的初始能量
     S4(i).type=S(i).type; %节点i的类型
     S4(i).t=S(i).t; %节点当前可用信道数
     S4(i).ch=S(i).ch; %将节点所属的CH号
%      
      %考虑CH到sink传输范围的原始CogLEACH协议使用S44作为输入-2019-12-8
%      S44(i).xd=S(i).xd;  %节点i的横坐标
%      S44(i).yd=S(i).yd; %节点i的纵坐标
%      S44(i).e=S(i).e; %节点i的初始能量
%      S44(i).type=S(i).type; %节点i的类型
%      S44(i).t=S(i).t; %节点当前可用信道数
%      S44(i).ch=S(i).ch; %将节点所属的CH号
     %考虑CH到sink传输范围的CogLEACH_C协议使用S6作为输入
%      S6(i).xd=S(i).xd;  %节点i的横坐标
%      S6(i).yd=S(i).yd; %节点i的纵坐标
%      S6(i).e=S(i).e; %节点i的初始能量
%      S6(i).type=S(i).type; %节点i的类型
%      S6(i).t=S(i).t; %节点当前可用信道数
%      S6(i).ch=S(i).ch; %将节点所属的CH号
     
     
     %考虑CH到sink传输范围的LEAUCH协议使用S8作为输入
%      S8(i).xd=S(i).xd;  %节点i的横坐标
%      S8(i).yd=S(i).yd; %节点i的纵坐标
%      S8(i).e=S(i).e; %节点i的初始能量
%      S8(i).type=S(i).type; %节点i的类型
%      S8(i).t=S(i).t; %节点当前可用信道数
%      S8(i).ch=S(i).ch; %将节点所属的CH号
     
     
%      %考虑CH到sink传输范围的Fuzzy-C-means协议使用S10作为输入
%      S10(i).xd=S(i).xd;  %节点i的横坐标
%      S10(i).yd=S(i).yd; %节点i的纵坐标
%      S10(i).e=S(i).e; %节点i的初始能量
%      S10(i).type=S(i).type; %节点i的类型
%      S10(i).diantance=S(i).diantance; %注：在选取CH时用来记录CH选取函数的值，用节点能量*节点与FC之间信道的SNR值/(a*路径损耗1+(1-a)*路径损耗2)-2018-11-14
%      S10(i).t=S(i).t;  %节点i随机选取的信道-2019-4-26
    
     
%      %DSAC协议最优调度下使用S15作为输入
%      S15(i).xd=S(i).xd;  %节点i的横坐标
%      S15(i).yd=S(i).yd; %节点i的纵坐标
%      S15(i).e=S(i).e; %节点i的初始能量
%      ClusterHeadF(i)=-1;%定义簇头向量ClusterHeadF
%      for j=1:1:n
%          ClusterF(i,j)=0;%定义簇成员矩阵ClusterF
%      end
%      for j=1:1:c
%          ClusterchannelF(i,j)=0; %定义簇信道矩阵ClusterchannelF
%      end
% 
%      
%      %WCM-based SAC协议最优调度下使用S19作为输入
%      S19(i).xd=S(i).xd;  %节点i的横坐标
%      S19(i).yd=S(i).yd; %节点i的纵坐标
%      S19(i).e=S(i).e; %节点i的初始能量
%      
%      
%      %NSAC协议最优调度下使用S21作为输入
%      S21(i).xd=S(i).xd;  %节点i的横坐标
%      S21(i).yd=S(i).yd; %节点i的纵坐标
%      S21(i).e=S(i).e; %节点i的初始能量
% %      
% %      
%      %IMOCRP协议使用S13作为输入
%      S13(i).xd=S(i).xd;  %节点i的横坐标
%      S13(i).yd=S(i).yd; %节点i的纵坐标
%      S13(i).e=S(i).e; %节点i的初始能量
%      S13(i).t=S(i).t;
 end
 
 
for r=1:1:rmax
%     WCM-based SAC需要CONFIDENCE矩阵
%     for i=1:1:n
%         CONFIDENCE(i,r)=0; %-2019-12-13
%     end


%      %每轮产生的CH数目
%      CPIRSE_Clusterhead(r)=0;  %将CPIRSE协议运行时第r轮选取的簇头数初始化为0
%      EBUCRP_Clusterhead(r)=0;  %将EBUCRP协议运行时第r轮选取的簇头数初始化为0
     MCogLEACH_Clusterhead(r)=0;  %将MCogLEACH_C协议运行时第r轮选取的簇头数初始化为0
%      CogLEACH_Clusterhead(r)=0; 
% %      MCogLEACHC_Clusterhead(r)=0;  %将MCogLEACH_C协议运行时第r轮选取的簇头数初始化为0
% %      MLEAUCH_Clusterhead(r)=0;  %将MLEAUCH协议运行时第r轮选取的簇头数初始化为0
% %      MFuzzy_Clusterhead(r)=0;  %将MFuzzy-C-means协议运行时第r轮选取的簇头数初始化为0
%      DSAC_Clusterhead(r)=0;  %将DSAC协议最优调度运行时第r轮选取的簇头数初始化为0
%      WCM_Clusterhead(r)=0;  %将WCM-based SAC协议协议运行时第r轮选取的簇头数初始化为0
%      NSAC_Clusterhead(r)=0;  %将NSAC协议协议运行时第r轮选取的簇头数初始化为0
%      ION_Clusterhead(r)=0;

     %每轮过后活着的节点数目
%      CPIRSE_Numberoflive(r)=0;  %将运行CPIRSE协议第r轮结束时活着的节点总数初始化为0
%      EBUCRP_Numberoflive(r)=0;  %将运行EBUCRP协议第r轮结束时活着的节点总数初始化为0
     MCogLEACH_Numberoflive(r)=0;      %联合   %将运行MCogLEACH协议第r轮结束时活着的节点总数初始化为0
     MCogLEACH_Numberoflivenirs(r)=0;  %无IRS
     MCogLEACH_Numberofliveab(r)=0;    %净能量收益
     MCogLEACH_Numberoflivep(r)=0;     %被动
     MCogLEACH_Numberoflives(r)=0;     %单天线
     MCogLEACH_Numberofliveu(r)=0;     %仅上行
     MCogLEACH_Numberoflived(r)=0;     %仅下行
     MCogLEACH_Numberofliver(r)=0;     %随机反射因子
     MCogLEACH_Numberofliveg(r)=0;     %共用反射因子
%      CogLEACH_Numberoflive(r)=0;
% %      MCogLEACHC_Numberoflive(r)=0;  %将运行MCogLEACH_C协议第r轮结束时活着的节点总数初始化为0
% %      MLEAUCH_Numberoflive(r)=0;  %将运行MLEAUCH协议第r轮结束时活着的节点总数初始化为0
% %      MFuzzy_Numberoflive(r)=0;  %将运行MFuzzy-C-means协议第r轮结束时活着的节点总数初始化为0
%      DSAC_Numberoflive(r)=0;  %将运行DSAC协议最优调度下第r轮结束时活着的节点总数初始化为0
%      WCM_Numberoflive(r)=0;  %将运行WCM-based SAC协议第r轮结束时活着的节点总数初始化为0
%      NSAC_Numberoflive(r)=0;  %将运行NSAC协议第r轮结束时活着的节点总数初始化为0
%      ION_Numberoflive(r)=0;
     

%      %每轮过后所有节点的剩余能量
%      MCogLEACH_Residualenergy(:,r)=zeros(100,1);
%      MCogLEACH_Residualenergynirs(:,r)=zeros(100,1);
%      MCogLEACH_Residualenergyab(:,r)=zeros(100,1);
%      MCogLEACH_Residualenergyp(:,r)=zeros(100,1);
%      MCogLEACH_Residualenergys(:,r)=zeros(100,1);
%      MCogLEACH_Residualenergyu(:,r)=zeros(100,1);
%      MCogLEACH_Residualenergyd(:,r)=zeros(100,1);
%      MCogLEACH_Residualenergyr(:,r)=zeros(100,1);
%      MCogLEACH_Residualenergyg(:,r)=zeros(100,1);
     %每轮中选取CH的开销，计算的是消息数量
%      CPIRSE_overheadofCH(r)=0;  %运行CPIRSE协议第r轮选取CH的开销，即发送的消息数量
%      EBUCRP_overheadofCH(r)=0;  %运行EBUCRP协议第r轮选取CH的开销，即发送的消息数量
%      MCogLEACH_overheadofCH(r)=0;  %运行MCogLEACH协议第r轮选取CH的开销，即发送的消息数量
%      CogLEACH_overheadofCH(r)=0; 
% %      MCogLEACHC_overheadofCH(r)=0;  %运行MCogLEACH_C协议第r轮选取CH的开销，即发送的消息数量
% %      MLEAUCH_overheadofCH(r)=0;  %运行MLEAUCH协议第r轮选取CH的开销，即发送的消息数量
% %      MFuzzy_overheadofCH(r)=0;  %运行MFuzzy-C-means协议第r轮选取CH的开销，即发送的消息数量
%      DSAC_overheadofCH(r)=0;  %运行DSAC协议最优调度下第r轮选取CH的开销，即发送的消息数量
%      WCM_overheadofCH(r)=0;  %运行WCM-based SAC协议第r轮选取CH的开销，即发送的消息数量
%      NSAC_overheadofCH(r)=0;  %运行NSAC协议第r轮选取CH的开销，即发送的消息数量
%      ION_overheadofCH(r)=0;
%      
     %每轮中选取完CH后构建簇的开销
%      CPIRSE_overheadofcluster(r)=0;  %运行CPIRSE协议第r轮建立簇的开销，即选完CH后建立簇发送的消息数量
%      EBUCRP_overheadofcluster(r)=0;  %运行EBUCRP协议第r轮建立簇的开销，即选完CH后建立簇发送的消息数量
%      MCogLEACH_overheadofcluster(r)=0;  %运行MCogLEACH协议第r轮建立簇的开销，即选完CH后建立簇发送的消息数量
%      CogLEACH_overheadofcluster(r)=0; 
% %      MCogLEACHC_overheadofcluster(r)=0;  %运行MCogLEACH_C协议第r轮建立簇的开销，即选完CH后建立簇发送的消息数量
% %      MLEAUCH_overheadofcluster(r)=0;  %运行MLEAUCH协议第r轮建立簇的开销，即选完CH后建立簇发送的消息数量
% %      MFuzzy_overheadofcluster(r)=0;  %运行MFuzzy-C-means协议第r轮建立簇的开销，即选完CH后建立簇发送的消息数量
%      DSAC_overheadofcluster(r)=0;  %运行DSAC协议最优调度下第r轮建立簇的开销，即选完CH后建立簇发送的消息数量
%      WCM_overheadofcluster(r)=0;  %运行WCM-based SAC协议最差调度下第r轮建立簇的开销，即选完CH后建立簇发送的消息数量
%      NSAC_overheadofcluster(r)=0;  %运行NSAC协议最差调度下第r轮建立簇的开销，即选完CH后建立簇发送的消息数量
%      ION_overheadofcluster(r)=0;
     
     %补充：每轮中真正能够进行数据收集的节点数量，数量越多说明信息收集越有效-2018-11-13
%      CPIRSE_NumberofAcquisiton(r)=0;
%      EBUCRP_NumberofAcquisiton(r)=0; 
%      MCogLEACH_NumberofAcquisiton(r)=0;
%      CogLEACH_NumberofAcquisiton(r)=0;
% %      MCogLEACHC_NumberofAcquisiton(r)=0;
% %      MLEAUCH_NumberofAcquisiton(r)=0;
% %      MFuzzy_NumberofAcquisiton(r)=0;
%      DSAC_NumberofAcquisiton(r)=0;
%      WCM_NumberofAcquisiton(r)=0;
%      NSAC_NumberofAcquisiton(r)=0;
%      ION_NumberofAcquisiton(r)=0;
     
     %新加：每轮中真正能够进行数据收集的节点比例，它是真正能够收集到数据的节点数目与有资格收集数据的节点数目的比值。它是衡量CH选取、分簇构建整体效率的一个指标-2019-2-19  
%      CPIRSE_RatioofAcquisiton(r)=0;
%      EBUCRP_RatioofAcquisiton(r)=0;
%      MCogLEACH_RatioofAcquisiton(r)=0; 
%      CogLEACH_RatioofAcquisiton(r)=0; 
% %      MCogLEACHC_RatioofAcquisiton(r)=0;  
% %      MLEAUCH_RatioofAcquisiton(r)=0;
% %      MFuzzy_RatioofAcquisiton(r)=0;
%      DSAC_RatioofAcquisiton(r)=0;  
%      WCM_RatioofAcquisiton(r)=0;
%      NSAC_RatioofAcquisiton(r)=0; 
%      ION_RatioofAcquisiton(r)=0;
     
     %平均时延
%      CPIRSE_Timedelay(r)=0;
%      EBUCRP_Timedelay(r)=0;
%      MCogLEACH_Timedelay(r)=0;
% %      MCogLEACHC_Timedelay(r)=0;  
% %      MLEAUCH_Timedelay(r)=0;
% %      MFuzzy_Timedelay(r)=0;
%      DSAC_Timedelay(r)=0;
%      WCM_Timedelay(r)=0;
%      NSAC_Timedelay(r)=0;
%      ION_Timedelay(r)=0;
     
     %每轮所有节点的控制能耗
%      CPIRSE_TotalEnergyConsumption(r)=0;
%      EBUCRP_TotalEnergyConsumption(r)=0;
%      MCogLEACH_TotalEnergyConsumption(r)=0;
%      CogLEACH_TotalEnergyConsumption(r)=0;
% %      MCogLEACHC_TotalEnergyConsumption(r)=0;  
% %      MLEAUCH_TotalEnergyConsumption(r)=0;
% %      MFuzzy_TotalEnergyConsumption(r)=0;
%      DSAC_TotalEnergyConsumption(r)=0;
%      WCM_TotalEnergyConsumption(r)=0;
%      NSAC_TotalEnergyConsumption(r)=0;
%      ION_TotalEnergyConsumption(r)=0;

     %每轮所有节点的控制能耗
%      CPIRSE_TotalEnergyConsumption(r)=0;
%      EBUCRP_TotalEnergyConsumption(r)=0;
%      MCogLEACH_TotalEnergyConsumptionCH(r)=0;
%      CogLEACH_TotalEnergyConsumptionCH(r)=0;

       %每轮系统的能效
%      CPIRSE_TotalEnergyConsumption(r)=0;
%      EBUCRP_TotalEnergyConsumption(r)=0;
     MCogLEACH_EnergyEfficiency(r)=0;      %联合
     MCogLEACH_EnergyEfficiencyNIRS(r)=0;  %无IRS
     MCogLEACH_EnergyEfficiencyEb(r)=0;    %净能量收益
     MCogLEACH_EnergyEfficiencyP(r)=0;     %被动
     MCogLEACH_EnergyEfficiencyS(r)=0;     %单天线
     MCogLEACH_EnergyEfficiencyU(r)=0;     %仅上行
     MCogLEACH_EnergyEfficiencyD(r)=0;     %仅下行
     MCogLEACH_EnergyEfficiencyR(r)=0;     %随机反射因子
     MCogLEACH_EnergyEfficiencyG(r)=0;     %共用反射因子
%      CogLEACH_EnergyEfficiency(r)=0;

     %路由开销，即为寻找路由洪泛的RREQ包数量-2018-11-25
%      DSAC_routingoverhead(r)=0;
%      EACRP_routingoverhead(r)=0; 
%      CPIRSE_overheadofCHtosink(r)=0;%对应CPIRSE中CHs向sink节点发送控制信息告知自己是CHs的开销
end
 
 %当网络中出现第一个死亡节点时，该标志位被置1，记下第一个节点死亡的轮数
%  CPIRSE_flag_first_dead=0;
%  CPIRSE_first_dead=0;     %运行CPIRSE协议第一个节点死亡的轮数 
%  
%  EBUCRP_flag_first_dead=0;
%  EBUCRP_first_dead=0;     %运行EBUCRP协议第一个节点死亡的轮数 

 
 MCogLEACH_flag_first_dead=0;
 MCogLEACH_first_dead=0; %运行MCogLEACH协议第一个节点死亡的轮数
 
 MCogLEACH_flag_first_deadnirs=0;
 MCogLEACH_first_deadnirs=0;
 
 MCogLEACH_flag_first_deadab=0;
 MCogLEACH_first_deadab=0;

 MCogLEACH_flag_first_deadp=0;
 MCogLEACH_first_deadp=0;

 MCogLEACH_flag_first_deads=0;
 MCogLEACH_first_deads=0;

 MCogLEACH_flag_first_deadu=0;
 MCogLEACH_first_deadu=0;

 MCogLEACH_flag_first_deadd=0;
 MCogLEACH_first_deadd=0;

 MCogLEACH_flag_first_deadr=0;
 MCogLEACH_first_deadr=0;

 MCogLEACH_flag_first_deadg=0;
 MCogLEACH_first_deadg=0;
%  CogLEACH_flag_first_dead=0;
%  CogLEACH_first_dead=0; 
%  MCogLEACHC_flag_first_dead=0;
%  MCogLEACHC_first_dead=0; %运行MCogLEACH_C协议第一个节点死亡的轮数
%  
%  MLEAUCH_flag_first_dead=0;
%  MLEAUCH_first_dead=0;
%  
%  MFuzzy_flag_first_dead=0;
%  MFuzzy_first_dead=0; %运行MFuzzy-C-means协议第一个节点死亡的轮数
 
%  DSAC_flag_first_dead=0;
%  DSAC_first_dead=0; %运行DSAC协议最优调度下第一个节点死亡的轮数
%   
%  WCM_flag_first_dead=0;
%  WCM_first_dead=0; %运行WCM-based SAC协议最优调度下第一个节点死亡的轮数
%  
%  NSAC_flag_first_dead=0;
%  NSAC_first_dead=0; %运行WCM-based SAC协议最优调度下第一个节点死亡的轮数
%   
%  ION_flag_first_dead=0;
%  ION_first_dead=0;
  
 %补充：最后一个节点死亡标志位和轮数last_dead，它与first_dead之间的差越小说明能耗越均衡-2018-11-13
%  CPIRSE_flag_last_dead=0; 
%  CPIRSE_last_dead=0;

%  EBUCRP_flag_last_dead=0; 
%  EBUCRP_last_dead=0;
 
 MCogLEACH_flag_last_dead=0; 
 MCogLEACH_last_dead=0;

 MCogLEACH_flag_last_deadnirs=0; 
 MCogLEACH_last_deadnirs=0;

 MCogLEACH_flag_last_deadab=0; 
 MCogLEACH_last_deadab=0;

 MCogLEACH_flag_last_deadp=0; 
 MCogLEACH_last_deadp=0;

 MCogLEACH_flag_last_deads=0; 
 MCogLEACH_last_deads=0;

 MCogLEACH_flag_last_deadu=0; 
 MCogLEACH_last_deadu=0;

 MCogLEACH_flag_last_deadd=0; 
 MCogLEACH_last_deadd=0;

 MCogLEACH_flag_last_deadr=0; 
 MCogLEACH_last_deadr=0;

 MCogLEACH_flag_last_deadg=0; 
 MCogLEACH_last_deadg=0;
 
%  CogLEACH_flag_last_dead=0; 
%  CogLEACH_last_dead=0;
%  MCogLEACHC_flag_last_dead=0;
%  MCogLEACHC_last_dead=0;
%  
%  MLEAUCH_flag_last_dead=0;
%  MLEAUCH_last_dead=0;
% 
%  MFuzzy_flag_last_dead=0;
%  MFuzzy_last_dead=0;
 
%  DSAC_flag_last_dead=0;
%  DSAC_last_dead=0;
%  
%  WCM_flag_last_dead=0;
%  WCM_last_dead=0;
%  
%  NSAC_flag_last_dead=0;
%  NSAC_last_dead=0;
%  
%  ION_flag_last_dead=0;
%  ION_last_dead=0;
 
 
 for r=1:1:rmax
     r
 %开始调用各分簇算法获取分簇结果并画图  

     %返回参数的顺序：各分簇算法对应的CRSNs节点集合、每轮选取的CH数、每轮活着的节点数、CH选取开销、簇构建的开销、第一个节点死亡的标志位、第一个节点死亡的轮数、最后一个节点死亡的标志位、最后一个节点死亡的轮数、每轮有效收集数据的节点数目、每轮有效收集数据的节点比例、每轮过后节点的剩余能量、每轮各CH的能耗、每轮各簇的能耗
     %输入参数的顺序：原始CRSNs节点集合、各分簇算法对应的CRSNs节点集合、可用信道数c、网络中CRSNs节点总数n、当前轮数r、信道是否被占用矩阵occupu、信道是否被索回矩阵willoccupu、节点的传输范围、数据包大小L和控制包大小L1、第一个节点死亡标志位、第一个节点死亡的轮数、最后一个节点死亡的标志位、最后一个节点死亡的轮数；
     %对于事件驱动分簇算法，需要输入的参数还有：事件位置event、事件半径erange
     %调用函数时需要将S也作为输入的原因是：sink节点特殊，凡子程序中涉及sink节点的，还是用S(n+1).xd或者S(n+1).yd表示
     %已调：调用CPIRSE程序
%      [S2,CPIRSE_Clusterhead1,CPIRSE_Numberoflive1,CPIRSE_overheadofCH1,CPIRSE_overheadofcluster1,CPIRSE_overheadofchannelswitch1,CPIRSE_overheadofCHtosink1,CPIRSE_flag_first_dead,CPIRSE_first_dead,CPIRSE_flag_last_dead,CPIRSE_last_dead,CPIRSE_NumberofAcquisiton1,CPIRSE_RatioofAcquisiton1,CPIRSE_TotalEnergyConsumption1]=CPIRSE(S,S2,c,n,r,occupy,willoccupy,nodetransmissionrange,L,L1,CPIRSE_flag_first_dead,CPIRSE_first_dead,CPIRSE_flag_last_dead,CPIRSE_last_dead,EH_in,fsamp);
%      CPIRSE_Clusterhead(r)=CPIRSE_Clusterhead1;
%      CPIRSE_Numberoflive(r)=CPIRSE_Numberoflive1;
%      CPIRSE_overheadofCH(r)=CPIRSE_overheadofCH1;
%      CPIRSE_overheadofcluster(r)=CPIRSE_overheadofcluster1;
%      CPIRSE_NumberofAcquisiton(r)=CPIRSE_NumberofAcquisiton1; %每轮有效信息收集节点数目
%      CPIRSE_RatioofAcquisiton(r)=CPIRSE_RatioofAcquisiton1;%每轮有效信息收集节点的比例
% %      CPIRSE_Timedelay(r)=CPIRSE_Timedelay1;
%      CPIRSE_overheadofCHtosink(r)=CPIRSE_overheadofCHtosink1;
%      CPIRSE_TotalEnergyConsumption(r)=CPIRSE_TotalEnergyConsumption1;
%      
%      
%      %已调：调用EBUCRP程序
%      [S1,EBUCRP_Clusterhead1,EBUCRP_Numberoflive1,EBUCRP_overheadofCH1,EBUCRP_overheadofcluster1,EBUCRP_Routingoverhead1,EBUCRP_overheadofchannelswitch1,EBUCRP_flag_first_dead,EBUCRP_first_dead,EBUCRP_flag_last_dead,EBUCRP_last_dead,EBUCRP_NumberofAcquisiton1,EBUCRP_RatioofAcquisiton1,EBUCRP_TotalEnergyConsumption1]=EBUCRP(S,S1,c,n,r,occupy,willoccupy,nodetransmissionrange,L,L1,EBUCRP_flag_first_dead,EBUCRP_first_dead,EBUCRP_flag_last_dead,EBUCRP_last_dead,EH_in);
%      EBUCRP_Clusterhead(r)=EBUCRP_Clusterhead1;
%      EBUCRP_Numberoflive(r)=EBUCRP_Numberoflive1;
%      EBUCRP_overheadofCH(r)=EBUCRP_overheadofCH1;
%      EBUCRP_overheadofcluster(r)=EBUCRP_overheadofcluster1;
%      EBUCRP_NumberofAcquisiton(r)=EBUCRP_NumberofAcquisiton1; %每轮有效信息收集节点数目
%      EBUCRP_RatioofAcquisiton(r)=EBUCRP_RatioofAcquisiton1;%每轮有效信息收集节点的比例
%      EBUCRP_routingoverhead(r)=EBUCRP_Routingoverhead1;
% %      EBUCRP_Timedelay(r)=EBUCRP_Timedelay1;
%      EBUCRP_TotalEnergyConsumption(r)=EBUCRP_TotalEnergyConsumption1;
% %  
% sum(MCogLEACH_Residualenergy);
% sum(MCogLEACH_Residualenergynirs);
% sum(MCogLEACH_Residualenergyab);
% sum(MCogLEACH_Residualenergyp);
% sum(MCogLEACH_Residualenergys);
% sum(MCogLEACH_Residualenergyu);
% sum(MCogLEACH_Residualenergyd);
% sum(MCogLEACH_Residualenergyr);
% sum(MCogLEACH_Residualenergyg);
     %已调：调用MCogLEACH程序
%      [S4,MCogLEACH_Numberoflive1,MCogLEACH_flag_first_dead,MCogLEACH_first_dead,MCogLEACH_flag_last_dead,MCogLEACH_last_dead,MCogLEACH_EnergyEfficiency1]=IRSCogLEACH(S,S4,c,n,r,occupy,willoccupy,nodetransmissionrange,L,L1,MCogLEACH_flag_first_dead,MCogLEACH_first_dead,MCogLEACH_flag_last_dead,MCogLEACH_last_dead,EH_in);
%      [S4,MCogLEACH_Clusterhead1,MCogLEACH_Numberoflive1,MCogLEACH_EnergyEfficiency1,MCogLEACH_Numberoflivenirs1,MCogLEACH_EnergyEfficiencyNIRS1,MCogLEACH_Numberofliveab1,MCogLEACH_EnergyEfficiencyEb1,MCogLEACH_Numberoflivep1,MCogLEACH_EnergyEfficiencyP1,MCogLEACH_Numberoflives1,MCogLEACH_EnergyEfficiencyS1,MCogLEACH_Numberofliveu1,MCogLEACH_EnergyEfficiencyU1,MCogLEACH_Numberoflived1,MCogLEACH_EnergyEfficiencyD1,MCogLEACH_Numberofliver1,MCogLEACH_EnergyEfficiencyR1,MCogLEACH_Numberofliveg1,MCogLEACH_EnergyEfficiencyG1]=IRSCogLEACH(S,S4,c,n,r,occupy,willoccupy,nodetransmissionrange,L,L1,MCogLEACH_flag_first_dead,MCogLEACH_flag_last_dead,MCogLEACH_flag_first_deadnirs,MCogLEACH_flag_last_deadnirs,MCogLEACH_flag_first_deadab,MCogLEACH_flag_last_deadab,MCogLEACH_flag_first_deadp,MCogLEACH_flag_last_deadp,MCogLEACH_flag_first_deads,MCogLEACH_flag_last_deads,MCogLEACH_flag_first_deadu,MCogLEACH_flag_last_deadu,MCogLEACH_flag_first_deadd,MCogLEACH_flag_last_deadd,MCogLEACH_flag_first_deadr,MCogLEACH_flag_last_deadr,MCogLEACH_flag_first_deadg,MCogLEACH_flag_last_deadg,EH_in,EH_innirs,EH_inab,EH_inp,EH_ins,EH_inu,EH_ind,EH_inr,EH_ing,MCogLEACH_Residualenergy1,MCogLEACH_Residualenergynirs1,MCogLEACH_Residualenergyab1,MCogLEACH_Residualenergyp1,MCogLEACH_Residualenergys1,MCogLEACH_Residualenergyu1,MCogLEACH_Residualenergyd1,MCogLEACH_Residualenergyr1,MCogLEACH_Residualenergyg1);
     [S4,MCogLEACH_TotalEnergyConsumption1,MCogLEACH_Clusterhead1,MCogLEACH_Numberoflive1,MCogLEACH_EnergyEfficiency1,MCogLEACH_Numberoflivenirs1,MCogLEACH_EnergyEfficiencyNIRS1,MCogLEACH_Numberofliveab1,MCogLEACH_EnergyEfficiencyEb1,MCogLEACH_Numberoflivep1,MCogLEACH_EnergyEfficiencyP1,MCogLEACH_Numberoflives1,MCogLEACH_EnergyEfficiencyS1,MCogLEACH_Numberofliveu1,MCogLEACH_EnergyEfficiencyU1,MCogLEACH_Numberoflived1,MCogLEACH_EnergyEfficiencyD1,MCogLEACH_Numberofliver1,MCogLEACH_EnergyEfficiencyR1,MCogLEACH_Numberofliveg1,MCogLEACH_EnergyEfficiencyG1]=IRSCogLEACH(S,S4,c,n,r,occupy,willoccupy,nodetransmissionrange,L,L1,MCogLEACH_flag_first_dead,MCogLEACH_flag_last_dead,MCogLEACH_flag_first_deadnirs,MCogLEACH_flag_last_deadnirs,MCogLEACH_flag_first_deadab,MCogLEACH_flag_last_deadab,MCogLEACH_flag_first_deadp,MCogLEACH_flag_last_deadp,MCogLEACH_flag_first_deads,MCogLEACH_flag_last_deads,MCogLEACH_flag_first_deadu,MCogLEACH_flag_last_deadu,MCogLEACH_flag_first_deadd,MCogLEACH_flag_last_deadd,MCogLEACH_flag_first_deadr,MCogLEACH_flag_last_deadr,MCogLEACH_flag_first_deadg,MCogLEACH_flag_last_deadg,EH_in,EH_innirs,EH_inab,EH_inp,EH_ins,EH_inu,EH_ind,EH_inr,EH_ing);
     for i=1:1:n
         MCogLEACH_Residualenergy(i,r)=S4(i).ehou;
         MCogLEACH_Residualenergynirs(i,r)=S4(i).enirshou;
         MCogLEACH_Residualenergyab(i,r)=S4(i).eabhou;
         MCogLEACH_Residualenergyp(i,r)=S4(i).ephou;
         MCogLEACH_Residualenergys(i,r)=S4(i).eshou;
         MCogLEACH_Residualenergyu(i,r)=S4(i).euhou;
         MCogLEACH_Residualenergyd(i,r)=S4(i).edhou;
         MCogLEACH_Residualenergyr(i,r)=S4(i).erhou;
         MCogLEACH_Residualenergyg(i,r)=S4(i).eghou;
     end

     for i=1:1:n
         MCogLEACH_cutoufenbu(i,r)=S4(i).typehou;
     end

     for i=1:1:n
         MCogLEACH_cutouhao(i,r)=S4(i).chhou;
     end
     
     MCogLEACH_Clusterhead(r)=MCogLEACH_Clusterhead1;
     %%***************************************存活节点数******************************************************
     MCogLEACH_Numberoflive(r)=MCogLEACH_Numberoflive1;          %联合
     MCogLEACH_Numberoflivenirs(r)=MCogLEACH_Numberoflivenirs1;  %无IRS
     MCogLEACH_Numberofliveab(r)=MCogLEACH_Numberofliveab1;      %净能量收益
     MCogLEACH_Numberoflivep(r)=MCogLEACH_Numberoflivep1;        %被动
     MCogLEACH_Numberoflives(r)=MCogLEACH_Numberoflives1;        %单天线
     MCogLEACH_Numberofliveu(r)=MCogLEACH_Numberofliveu1;        %仅上行
     MCogLEACH_Numberoflived(r)=MCogLEACH_Numberoflived1;        %仅下行
     MCogLEACH_Numberofliver(r)=MCogLEACH_Numberofliver1;        %随机反射因子
     MCogLEACH_Numberofliveg(r)=MCogLEACH_Numberofliveg1;        %共用反射因子
%      MCogLEACH_overheadofCH(r)=MCogLEACH_overheadofCH1;
%      MCogLEACH_overheadofcluster(r)=MCogLEACH_overheadofcluster1;
%      MCogLEACH_NumberofAcquisiton(r)=MCogLEACH_NumberofAcquisiton1; %每轮有效信息收集节点数目
%      MCogLEACH_RatioofAcquisiton(r)=MCogLEACH_RatioofAcquisiton1;%每轮有效信息收集节点的比例
%      MCogLEACH_Timedelay(r)=MCogLEACH_Timedelay1;
     MCogLEACH_TotalEnergyConsumption(r)=MCogLEACH_TotalEnergyConsumption1;
     %%**********************************************剩余能量*************************************************
%      MCogLEACH_Residualenergy(:,r)=MCogLEACH_Residualenergy1;
%      MCogLEACH_Residualenergynirs(:,r)=MCogLEACH_Residualenergynirs1;
%      MCogLEACH_Residualenergyab(:,r)=MCogLEACH_Residualenergyab1;
%      MCogLEACH_Residualenergyp(:,r)=MCogLEACH_Residualenergyp1;
%      MCogLEACH_Residualenergys(:,r)=MCogLEACH_Residualenergys1;
%      MCogLEACH_Residualenergyu(:,r)=MCogLEACH_Residualenergyu1;
%      MCogLEACH_Residualenergyd(:,r)=MCogLEACH_Residualenergyd1;
%      MCogLEACH_Residualenergyr(:,r)=MCogLEACH_Residualenergyr1;
%      MCogLEACH_Residualenergyg(:,r)=MCogLEACH_Residualenergyg1;
     %%*******************************************能效********************************************************
     MCogLEACH_EnergyEfficiency(r)=MCogLEACH_EnergyEfficiency1;          %联合
     MCogLEACH_EnergyEfficiencyNIRS(r)=MCogLEACH_EnergyEfficiencyNIRS1;  %无IRS
     MCogLEACH_EnergyEfficiencyEb(r)=MCogLEACH_EnergyEfficiencyEb1;      %净能量收益
     MCogLEACH_EnergyEfficiencyP(r)=MCogLEACH_EnergyEfficiencyP1;        %被动
     MCogLEACH_EnergyEfficiencyS(r)=MCogLEACH_EnergyEfficiencyS1;        %单天线
     MCogLEACH_EnergyEfficiencyU(r)=MCogLEACH_EnergyEfficiencyU1;        %仅上行
     MCogLEACH_EnergyEfficiencyD(r)=MCogLEACH_EnergyEfficiencyD1;        %仅下行
     MCogLEACH_EnergyEfficiencyR(r)=MCogLEACH_EnergyEfficiencyR1;        %随机反射因子
     MCogLEACH_EnergyEfficiencyG(r)=MCogLEACH_EnergyEfficiencyG1;        %共用反射因子

     if (MCogLEACH_Numberoflive1<100 || MCogLEACH_Numberoflivenirs1<100 || MCogLEACH_Numberofliveab1<100 || MCogLEACH_Numberoflivep1<100 || MCogLEACH_Numberoflives1<100 || MCogLEACH_Numberofliveu1<100  || MCogLEACH_Numberoflived1<100 || MCogLEACH_Numberofliver1<100 || MCogLEACH_Numberofliveg1<100)
         break
     end
     %      [S44,CogLEACH_Clusterhead1,CogLEACH_Numberoflive1,CogLEACH_overheadofCH1,CogLEACH_overheadofcluster1,CogLEACH_flag_first_dead,CogLEACH_first_dead,CogLEACH_flag_last_dead,CogLEACH_last_dead,CogLEACH_NumberofAcquisiton1,CogLEACH_RatioofAcquisiton1,CogLEACH_Timedelay1,CogLEACH_TotalEnergyConsumption1]=CogLEACH(S,S4,c,n,r,occupy,willoccupy,nodetransmissionrange,L,L1,CogLEACH_flag_first_dead,CogLEACH_first_dead,CogLEACH_flag_last_dead,CogLEACH_last_dead,EH_in);
%      CogLEACH_Clusterhead(r)=CogLEACH_Clusterhead1;
%      CogLEACH_Numberoflive(r)=CogLEACH_Numberoflive1;
%      CogLEACH_overheadofCH(r)=CogLEACH_overheadofCH1;
%      CogLEACH_overheadofcluster(r)=CogLEACH_overheadofcluster1;
%      CogLEACH_NumberofAcquisiton(r)=CogLEACH_NumberofAcquisiton1; %每轮有效信息收集节点数目
%      CogLEACH_RatioofAcquisiton(r)=CogLEACH_RatioofAcquisiton1;%每轮有效信息收集节点的比例
% %      CogLEACH_Timedelay(r)=CogLEACH_Timedelay1;
%      CogLEACH_TotalEnergyConsumption(r)=CogLEACH_TotalEnergyConsumption1;
%      %已调：调用MCogLEACH_C程序
% %      [S6,MCogLEACHC_Clusterhead1,MCogLEACHC_Numberoflive1,MCogLEACHC_overheadofCH1,MCogLEACHC_overheadofcluster1,MCogLEACHC_flag_first_dead,MCogLEACHC_first_dead,MCogLEACHC_flag_last_dead,MCogLEACHC_last_dead,MCogLEACHC_NumberofAcquisiton1,MCogLEACHC_RatioofAcquisiton1,MCogLEACHC_Energy1,MCogLEACHC_CHE1,MCogLEACHC_ClusterE1,MCogLEACHC_Timedelay1,MCogLEACHC_TotalEnergyConsumption1]=MCogLEACHC(S,S6,c,n,r,occupy,willoccupy,nodetransmissionrange,L,L1,MCogLEACHC_flag_first_dead,MCogLEACHC_first_dead,MCogLEACHC_flag_last_dead,MCogLEACHC_last_dead);
% %      MCogLEACHC_Clusterhead(r)=MCogLEACHC_Clusterhead1;
% %      MCogLEACHC_Numberoflive(r)=MCogLEACHC_Numberoflive1;
% %      MCogLEACHC_overheadofCH(r)=MCogLEACHC_overheadofCH1;
% %      MCogLEACHC_overheadofcluster(r)=MCogLEACHC_overheadofcluster1;
% %      MCogLEACHC_NumberofAcquisiton(r)=MCogLEACHC_NumberofAcquisiton1;  %每轮有效信息收集节点数目
% %      MCogLEACHC_RatioofAcquisiton(r)=MCogLEACHC_RatioofAcquisiton1;%每轮有效信息收集节点的比例
% %      MCogLEACHC_Timedelay(r)=MCogLEACHC_Timedelay1;
% %      MCogLEACHC_TotalEnergyConsumption(r)=MCogLEACHC_TotalEnergyConsumption1;
% %      
% %      %已调：调用MLEAUCH程序
% %      [S8,MLEAUCH_Clusterhead1,MLEAUCH_Numberoflive1,MLEAUCH_overheadofCH1,MLEAUCH_overheadofcluster1,MLEAUCH_flag_first_dead,MLEAUCH_first_dead,MLEAUCH_flag_last_dead,MLEAUCH_last_dead,MLEAUCH_NumberofAcquisiton1,MLEAUCH_RatioofAcquisiton1,MLEAUCH_Timedelay1,MLEAUCH_TotalEnergyConsumption1]=MLEAUCH(S,S8,c,n,r,nodetransmissionrange,occupy,willoccupy,L,L1,MLEAUCH_flag_first_dead,MLEAUCH_first_dead,MLEAUCH_flag_last_dead,MLEAUCH_last_dead);
% %      MLEAUCH_Clusterhead(r)=MLEAUCH_Clusterhead1;
% %      MLEAUCH_Numberoflive(r)=MLEAUCH_Numberoflive1;
% %      MLEAUCH_overheadofCH(r)=MLEAUCH_overheadofCH1;
% %      MLEAUCH_overheadofcluster(r)=MLEAUCH_overheadofcluster1;
% %      MLEAUCH_NumberofAcquisiton(r)=MLEAUCH_NumberofAcquisiton1; %每轮有效信息收集节点数目
% %      MLEAUCH_RatioofAcquisiton(r)=MLEAUCH_RatioofAcquisiton1; %每轮有效信息收集节点数目
% %      MLEAUCH_Timedelay(r)=MLEAUCH_Timedelay1;
% %      MLEAUCH_TotalEnergyConsumption(r)=MLEAUCH_TotalEnergyConsumption1;
% %      
% %      %已调：调用MFuzzy-C-means程序 2019-2-11
% %      [S10,MFuzzy_Clusterhead1,MFuzzy_Numberoflive1,MFuzzy_overheadofCH1,MFuzzy_overheadofcluster1,MFuzzy_flag_first_dead,MFuzzy_first_dead,MFuzzy_flag_last_dead,MFuzzy_last_dead,MFuzzy_NumberofAcquisiton1,MFuzzy_RatioofAcquisiton1,MFuzzy_Energy1, MFuzzy_CHE1,MFuzzy_ClusterE1,MFuzzy_Timedelay1,MFuzzy_TotalEnergyConsumption1]=MFuzzy(S,S10,c,n,r,occupy,willoccupy,nodetransmissionrange,L,L1,MFuzzy_flag_first_dead,MFuzzy_first_dead,MFuzzy_flag_last_dead,MFuzzy_last_dead);
% %      MFuzzy_Clusterhead(r)=MFuzzy_Clusterhead1;
% %      MFuzzy_Numberoflive(r)=MFuzzy_Numberoflive1;
% %      MFuzzy_overheadofCH(r)=MFuzzy_overheadofCH1;
% %      MFuzzy_overheadofcluster(r)=MFuzzy_overheadofcluster1;
% %      MFuzzy_NumberofAcquisiton(r)=MFuzzy_NumberofAcquisiton1; %每轮有效信息收集节点数目
% %      MFuzzy_RatioofAcquisiton(r)=MFuzzy_RatioofAcquisiton1; %每轮有效信息收集节点数目
% %      MFuzzy_Timedelay(r)=MFuzzy_Timedelay1;
% %      MFuzzy_TotalEnergyConsumption(r)=MFuzzy_TotalEnergyConsumption1;
%      
%      %已调：调用DSAC程序 最优调度2019-2-13
%      [S15,DSAC_Clusterhead1,DSAC_Numberoflive1,DSAC_overheadofCH1,DSAC_overheadofcluster1,DSAC_NumberofAcquisiton1,DSAC_RatioofAcquisiton1,DSAC_Routingoverhead1,DSAC_flag_first_dead,DSAC_first_dead,DSAC_flag_last_dead,DSAC_last_dead,ClusterHeadF,ClusterF,ClusterchannelF,DSAC_Timedelay1,DSAC_TotalEnergyConsumption1]=DSAC(S,S15,c,n,r,occupy,willoccupy,nodetransmissionrange,L,L1,DSAC_flag_first_dead,DSAC_first_dead,DSAC_flag_last_dead,DSAC_last_dead,ClusterHeadF,ClusterF,ClusterchannelF,EH_in);
%      DSAC_Clusterhead(r)=DSAC_Clusterhead1;
%      DSAC_Numberoflive(r)=DSAC_Numberoflive1;
%      DSAC_overheadofCH(r)=DSAC_overheadofCH1;
%      DSAC_overheadofcluster(r)=DSAC_overheadofcluster1;
%      DSAC_NumberofAcquisiton(r)=DSAC_NumberofAcquisiton1;  %每轮有效信息收集节点数目
%      DSAC_RatioofAcquisiton(r)=DSAC_RatioofAcquisiton1; %每轮有效信息收集节点数目
%      DSAC_routingoverhead(r)=DSAC_Routingoverhead1;
% %      DSAC_Timedelay(r)=DSAC_Timedelay1;
%      DSAC_TotalEnergyConsumption(r)=DSAC_TotalEnergyConsumption1;
% %      
% %      %调用WCM-based SAC程序
%      [S19,WCM_Clusterhead1,WCM_Numberoflive1,WCM_overheadofCH1,WCM_overheadofcluster1,WCM_NumberofAcquisiton1,WCM_RatioofAcquisiton1,CONFIDENCE,WCM_flag_first_dead,WCM_first_dead,WCM_flag_last_dead,WCM_last_dead,WCM_TotalEnergyConsumption1]=WCM(S,S19,c,n,r,occupy,willoccupy,nodetransmissionrange,L,L1,CONFIDENCE,WCM_flag_first_dead,WCM_first_dead,WCM_flag_last_dead,WCM_last_dead,EH_in);
%      WCM_Clusterhead(r)=WCM_Clusterhead1;
%      WCM_Numberoflive(r)=WCM_Numberoflive1;
%      WCM_overheadofCH(r)=WCM_overheadofCH1;
%      WCM_overheadofcluster(r)=WCM_overheadofcluster1;
%      WCM_NumberofAcquisiton(r)=WCM_NumberofAcquisiton1;%每轮有效信息收集节点数目
%      WCM_RatioofAcquisiton(r)=WCM_RatioofAcquisiton1; %每轮有效信息收集节点数目
% %      WCM_Timedelay(r)=WCM_Timedelay1;
%      WCM_TotalEnergyConsumption(r)=WCM_TotalEnergyConsumption1;
% %      
% %      调用NSAC程序
%      [S21,NSAC_Clusterhead1,NSAC_Numberoflive1,NSAC_overheadofCH1,NSAC_overheadofcluster1,NSAC_NumberofAcquisiton1,NSAC_RatioofAcquisiton1,NSAC_flag_first_dead,NSAC_first_dead,NSAC_flag_last_dead,NSAC_last_dead,NSAC_TotalEnergyConsumption1]=NSAC(S,S21,c,n,r,occupy,willoccupy,nodetransmissionrange,L,L1,NSAC_flag_first_dead,NSAC_first_dead,NSAC_flag_last_dead,NSAC_last_dead,EH_in);
%      NSAC_Clusterhead(r)=NSAC_Clusterhead1;
%      NSAC_Numberoflive(r)=NSAC_Numberoflive1;
%      NSAC_overheadofCH(r)=NSAC_overheadofCH1;
%      NSAC_overheadofcluster(r)=NSAC_overheadofcluster1;
%      NSAC_NumberofAcquisiton(r)=NSAC_NumberofAcquisiton1;%每轮有效信息收集节点数目
%      NSAC_RatioofAcquisiton(r)=NSAC_RatioofAcquisiton1; %每轮有效信息收集节点数目
% %      NSAC_Timedelay(r)=NSAC_Timedelay1;
%      NSAC_TotalEnergyConsumption(r)=NSAC_TotalEnergyConsumption1;
% %      
% %      %调用IMOCRP程序
%      [S13,ION_Clusterhead1,ION_Numberoflive1,ION_overheadofCH1,ION_overheadofcluster1,ION_NumberofAcquisiton1,ION_RatioofAcquisiton1,ION_flag_first_dead,ION_first_dead,ION_flag_last_dead,ION_last_dead,ION_TotalEnergyConsumption1]=ION(S,S13,c,n,r,occupy,willoccupy,nodetransmissionrange,L,L1,ION_flag_first_dead,ION_first_dead,ION_flag_last_dead,ION_last_dead,EH_in);
%      ION_Clusterhead(r)=ION_Clusterhead1;
%      ION_Numberoflive(r)=ION_Numberoflive1;
%      ION_overheadofCH(r)=ION_overheadofCH1;
%      ION_overheadofcluster(r)=ION_overheadofcluster1;
%      ION_NumberofAcquisiton(r)=ION_NumberofAcquisiton1;
%      ION_RatioofAcquisiton(r)=ION_RatioofAcquisiton1;
% %      ION_Timedelay(r)=ION_Timedelay1;
%      ION_TotalEnergyConsumption(r)=ION_TotalEnergyConsumption1;
 end
 
e1=sum(MCogLEACH_Residualenergy,1);
e2=sum(MCogLEACH_Residualenergynirs,1);
e3=sum(MCogLEACH_Residualenergyab,1);
e4=sum(MCogLEACH_Residualenergyp,1);
e5=sum(MCogLEACH_Residualenergys,1);
e6=sum(MCogLEACH_Residualenergyu,1);
e7=sum(MCogLEACH_Residualenergyd,1);
e8=sum(MCogLEACH_Residualenergyr,1);
e9=sum(MCogLEACH_Residualenergyg,1);
 %将仿真数据写入CompareSimulationresult900表格中，方便比较和做图-2019-3-2
 %1、簇头数
%  SUCCESS_EBUCRP1=xlswrite('CompareSimulationresult900.xlsx',EBUCRP_Clusterhead,'Sheet1','D2:NTS2');%将EBUCRP每轮选取的簇头数写入表格
 SUCCESS_MCogLEACH1=xlswrite('CompareSimulationresult1001.xlsx',MCogLEACH_Clusterhead,'Sheet1','D2:NTS2');%将MCogLEACH每轮选取的簇头数写入表格
%  SUCCESS_CogLEACH1=xlswrite('CompareSimulationresult900.xlsx',CogLEACH_Clusterhead,'Sheet1','D3:NTS3');%将MCogLEACH每轮选取的簇头数写入表格
 %  SUCCESS_MCogLEACHC1=xlswrite('E:\matlab\myprogram\myprocotol\OneLayerDelayCompare\CompareSimulationresult100.xlsx',MCogLEACHC_Clusterhead,'Sheet1','D4:NTS4');%将MCogLEACH-C每轮选取的簇头数写入表格
%  SUCCESS_MLEAUCH1=xlswrite('E:\matlab\myprogram\myprocotol\OneLayerDelayCompare\CompareSimulationresult100.xlsx',MLEAUCH_Clusterhead,'Sheet1','D5:NTS5');%将MLEAUCH每轮选取的簇头数写入表格
%  SUCCESS_MFuzzy1=xlswrite('E:\matlab\myprogram\myprocotol\OneLayerDelayCompare\CompareSimulationresult100.xlsx',MFuzzy_Clusterhead,'Sheet1','D6:NTS6');%将MFuzzy C-means每轮选取的簇头数写入表格
%  SUCCESS_DSAC1=xlswrite('CompareSimulationresult900.xlsx',DSAC_Clusterhead,'Sheet1','D4:NTS4');%将DSAC最优调度下每轮选取的簇头数写入表格
%  SUCCESS_WCM1=xlswrite('CompareSimulationresult900.xlsx',WCM_Clusterhead,'Sheet1','D5:NTS5');%将WCM最优调度下每轮选取的簇头数写入表格
%  SUCCESS_NSAC1=xlswrite('CompareSimulationresult900.xlsx',NSAC_Clusterhead,'Sheet1','D6:NTS6');%将NSAC最优调度下每轮选取的簇头数写入表格
%  SUCCESS_ION1=xlswrite('CompareSimulationresult900.xlsx',ION_Clusterhead,'Sheet1','D7:NTS7');%将NSAC最优调度下每轮选取的簇头数写入表格
%  SUCCESS_CPIRSE1=xlswrite('CompareSimulationresult900.xlsx',CPIRSE_Clusterhead,'Sheet1','D8:NTS8');%将CPIRSE每轮选取的簇头数写入表格
 
 %2、活着的节点数
%  SUCCESS_EBUCRP2=xlswrite('CompareSimulationresult900.xlsx',EBUCRP_Numberoflive,'Sheet1','D10:NTS10');%将EBUCRP每轮活着的节点数写入表格
 SUCCESS_MCogLEACH2=xlswrite('CompareSimulationresult1001.xlsx',MCogLEACH_Numberoflive,'Sheet1','D3:NTS3');%将MCogLEACH每轮活着的节点数写入表格
 SUCCESS_MCogLEACH2nirs=xlswrite('CompareSimulationresult1001.xlsx',MCogLEACH_Numberoflivenirs,'Sheet1','D4:NTS4');%将MCogLEACH每轮活着的节点数写入表格
 SUCCESS_MCogLEACH2ab=xlswrite('CompareSimulationresult1001.xlsx',MCogLEACH_Numberofliveab,'Sheet1','D5:NTS5');
 SUCCESS_MCogLEACH2p=xlswrite('CompareSimulationresult1001.xlsx',MCogLEACH_Numberoflivep,'Sheet1','D6:NTS6');%将MCogLEACH每轮活着的节点数写入表格
 SUCCESS_MCogLEACH2s=xlswrite('CompareSimulationresult1001.xlsx',MCogLEACH_Numberoflives,'Sheet1','D7:NTS7');%将MCogLEACH每轮活着的节点数写入表格
 SUCCESS_MCogLEACH2u=xlswrite('CompareSimulationresult1001.xlsx',MCogLEACH_Numberofliveu,'Sheet1','D8:NTS8');%将MCogLEACH每轮活着的节点数写入表格
 SUCCESS_MCogLEACH2d=xlswrite('CompareSimulationresult1001.xlsx',MCogLEACH_Numberoflived,'Sheet1','D9:NTS9');%将MCogLEACH每轮活着的节点数写入表格
 SUCCESS_MCogLEACH2r=xlswrite('CompareSimulationresult1001.xlsx',MCogLEACH_Numberofliver,'Sheet1','D10:NTS10');%将MCogLEACH每轮活着的节点数写入表格
 SUCCESS_MCogLEACH2g=xlswrite('CompareSimulationresult1001.xlsx',MCogLEACH_Numberofliveg,'Sheet1','D11:NTS11');%将MCogLEACH每轮活着的节点数写入表格

 %  SUCCESS_CogLEACH2=xlswrite('CompareSimulationresult900.xlsx',CogLEACH_Numberoflive,'Sheet1','D11:NTS11');%将MCogLEACH每轮活着的节点数写入表格
 %  SUCCESS_MCogLEACHC2=xlswrite('E:\matlab\myprogram\myprocotol\OneLayerDelayCompare\CompareSimulationresult100.xlsx',MCogLEACHC_Numberoflive,'Sheet1','D14:NTS14');%将MCogLEACH-C每轮活着的节点数写入表格
%  SUCCESS_MLEAUCH2=xlswrite('E:\matlab\myprogram\myprocotol\OneLayerDelayCompare\CompareSimulationresult100.xlsx',MLEAUCH_Numberoflive,'Sheet1','D15:NTS15');%将MLEAUCH每轮活着的节点数写入表格
%  SUCCESS_MFuzzy2=xlswrite('E:\matlab\myprogram\myprocotol\OneLayerDelayCompare\CompareSimulationresult100.xlsx',MFuzzy_Numberoflive,'Sheet1','D16:NTS16');%将MFuzzy C-means每轮活着的节点数写入表格
%  SUCCESS_DSAC2=xlswrite('CompareSimulationresult900.xlsx',DSAC_Numberoflive,'Sheet1','D12:NTS12');%将DSAC最优调度下每轮活着的节点数写入表格
%  SUCCESS_WCM2=xlswrite('CompareSimulationresult900.xlsx',WCM_Numberoflive,'Sheet1','D13:NTS13');%将WCM最优调度下每轮活着的节点数写入表格
%  SUCCESS_NSAC2=xlswrite('CompareSimulationresult900.xlsx',NSAC_Numberoflive,'Sheet1','D14:NTS14');%将NSAC最优调度下每轮活着的节点数写入表格
%  SUCCESS_ION2=xlswrite('CompareSimulationresult900.xlsx',ION_Numberoflive,'Sheet1','D15:NTS15');%将NSAC最优调度下每轮选取的簇头数写入表格
%  SUCCESS_CPIRSE2=xlswrite('CompareSimulationresult900.xlsx',CPIRSE_Numberoflive,'Sheet1','D16:NTS16');%将CPIRSE每轮活着的节点数写入表格

 %3、CH选取的开销
%  SUCCESS_EBUCRP3=xlswrite('CompareSimulationresult900.xlsx',EBUCRP_overheadofCH,'Sheet1','D18:NTS18');%将EBUCRP每轮CH选取的开销写入表格
%  SUCCESS_MCogLEACH3=xlswrite('CompareSimulationresult900.xlsx',MCogLEACH_overheadofCH,'Sheet1','D19:NTS19');%将MCogLEACH每轮CH选取的开销写入表格
%  SUCCESS_CogLEACH3=xlswrite('CompareSimulationresult900.xlsx',CogLEACH_overheadofCH,'Sheet1','D19:NTS19');%将MCogLEACH每轮CH选取的开销写入表格
 %  SUCCESS_MCogLEACHC3=xlswrite('E:\matlab\myprogram\myprocotol\OneLayerDelayCompare\CompareSimulationresult100.xlsx',MCogLEACHC_overheadofCH,'Sheet1','D24:NTS24');%将MCogLEACH-C每轮CH选取的开销写入表格
%  SUCCESS_MLEAUCH3=xlswrite('E:\matlab\myprogram\myprocotol\OneLayerDelayCompare\CompareSimulationresult100.xlsx',MLEAUCH_overheadofCH,'Sheet1','D25:NTS25');%将MLEAUCH每轮CH选取的开销写入表格
%  SUCCESS_MFuzzy3=xlswrite('E:\matlab\myprogram\myprocotol\OneLayerDelayCompare\CompareSimulationresult100.xlsx',MFuzzy_overheadofCH,'Sheet1','D26:NTS26');%将MFuzzy C-means每轮CH选取的开销写入表格
%  SUCCESS_DSAC3=xlswrite('CompareSimulationresult900.xlsx',DSAC_overheadofCH,'Sheet1','D20:NTS20');%将DSAC最优调度下每轮CH选取的开销写入表格
%  SUCCESS_WCM3=xlswrite('CompareSimulationresult900.xlsx',WCM_overheadofCH,'Sheet1','D21:NTS21');%将WCM最优调度下每轮CH选取的开销写入表格
%  SUCCESS_NSAC3=xlswrite('CompareSimulationresult900.xlsx',NSAC_overheadofCH,'Sheet1','D22:NTS22');%将NSAC最优调度下每轮CH选取的开销写入表格
%  SUCCESS_ION3=xlswrite('CompareSimulationresult900.xlsx',ION_overheadofCH,'Sheet1','D23:NTS23');%将NSAC最优调度下每轮选取的簇头数写入表格
%  SUCCESS_CPIRSE3=xlswrite('CompareSimulationresult900.xlsx',CPIRSE_overheadofCH,'Sheet1','D24:NTS24');%将EBUCRP每轮CH选取的开销写入表格
 
 %4、簇构建的开销
%  SUCCESS_EBUCRP4=xlswrite('CompareSimulationresult900.xlsx',EBUCRP_overheadofcluster,'Sheet1','D26:NTS26');%将EBUCRP每轮簇构建的开销写入表格
%  SUCCESS_MCogLEACH4=xlswrite('CompareSimulationresult900.xlsx',MCogLEACH_overheadofcluster,'Sheet1','D27:NTS27');%将MCogLEACH每轮簇构建的开销写入表格
%  SUCCESS_CogLEACH4=xlswrite('CompareSimulationresult900.xlsx',CogLEACH_overheadofcluster,'Sheet1','D27:NTS27');%将MCogLEACH每轮簇构建的开销写入表格
 %  SUCCESS_MCogLEACHC4=xlswrite('E:\matlab\myprogram\myprocotol\OneLayerDelayCompare\CompareSimulationresult100.xlsx',MCogLEACHC_overheadofcluster,'Sheet1','D34:NTS34');%将MCogLEACH-C每轮簇构建的开销写入表格
%  SUCCESS_MLEAUCH4=xlswrite('E:\matlab\myprogram\myprocotol\OneLayerDelayCompare\CompareSimulationresult100.xlsx',MLEAUCH_overheadofcluster,'Sheet1','D35:NTS35');%将MLEAUCH每轮簇构建的开销写入表格
%  SUCCESS_MFuzzy4=xlswrite('E:\matlab\myprogram\myprocotol\OneLayerDelayCompare\CompareSimulationresult100.xlsx',MFuzzy_overheadofcluster,'Sheet1','D36:NTS36');%将MFuzzy C-means每轮簇构建的开销写入表格
%  SUCCESS_DSAC4=xlswrite('CompareSimulationresult900.xlsx',DSAC_overheadofcluster,'Sheet1','D28:NTS28');%将DSAC最优调度下每轮簇构建的开销写入表格
%  SUCCESS_WCM4=xlswrite('CompareSimulationresult900.xlsx',WCM_overheadofcluster,'Sheet1','D29:NTS29');%将WCM最优调度下每轮簇构建的开销写入表格
%  SUCCESS_NSAC4=xlswrite('CompareSimulationresult900.xlsx',NSAC_overheadofcluster,'Sheet1','D30:NTS30');%将NSAC最优调度下每轮簇构建的开销写入表格
%  SUCCESS_ION4=xlswrite('CompareSimulationresult900.xlsx',ION_overheadofcluster,'Sheet1','D31:NTS31');%将NSAC最优调度下每轮选取的簇头数写入表格
%  SUCCESS_CPIRSE4=xlswrite('CompareSimulationresult900.xlsx',CPIRSE_overheadofcluster,'Sheet1','D32:NTS32');%将EBUCRP每轮簇构建的开销写入表格
 
 %5、有效收集数据的节点数量
%  SUCCESS_EBUCRP5=xlswrite('CompareSimulationresult900.xlsx',EBUCRP_NumberofAcquisiton,'Sheet1','D34:NTS34');%将EBUCRP每轮有效收集数据的节点数量写入表格
%  SUCCESS_MCogLEACH5=xlswrite('CompareSimulationresult900.xlsx',MCogLEACH_NumberofAcquisiton,'Sheet1','D35:NTS35');%将MCogLEACH每轮有效收集数据的节点数量写入表格
%  SUCCESS_CogLEACH5=xlswrite('CompareSimulationresult900.xlsx',CogLEACH_NumberofAcquisiton,'Sheet1','D35:NTS35');%将MCogLEACH每轮有效收集数据的节点数量写入表格
 %  SUCCESS_MCogLEACHC5=xlswrite('E:\matlab\myprogram\myprocotol\OneLayerDelayCompare\CompareSimulationresult100.xlsx',MCogLEACHC_NumberofAcquisiton,'Sheet1','D44:NTS44');%将MCogLEACH-C每轮有效收集数据的节点数量写入表格
%  SUCCESS_MLEAUCH5=xlswrite('E:\matlab\myprogram\myprocotol\OneLayerDelayCompare\CompareSimulationresult100.xlsx',MLEAUCH_NumberofAcquisiton,'Sheet1','D45:NTS45');%将MLEAUCH每轮有效收集数据的节点数量写入表格
%  SUCCESS_MFuzzy5=xlswrite('E:\matlab\myprogram\myprocotol\OneLayerDelayCompare\CompareSimulationresult100.xlsx',MFuzzy_NumberofAcquisiton,'Sheet1','D46:NTS46');%将MFuzzy C-means每轮有效收集数据的节点数量写入表格
%  SUCCESS_DSAC5=xlswrite('CompareSimulationresult900.xlsx',DSAC_NumberofAcquisiton,'Sheet1','D36:NTS36');%将DSAC最优调度下每轮有效收集数据的节点数量写入表格
%  SUCCESS_WCM5=xlswrite('CompareSimulationresult900.xlsx',WCM_NumberofAcquisiton,'Sheet1','D37:NTS37');%将WCM最优调度下每轮有效收集数据的节点数量写入表格
%  SUCCESS_NSAC5=xlswrite('CompareSimulationresult900.xlsx',NSAC_NumberofAcquisiton,'Sheet1','D38:NTS38');%将NSAC最优调度下每轮有效收集数据的节点数量写入表格
%  SUCCESS_ION5=xlswrite('CompareSimulationresult900.xlsx',ION_NumberofAcquisiton,'Sheet1','D39:NTS39');%将NSAC最优调度下每轮选取的簇头数写入表格
%  SUCCESS_CPIRSE5=xlswrite('CompareSimulationresult900.xlsx',CPIRSE_NumberofAcquisiton,'Sheet1','D40:NTS40');%将EBUCRP每轮有效收集数据的节点数量写入表格

 %6、有效收集数据的节点比例
%  SUCCESS_EBUCRP6=xlswrite('CompareSimulationresult900.xlsx',EBUCRP_RatioofAcquisiton,'Sheet1','D42:NTS42');%将EBUCRP每轮有效收集数据的节点比例写入表格
%  SUCCESS_MCogLEACH6=xlswrite('CompareSimulationresult900.xlsx',MCogLEACH_RatioofAcquisiton,'Sheet1','D43:NTS43');%将MCogLEACH每轮有效收集数据的节点比例写入表格
%  SUCCESS_CogLEACH6=xlswrite('CompareSimulationresult900.xlsx',CogLEACH_RatioofAcquisiton,'Sheet1','D43:NTS43');%将MCogLEACH每轮有效收集数据的节点比例写入表格
 %  SUCCESS_MCogLEACHC6=xlswrite('E:\matlab\myprogram\myprocotol\OneLayerDelayCompare\CompareSimulationresult100.xlsx',MCogLEACHC_RatioofAcquisiton,'Sheet1','D54:NTS54');%将MCogLEACH-C每轮有效收集数据的节点比例写入表格
%  SUCCESS_MLEAUCH6=xlswrite('E:\matlab\myprogram\myprocotol\OneLayerDelayCompare\CompareSimulationresult100.xlsx',MLEAUCH_RatioofAcquisiton,'Sheet1','D55:NTS55');%将MLEAUCH每轮有效收集数据的节点比例写入表格
%  SUCCESS_MFuzzy6=xlswrite('E:\matlab\myprogram\myprocotol\OneLayerDelayCompare\CompareSimulationresult100.xlsx',MFuzzy_RatioofAcquisiton,'Sheet1','D56:NTS56');%将MFuzzy C-means每轮有效收集数据的节点比例写入表格
%  SUCCESS_DSAC6=xlswrite('CompareSimulationresult900.xlsx',DSAC_RatioofAcquisiton,'Sheet1','D44:NTS44');%将DSAC最优调度下每轮有效收集数据的节点比例写入表格
%  SUCCESS_WCM6=xlswrite('CompareSimulationresult900.xlsx',WCM_RatioofAcquisiton,'Sheet1','D45:NTS45');%将WCM最优调度下每轮有效收集数据的节点比例数写入表格
%  SUCCESS_NSAC6=xlswrite('CompareSimulationresult900.xlsx',NSAC_RatioofAcquisiton,'Sheet1','D46:NTS46');%将NSAC最优调度下每轮有效收集数据的节点比例数写入表格
%  SUCCESS_ION6=xlswrite('CompareSimulationresult900.xlsx',ION_RatioofAcquisiton,'Sheet1','D47:NTS47');%将NSAC最优调度下每轮选取的簇头数写入表格
%  SUCCESS_CPIRSE6=xlswrite('CompareSimulationresult900.xlsx',CPIRSE_RatioofAcquisiton,'Sheet1','D48:NTS48');%将EBUCRP每轮有效收集数据的节点比例写入表格

 %7、第一个节点死亡的轮数
%  SUCCESS_EBUCRP7=xlswrite('CompareSimulationresult900.xlsx',EBUCRP_first_dead,'Sheet1','D58:D58');%将EBUCRP第一个节点死亡的轮数写入表格
%  SUCCESS_MCogLEACH7=xlswrite('CompareSimulationresult900.xlsx',MCogLEACH_first_dead,'Sheet1','D59:D59');%将MCogLEACH第一个节点死亡的轮数写入表格
%  SUCCESS_CogLEACH7=xlswrite('CompareSimulationresult900.xlsx',CogLEACH_first_dead,'Sheet1','D59:D59');%将MCogLEACH第一个节点死亡的轮数写入表格
 %  SUCCESS_MCogLEACHC7=xlswrite('E:\matlab\myprogram\myprocotol\OneLayerDelayCompare\CompareSimulationresult100.xlsx',MCogLEACHC_first_dead,'Sheet1','D64:D64');%将MCogLEACH-C第一个节点死亡的轮数写入表格
%  SUCCESS_MLEAUCH7=xlswrite('E:\matlab\myprogram\myprocotol\OneLayerDelayCompare\CompareSimulationresult100.xlsx',MLEAUCH_first_dead,'Sheet1','D65:D65');%将MLEAUCH第一个节点死亡的轮数写入表格
%  SUCCESS_MFuzzy7=xlswrite('E:\matlab\myprogram\myprocotol\OneLayerDelayCompare\CompareSimulationresult100.xlsx',MFuzzy_first_dead,'Sheet1','D66:D66');%将MFuzzy C-means第一个节点死亡的轮数写入表格
%  SUCCESS_DSAC7=xlswrite('CompareSimulationresult900.xlsx',DSAC_first_dead,'Sheet1','D60:D60');%将DSAC最优调度下第一个节点死亡的轮数写入表格
%  SUCCESS_WCM7=xlswrite('CompareSimulationresult900.xlsx',WCM_first_dead,'Sheet1','D61:D61');%将WCM最优调度下第一个节点死亡的轮数写入表格
%  SUCCESS_NSAC7=xlswrite('CompareSimulationresult900.xlsx',NSAC_first_dead,'Sheet1','D62:D62');%将NSAC最优调度下第一个节点死亡的轮数写入表格
%  SUCCESS_ION7=xlswrite('CompareSimulationresult900.xlsx',ION_first_dead,'Sheet1','D63:D63');%将NSAC最优调度下每轮选取的簇头数写入表格
%  SUCCESS_CPIRSE7=xlswrite('CompareSimulationresult900.xlsx',CPIRSE_first_dead,'Sheet1','D64:D64');%将EBUCRP第一个节点死亡的轮数写入表格
 
 %8、最后一个节点死亡的轮数
%  SUCCESS_EBUCRP8=xlswrite('CompareSimulationresult900.xlsx',EBUCRP_last_dead,'Sheet1','D66:D66');%将EBUCRP最后一个节点死亡的轮数写入表格
%  SUCCESS_MCogLEACH8=xlswrite('CompareSimulationresult900.xlsx',MCogLEACH_last_dead,'Sheet1','D67:D67');%将MCogLEACH最后一个节点死亡的轮数写入表格
%  SUCCESS_CogLEACH8=xlswrite('CompareSimulationresult900.xlsx',CogLEACH_last_dead,'Sheet1','D67:D67');%将MCogLEACH最后一个节点死亡的轮数写入表格
 %  SUCCESS_MCogLEACHC8=xlswrite('E:\matlab\myprogram\myprocotol\OneLayerDelayCompare\CompareSimulationresult100.xlsx',MCogLEACHC_last_dead,'Sheet1','D74:D74');%将MCogLEACH-C最后一个节点死亡的轮数写入表格
%  SUCCESS_MLEAUCH8=xlswrite('E:\matlab\myprogram\myprocotol\OneLayerDelayCompare\CompareSimulationresult100.xlsx',MLEAUCH_last_dead,'Sheet1','D75:D75');%将MLEAUCH最后一个节点死亡的轮数写入表格
%  SUCCESS_MFuzzy8=xlswrite('E:\matlab\myprogram\myprocotol\OneLayerDelayCompare\CompareSimulationresult100.xlsx',MFuzzy_last_dead,'Sheet1','D76:D76');%将MFuzzy C-means最后一个节点死亡的轮数写入表格
%  SUCCESS_DSAC8=xlswrite('CompareSimulationresult900.xlsx',DSAC_last_dead,'Sheet1','D68:D68');%将DSAC最优调度下最后一个节点死亡的轮数写入表格
%  SUCCESS_WCM8=xlswrite('CompareSimulationresult900.xlsx',WCM_last_dead,'Sheet1','D69:D69');%将WCM最优调度下最后一个节点死亡的轮数写入表格
%  SUCCESS_NSAC8=xlswrite('CompareSimulationresult900.xlsx',NSAC_last_dead,'Sheet1','D70:D70');%将NSAC最优调度下最后一个节点死亡的轮数写入表格
%  SUCCESS_ION8=xlswrite('CompareSimulationresult900.xlsx',ION_last_dead,'Sheet1','D71:D71');%将NSAC最优调度下每轮选取的簇头数写入表格
%  SUCCESS_CPIRSE8=xlswrite('CompareSimulationresult900.xlsx',CPIRSE_last_dead,'Sheet1','D72:D72');%将EBUCRP最后一个节点死亡的轮数写入表格

 %9、平均时延
%  SUCCESS_EBUCRP9=xlswrite('CompareSimulationresult900.xlsx',EBUCRP_Timedelay,'Sheet1','D83:NTS83');%将EBUCRP最后一个节点死亡的轮数写入表格
%  SUCCESS_MCogLEACH9=xlswrite('CompareSimulationresult900.xlsx',MCogLEACH_Timedelay,'Sheet1','D84:NTS84');%将MCogLEACH最后一个节点死亡的轮数写入表格
% %  SUCCESS_MCogLEACHC9=xlswrite('E:\matlab\myprogram\myprocotol\OneLayerDelayCompare\CompareSimulationresult100.xlsx',MCogLEACHC_Timedelay,'Sheet1','D84:NTS84');%将MCogLEACH最后一个节点死亡的轮数写入表格
% %  SUCCESS_MLEAUCH9=xlswrite('E:\matlab\myprogram\myprocotol\OneLayerDelayCompare\CompareSimulationresult100.xlsx',MLEAUCH_Timedelay,'Sheet1','D85:NTS85');%将MCogLEACH最后一个节点死亡的轮数写入表格
% %  SUCCESS_MFuzzy9=xlswrite('E:\matlab\myprogram\myprocotol\OneLayerDelayCompare\CompareSimulationresult100.xlsx',MFuzzy_Timedelay,'Sheet1','D86:NTS86');%将MFuzzy C-means最后一个节点死亡的轮数写入表格
%  SUCCESS_DSAC9=xlswrite('CompareSimulationresult900.xlsx',DSAC_Timedelay,'Sheet1','D85:NTS85');%将DSAC最优调度下最后一个节点死亡的轮数写入表格
%  SUCCESS_WCM9=xlswrite('CompareSimulationresult900.xlsx',WCM_Timedelay,'Sheet1','D86:NTS86');%将WCM最优调度下最后一个节点死亡的轮数写入表格
%  SUCCESS_NSAC9=xlswrite('CompareSimulationresult900.xlsx',NSAC_Timedelay,'Sheet1','D87:NTS87');%将NSAC最优调度下最后一个节点死亡的轮数写入表格
%  SUCCESS_ION9=xlswrite('CompareSimulationresult900.xlsx',ION_Timedelay,'Sheet1','D88:NTS88');%将NSAC最优调度下每轮选取的簇头数写入表格
%  SUCCESS_CPIRSE9=xlswrite('CompareSimulationresult900.xlsx',CPIRSE_Timedelay,'Sheet1','D89:NTS89');%将EBUCRP最后一个节点死亡的轮数写入表格

 %10、每轮所有节点总控制能耗
%  SUCCESS_EBUCRP10=xlswrite('CompareSimulationresult900.xlsx',EBUCRP_TotalEnergyConsumption,'Sheet1','D91:NTS91');%将EBUCRP最后一个节点死亡的轮数写入表格
%  SUCCESS_MCogLEACH10=xlswrite('CompareSimulationresult900.xlsx',MCogLEACH_TotalEnergyConsumption,'Sheet1','D92:NTS92');%将MCogLEACH最后一个节点死亡的轮数写入表格
%  SUCCESS_CogLEACH10=xlswrite('CompareSimulationresult900.xlsx',CogLEACH_TotalEnergyConsumption,'Sheet1','D92:NTS92');%将MCogLEACH最后一个节点死亡的轮数写入表格
 %  SUCCESS_MCogLEACHC10=xlswrite('E:\matlab\myprogram\myprocotol\OneLayerDelayCompare\CompareSimulationresult100.xlsx',MCogLEACHC_TotalEnergyConsumption,'Sheet1','D94:NTS94');%将MCogLEACH最后一个节点死亡的轮数写入表格
%  SUCCESS_MLEAUCH10=xlswrite('E:\matlab\myprogram\myprocotol\OneLayerDelayCompare\CompareSimulationresult100.xlsx',MLEAUCH_TotalEnergyConsumption,'Sheet1','D95:NTS95');%将MCogLEACH最后一个节点死亡的轮数写入表格
%  SUCCESS_MFuzzy10=xlswrite('E:\matlab\myprogram\myprocotol\OneLayerDelayCompare\CompareSimulationresult100.xlsx',MFuzzy_TotalEnergyConsumption,'Sheet1','D96:NTS96');%将MFuzzy C-means最后一个节点死亡的轮数写入表格
%  SUCCESS_DSAC10=xlswrite('CompareSimulationresult900.xlsx',DSAC_TotalEnergyConsumption,'Sheet1','D93:NTS93');%将DSAC最优调度下最后一个节点死亡的轮数写入表格
%  SUCCESS_WCM10=xlswrite('CompareSimulationresult900.xlsx',WCM_TotalEnergyConsumption,'Sheet1','D94:NTS94');%将WCM最优调度下最后一个节点死亡的轮数写入表格
%  SUCCESS_NSAC10=xlswrite('CompareSimulationresult900.xlsx',NSAC_TotalEnergyConsumption,'Sheet1','D95:NTS95');%将NSAC最优调度下最后一个节点死亡的轮数写入表格
%  SUCCESS_ION10=xlswrite('CompareSimulationresult900.xlsx',ION_TotalEnergyConsumption,'Sheet1','D96:NTS96');%将NSAC最优调度下每轮选取的簇头数写入表格
%  SUCCESS_CPIRSE10=xlswrite('CompareSimulationresult900.xlsx',CPIRSE_TotalEnergyConsumption,'Sheet1','D97:NTS97');%将EBUCRP最后一个节点死亡的轮数写入表格

%11、每轮系统的能效
 SUCCESS_MCogLEACH10=xlswrite('CompareSimulationresult1001.xlsx',MCogLEACH_EnergyEfficiency,'Sheet1','D13:NTS13');%将MCogLEACH最后一个节点死亡的轮数写入表格
 SUCCESS_MCogLEACH10NIRS=xlswrite('CompareSimulationresult1001.xlsx',MCogLEACH_EnergyEfficiencyNIRS,'Sheet1','D14:NTS14');
 SUCCESS_MCogLEACH10Eb=xlswrite('CompareSimulationresult1001.xlsx',MCogLEACH_EnergyEfficiencyEb,'Sheet1','D15:NTS15');
 SUCCESS_MCogLEACH10P=xlswrite('CompareSimulationresult1001.xlsx',MCogLEACH_EnergyEfficiencyP,'Sheet1','D16:NTS16');
 SUCCESS_MCogLEACH10S=xlswrite('CompareSimulationresult1001.xlsx',MCogLEACH_EnergyEfficiencyS,'Sheet1','D17:NTS17');
 SUCCESS_MCogLEACH10U=xlswrite('CompareSimulationresult1001.xlsx',MCogLEACH_EnergyEfficiencyU,'Sheet1','D18:NTS18');
 SUCCESS_MCogLEACH10D=xlswrite('CompareSimulationresult1001.xlsx',MCogLEACH_EnergyEfficiencyD,'Sheet1','D19:NTS19');
 SUCCESS_MCogLEACH10R=xlswrite('CompareSimulationresult1001.xlsx',MCogLEACH_EnergyEfficiencyR,'Sheet1','D20:NTS20');
 SUCCESS_MCogLEACH10G=xlswrite('CompareSimulationresult1001.xlsx',MCogLEACH_EnergyEfficiencyG,'Sheet1','D21:NTS21');
 %  SUCCESS_CogLEACH10=xlswrite('CompareSimulationresult900.xlsx',CogLEACH_EnergyEfficiency,'Sheet1','D92:NTS92');%将MCogLEACH最后一个节点死亡的轮数写入表格
 %剩余能量
 SUCCESS_MCogLEACH9=xlswrite('CompareSimulationresult1001.xlsx',MCogLEACH_Residualenergy,'Sheet2','C3:NTR102');
 SUCCESS_MCogLEACH9nirs=xlswrite('CompareSimulationresult1001.xlsx',MCogLEACH_Residualenergynirs,'Sheet3','C3:NTR102');
 SUCCESS_MCogLEACH9ab=xlswrite('CompareSimulationresult1001.xlsx',MCogLEACH_Residualenergyab,'Sheet4','C3:NTR102');
 SUCCESS_MCogLEACH9p=xlswrite('CompareSimulationresult1001.xlsx',MCogLEACH_Residualenergyp,'Sheet2','C110:NTR209');
 SUCCESS_MCogLEACH9s=xlswrite('CompareSimulationresult1001.xlsx',MCogLEACH_Residualenergys,'Sheet3','C110:NTR209');
 SUCCESS_MCogLEACH9u=xlswrite('CompareSimulationresult1001.xlsx',MCogLEACH_Residualenergyu,'Sheet4','C110:NTR209');
 SUCCESS_MCogLEACH9d=xlswrite('CompareSimulationresult1001.xlsx',MCogLEACH_Residualenergyd,'Sheet2','C218:NTR317');
 SUCCESS_MCogLEACH9r=xlswrite('CompareSimulationresult1001.xlsx',MCogLEACH_Residualenergyr,'Sheet3','C218:NTR317');
 SUCCESS_MCogLEACH9g=xlswrite('CompareSimulationresult1001.xlsx',MCogLEACH_Residualenergyg,'Sheet4','C218:NTR317');
 %剩余能量求和
 SUCCESS_MCogLEACH101=xlswrite('CompareSimulationresult1001.xlsx',e1,'Sheet1','D23:NTS23');%将MCogLEACH最后一个节点死亡的轮数写入表格
 SUCCESS_MCogLEACH101NIRS=xlswrite('CompareSimulationresult1001.xlsx',e2,'Sheet1','D24:NTS24');
 SUCCESS_MCogLEACH101Eb=xlswrite('CompareSimulationresult1001.xlsx',e3,'Sheet1','D25:NTS25');
 SUCCESS_MCogLEACH101P=xlswrite('CompareSimulationresult1001.xlsx',e4,'Sheet1','D26:NTS26');
 SUCCESS_MCogLEACH101S=xlswrite('CompareSimulationresult1001.xlsx',e5,'Sheet1','D27:NTS27');
 SUCCESS_MCogLEACH101U=xlswrite('CompareSimulationresult1001.xlsx',e6,'Sheet1','D28:NTS28');
 SUCCESS_MCogLEACH101D=xlswrite('CompareSimulationresult1001.xlsx',e7,'Sheet1','D29:NTS29');
 SUCCESS_MCogLEACH101R=xlswrite('CompareSimulationresult1001.xlsx',e8,'Sheet1','D30:NTS30');
 SUCCESS_MCogLEACH101G=xlswrite('CompareSimulationresult1001.xlsx',e9,'Sheet1','D31:NTS31');


 SUCCESS_MCogLEACH1T=xlswrite('CompareSimulationresult1001.xlsx',MCogLEACH_TotalEnergyConsumption,'Sheet1','D33:NTS33');%将MCogLEACH每轮选取的簇头数写入表格

 %10、路由协议的开销
 SUCCESS_MCogLEACH99=xlswrite('CompareSimulationresult1001.xlsx',MCogLEACH_cutoufenbu,'Sheet5','C3:NTR102');
%10、路由协议的开销
 SUCCESS_MCogLEACH999=xlswrite('CompareSimulationresult1001.xlsx',MCogLEACH_cutouhao,'Sheet6','C3:NTR102');

%  SUCCESS_DSAC11=xlswrite('CompareSimulationresult900.xlsx',DSAC_routingoverhead,'Sheet1','D83:NTS83');%将DSAC最优调度下每轮路由的开销写入表格
%  SUCCESS_EBUCRP11=xlswrite('CompareSimulationresult900.xlsx',EBUCRP__routingoverhead,'Sheet1','D84:NTS84');%将EBUCRP最优调度下每轮路由的开销写入表格
%  SUCCESS_CPIRSE11=xlswrite('CompareSimulationresult900.xlsx',CPIRSE_overheadofCHtosink,'Sheet1','D87:NTS87');%CPIRSE中CHs向sink节点发送控制信息告知自己是CHs的开销