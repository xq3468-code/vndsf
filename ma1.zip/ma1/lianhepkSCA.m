function [ak, theta] = lianhepkSCA(hr_k, g, hd_k, M, Kcluster, SNR, Pirs, pout, derta1_2, derta2_2, wk, Edt, t1)
        for k=1:Kcluster
            theta(:,k)=mod((angle((wk(:,k))'*hd_k(:,k))*ones(M,1)-angle(diag((wk(:,k))'*g)*hr_k(:,k))),2*pi);%IRS最优相位 M*1
        end
        ak_=[];
        for k=1:Kcluster
            ak1=ones(M,1);
            ak_=[ak_ ak1];  %ak_为原文的ak_q-1，即SCA算法的初始迭代点 K个M*1
        end
        wk1=[];
        for k=1:Kcluster
            wk11=(norm(wk(:,k)))^2;  
            wk1=[wk1 wk11];  %wk1为原文的wk_，即||wk||^2
        end
        g_=[];
        for k=1:Kcluster
            g_=[g_ ; (wk(:,k))'*g];  %1*M
            G(:,:,k)=diag((abs(g_(k,:))).^2);  %M*M
            bk(:,k)=diag((hr_k(:,k))')*(g_(k,:))';  %M*1
            Hr_k(:,:,k)=diag((abs(hr_k(:,k))).^2);  %M*M
            hdk_(:,k)=(wk(:,k))'*hd_k(:,k);   %1*1
        end
        for k=1:Kcluster
            tk_(:,k)=(derta1_2*((ak_(:,k)).'*G(:,:,k)*ak_(:,k))+derta2_2*wk1(:,k))/((abs(abs(hdk_(:,k))+abs((bk(:,k))')*ak_(:,k)))^2);
            uk_(:,k)=tk_(:,k)*((ak_(:,k)).'*Hr_k(:,:,k)*ak_(:,k));
        end
        A11=[];
        for k=1:Kcluster
            A11=[A11 (t1*(((derta1_2*((ak_(:,k)).'*G(:,:,k)*ak_(:,k))+derta2_2*wk1(:,k))/((abs(abs(hdk_(:,k))+abs((bk(:,k))')*ak_(:,k)))^2))*SNR+...
                ((derta1_2*((ak_(:,k)).'*G(:,:,k)*ak_(:,k))+derta2_2*wk1(:,k))/((abs(abs(hdk_(:,k))+abs((bk(:,k))')*ak_(:,k)))^2))*SNR*((ak_(:,k)).'*Hr_k(:,:,k)*ak_(:,k))+...
                derta1_2*((ak_(:,k)).'*eye(M)*ak_(:,k))+M*Pirs))];
        end
        A_=sum(A11(1:Kcluster));
        SS_=A_+Edt;
        SSS=[];
        for Isca=1:10 %1:100  quiet
            cvx_begin quiet
                variable ak(M,Kcluster);
                variable tk(1,Kcluster);
                variable uk(1,Kcluster);
                expression A;
                A=[];
                for k=1:Kcluster
                    A=[A (t1*(tk(:,k)*SNR+SNR*uk(:,k)+derta1_2*((ak(:,k)).'*eye(M)*ak(:,k))+M*Pirs))];
                end
%                 minimize real(square_pos(norm((v0'*G0), 2)))   %二范数求模求平方用square_pos(norm(x, 2))：||x||^2
                minimize real(sum(A(1:Kcluster)))
%                 maximize real(t0*yita*real(B1)-A1-Edt-t0*(Eeh+v0'*G0*v0))
                subject to 
                for k=1:Kcluster
                    (10^10)*(derta1_2*((ak(:,k)).'*G(:,:,k)*ak(:,k))+derta2_2*wk1(:,k))<=(10^10)*(tk_(:,k)*(abs(abs(hdk_(:,k))+abs((bk(:,k))')*ak_(:,k)))^2+...
                        (abs(abs(hdk_(:,k))+abs((bk(:,k))')*ak_(:,k)))^2*(tk(:,k)-tk_(:,k))+...
                        tk_(:,k)*2*real((ak_(:,k)).'*abs(bk(:,k))*abs((bk(:,k))')+abs((hdk_(:,k))')*abs((bk(:,k))'))*(ak(:,k)-ak_(:,k)));
                    SNR*uk(:,k)+derta1_2*((ak(:,k)).'*eye(M)*ak(:,k))<=pout;
                    ((ak(:,k)).'*Hr_k(:,:,k)*ak(:,k))<=(uk_(:,k))/(tk_(:,k))+(uk(:,k)-uk_(:,k))/(tk_(:,k))-((uk_(:,k))/(tk_(:,k))^2)*(tk(:,k)-tk_(:,k));
                    tk(:,k)>=0;
                    uk(:,k)>=0;
                end
                for k=1:Kcluster
                    for m=1:M
                        ak(m,k)>=1;
                    end
                end
            cvx_end
            ASS1=[];
            for k=1:Kcluster
                ASS1=[ASS1 (t1*(((derta1_2*((ak(:,k)).'*G(:,:,k)*ak(:,k))+derta2_2*wk1(:,k))/((abs(abs(hdk_(:,k))+abs((bk(:,k))')*ak(:,k)))^2))*SNR+...
                ((derta1_2*((ak(:,k)).'*G(:,:,k)*ak(:,k))+derta2_2*wk1(:,k))/((abs(abs(hdk_(:,k))+abs((bk(:,k))')*ak(:,k)))^2))*SNR*((ak(:,k)).'*Hr_k(:,:,k)*ak(:,k))+...
                derta1_2*((ak(:,k)).'*eye(M)*ak(:,k))+M*Pirs))];
            end
            ASS=sum(ASS1(1:Kcluster));
            SS=ASS+Edt;
            if mean(abs(SS-SS_))<1e-7 %1e-8
               break
            else
               SS_=SS;
               for k=1:Kcluster
                   ak_(:,k)=ak(:,k);
                   tk_(:,k)=(derta1_2*((ak_(:,k)).'*G(:,:,k)*ak_(:,k))+derta2_2*wk1(:,k))/((abs(abs(hdk_(:,k))+abs((bk(:,k))')*ak_(:,k)))^2);
                   uk_(:,k)=tk_(:,k)*((ak_(:,k)).'*Hr_k(:,:,k)*ak_(:,k));
               end
            end
            SSS=[SSS SS];
        end
%         figure
%         plot(1:length(SSS),real(SSS));
end