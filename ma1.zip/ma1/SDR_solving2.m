function [wk, w0] = SDR_solving2(hr_k, g, hd_k, hr_n, hd_n, M, Nt, phi0, phik, Kcluster, N, SNR, PS, Pirs, pout, derta1_2, derta2_2, derta3n_2, Edt, t1, t0, yita)
% 参数初始化（确保这些变量在运行前已正确定义）
% Kcluster, Nt, M, N, hd_k, g, phik, hr_k, derta1_2, derta2_2, derta3n_2
% phi0, hr_n, hd_n, PS, yita, t0, t1, SNR, Pirs, pout, Edt

% 第一部分：计算必要的中间变量
for k = 1:Kcluster
    hk(:,k) = hd_k(:,k) + g * phik(:,:,k) * hr_k(:,k);  % Nt*1
    Gk(:,:,k) = g * phik(:,:,k);   % Nt*M
    hrk(:,k) = (norm(phik(:,:,k) * hr_k(:,k)))^2;   % 1*1
    Ik(:,k) = derta1_2 * (norm(phik(:,:,k) * eye(M)))^2;   % 1*1
end

G1 = phi0 * g';  % M*Nt
I0 = derta1_2 * (norm(phi0 * eye(M)))^2;  % 1*1

for n = 1:N
    hrn(:,n) = derta1_2 * (norm((hr_n(:,n))' * phi0))^2;  % 1*1
end

hn = [];
for n = 1:N
    hn = [hn; ((hd_n(:,n))' + (hr_n(:,n))' * phi0 * g')];  % 1*Nt
end

for k = 1:Kcluster
    Ak(:,:,k) = derta1_2 * (Gk(:,:,k) * (Gk(:,:,k))') + derta2_2 * eye(Nt);
    Hk(:,:,k) = hk(:,k) * (hk(:,k))';
end

C1 = 0;
for n = 1:N
    Cn1(:,:,n) = PS * ((hn(n,:))' * hn(n,:));
    C1 = C1 + Cn1(:,:,n);
end
C = t0 * yita * C1;

HZ1 = 0;
for n = 1:N
    Hz1(:,n) = hrn(:,n) + derta3n_2;
    HZ1 = HZ1 + Hz1(:,n);
end
HZ = t0 * yita * HZ1;

BB = PS * (G1' * G1);  % BB为原文的B

% CVX优化部分
cvx_begin sdp quiet
variable Wk1(Nt, Nt, Kcluster) hermitian semidefinite;
variable W0(Nt, Nt) hermitian semidefinite;
variable pk(1, Kcluster);

expression Y(Kcluster);
for k = 1:Kcluster
    Y(k) = t1 * (trace(Ak(:,:,k) * Wk1(:,:,k)) * SNR + ...
        trace(Ak(:,:,k) * Wk1(:,:,k)) * SNR * hrk(:,k) + ...
        Ik(:,k) + M * Pirs);
end

maximize(real(trace(C * W0) + HZ - sum(Y) - Edt - ...
    t0 * (PS * trace(W0) + M * Pirs + trace(BB * W0) + I0)));

subject to
for k = 1:Kcluster
    real(trace(Hk(:,:,k) * Wk1(:,:,k))) == 1;
    real(trace(Ak(:,:,k) * Wk1(:,:,k)) * SNR * hrk(:,k) + Ik(:,k)) <= pout;
    real(trace(Wk1(:,:,k))) <= pk(:,k);
    pk(:,k) >= 0;
    Wk1(:,:,k) == hermitian_semidefinite(Nt);
end

real(trace(BB * W0) + I0) <= pout;
real(trace(W0)) <= 1;
W0 == hermitian_semidefinite(Nt);
cvx_end

% 恢复秩1解 - 优化的高斯随机化过程
fprintf('CVX求解状态: %s\n', cvx_status);

% 初始化WK
WK = zeros(Nt, Nt, Kcluster);
for k = 1:Kcluster
    if pk(:,k) > 1e-10 % 避免除以0
        WK(:,:,k) = Wk1(:,:,k) / pk(:,k);
    else
        WK(:,:,k) = Wk1(:,:,k);
    end
end

% 高斯随机化参数
max_F = -1e20;
max_w1 = zeros(Nt, Kcluster);
max_w2 = zeros(Nt, 1);
found_feasible = false;

L2 = 5000; % 减少随机化次数以提高速度，但保证准确性

% 预计算特征分解
[U2, Sigma2] = eig((W0 + W0')/2); % 确保Hermitian
U1_k = cell(1, Kcluster);
Sigma1_k = cell(1, Kcluster);

for k = 1:Kcluster
    [U1_k{k}, Sigma1_k{k}] = eig((WK(:,:,k) + WK(:,:,k)')/2); % 确保Hermitian
end

% 高斯随机化主循环
for l = 1:L2
    % 生成w1
    w1_temp = zeros(Nt, Kcluster);
    all_valid = true;

    for k = 1:Kcluster
        valid_found = false;
        max_tries_per_k = 50;

        for try_count = 1:max_tries_per_k
            % 生成随机向量
            r1 = (randn(Nt,1) + 1j*randn(Nt,1)) / sqrt(2);
            w1_candidate = U1_k{k} * (Sigma1_k{k}.^(0.5)) * r1;

            % 归一化功率
            power_w1 = w1_candidate' * w1_candidate;
            if power_w1 > 1
                w1_candidate = w1_candidate / sqrt(power_w1);
            end

            % 计算约束相关量
            Ak_w1 = w1_candidate' * Ak(:,:,k) * w1_candidate;
            Hk_w1 = w1_candidate' * Hk(:,:,k) * w1_candidate;

            % 避免数值问题
            if abs(Hk_w1) < 1e-10
                continue;
            end

            % 检查约束
            constraint_val = real((Ak_w1 / Hk_w1) * SNR * hrk(:,k) + Ik(:,k));
            power_ok = real(w1_candidate' * w1_candidate) <= 1 + 1e-6;

            if constraint_val <= pout + 1e-6 && power_ok
                w1_temp(:,k) = w1_candidate;
                valid_found = true;
                break;
            end
        end

        if ~valid_found
            all_valid = false;
            break;
        end
    end

    if ~all_valid
        continue;
    end

    % 生成w2
    r2 = (randn(Nt,1) + 1j*randn(Nt,1)) / sqrt(2);
    w2_temp = U2 * (Sigma2.^(0.5)) * r2;

    % 归一化w2功率
    power_w2 = w2_temp' * w2_temp;
    if power_w2 > 1
        w2_temp = w2_temp / sqrt(power_w2);
    end

    % 检查w2约束
    w2_BB_constraint = real(w2_temp' * BB * w2_temp + I0);
    w2_power_ok = real(w2_temp' * w2_temp) <= 1 + 1e-6;

    if w2_BB_constraint > pout + 1e-6 || ~w2_power_ok
        continue;
    end

    % 计算目标函数
    ss = zeros(1, Kcluster);
    for k = 1:Kcluster
        Ak_w1 = w1_temp(:,k)' * Ak(:,:,k) * w1_temp(:,k);
        Hk_w1 = w1_temp(:,k)' * Hk(:,:,k) * w1_temp(:,k);

        if abs(Hk_w1) > 1e-10
            ss(k) = t1 * ((Ak_w1 / Hk_w1) * SNR + ...
                (Ak_w1 / Hk_w1) * SNR * hrk(:,k) + ...
                Ik(:,k) + M * Pirs);
        else
            ss(k) = 1e10; % 惩罚项
        end
    end

    F = real(w2_temp' * C * w2_temp + HZ - sum(ss) - Edt - ...
        t0 * (PS * (w2_temp' * w2_temp) + M * Pirs + ...
        (w2_temp' * BB * w2_temp) + I0));

    if F > max_F
        max_F = F;
        max_w1 = w1_temp;
        max_w2 = w2_temp;
        found_feasible = true;
    end
end

% 备选方案：如果没找到可行解，使用特征向量方法
if ~found_feasible
    fprintf('使用特征向量作为备选方案\n');

    % 对W0使用主特征向量
    [V0, D0] = eig((W0 + W0')/2);
    [~, idx0] = max(diag(D0));
    max_w2 = V0(:, idx0);

    % 归一化
    power_w2 = max_w2' * max_w2;
    if power_w2 > 1
        max_w2 = max_w2 / sqrt(power_w2);
    end

    % 对每个WK使用主特征向量
    for k = 1:Kcluster
        [Vk, Dk] = eig((WK(:,:,k) + WK(:,:,k)')/2);
        [~, idxk] = max(diag(Dk));
        max_w1(:,k) = Vk(:, idxk);

        % 归一化
        power_w1 = max_w1(:,k)' * max_w1(:,k);
        if power_w1 > 1
            max_w1(:,k) = max_w1(:,k) / sqrt(power_w1);
        end
    end

    % 重新计算目标函数值
    ss = zeros(1, Kcluster);
    for k = 1:Kcluster
        Ak_w1 = max_w1(:,k)' * Ak(:,:,k) * max_w1(:,k);
        Hk_w1 = max_w1(:,k)' * Hk(:,:,k) * max_w1(:,k);

        if abs(Hk_w1) > 1e-10
            ss(k) = t1 * ((Ak_w1 / Hk_w1) * SNR + ...
                (Ak_w1 / Hk_w1) * SNR * hrk(:,k) + ...
                Ik(:,k) + M * Pirs);
        else
            ss(k) = 1e10;
        end
    end

    max_F = real(max_w2' * C * max_w2 + HZ - sum(ss) - Edt - ...
        t0 * (PS * (max_w2' * max_w2) + M * Pirs + ...
        (max_w2' * BB * max_w2) + I0));
end

% 最终输出
w0 = max_w2;
wk = max_w1;

fprintf('优化完成，目标函数值: %.6f\n', max_F);
fprintf('w0功率: %.6f\n', real(w0' * w0));
for k = 1:Kcluster
    w1_power = real(wk(:,k)' * wk(:,k));
    fprintf('w%d功率: %.6f\n', k, w1_power);
end
end