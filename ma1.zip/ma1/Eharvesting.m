% function [hhm]=Eharvesting(PS)
clear;
clc;
pout=db2pow(8)/1000;%pout为5dBm 10^-2.5 10dBm:10^-2; PC=PDC=-10dBm=10^-4,pIRS=10dBm=0.01
PC=db2pow(-10)/1000;
PDC=db2pow(-10)/1000;
Pirs=PC+PDC;
PS=10; %PS为30dBm 10^0 , 40dBm:10W , 37dBm:10^0.7,46dBm:40W，此处的PA是原文的PS，下同
M=9; %反射单元数
lamuda=0.3333; %信号传输波长0.325,0.3333
C0=(lamuda/(4*pi))^2; 
Nt=4; %sink天线数量
dsink=lamuda/2; %天线之间的间隔半波长
dx=lamuda/2;%每个RE的dx,相邻RE之间假定半波长间隔
dy=lamuda/2;%每个RE的dy
CRSNspositionx=xlsread('100jiedianECM.xlsx','C2:CX2');%CRSNs节点坐标
CRSNspositiony=xlsread('100jiedianECM.xlsx','C3:CX3');
x1=CRSNspositionx;
y1=CRSNspositiony;
Eelec=50*0.000000001;%发送和接收数据时电路能耗Eelec=50nJ/b 
Efs=10*0.000000000001;%发送时功率放大器功耗取决于距离，当小于参考距离d0时为10pJ/b/m2;大于参考距离d0时为0.0013pJ/b/m4
Emp=0.0013*0.000000000001;
EDA=5*0.000000001; %聚合数据时消耗能量为5nJ/b/packet
L=1000;%数据包大小1000bit,控制包大小100bit
N=100;%簇内CRSNs节点总数为100
% R_=2;%簇半径为2m
% dCMtoCH=(2*R_)/3;
% ECM=L1*(Eelec+Efs*(dCMtoCH)^2);
% ECM=xlsread('100jiedianECM.xlsx','C14:C14');  %15CHs
% ECM=xlsread('100jiedianECM.xlsx','C18:C18');  %10CHs
% ECM=xlsread('100jiedianECM.xlsx','C22:C22');  %5CHs
% Esink=K*Eelec*L;
HIRS = 5; % IRS与平面的垂直距离
D0=1;%参考距离
derta2_2=10^-11; %噪声功率-80dBm:10^-11
derta1_2=10^-11;
derta3n_2=10^-11;
% 路损参数
alpha_SI = 2.3; %级联链路莱斯
alpha_IC = 2.3;
alpha_SC = 2.9; %直接链路自由空间
beta_SI = db2pow(3); %莱斯因子10  db2pow(3)
beta_IC = db2pow(3);
beta_SC = db2pow(3);
www=[];
t0=0.5;%sink辐射时间1s
% Rtotal=R; %Rtotal为R的倍数
yita=0.8; %能量转换效率
epsilon=1e-3;
maxIter=20;
eee=[]; %建立空数组，为最后100次取平均值做准备
hhh=[];
ppk=[];
nengxiao=[];
HHM=[];
% yIRS=-50:10:50;   %IRS:(0,yIRS,dv)-50:0.1:50
for it=1:10 %跑100次取平均值 it=1:100
    it
    weizhi=[];
    Eee=[];
    Etotal=[];
    Eeh=[];
    for yIRS=2.1   %IRS:(0,yIRS,dv)-50:0.1:50
%     for yirs=1:length(yIRS)
%         yirs
%         yIRS_irs = yIRS(yirs);
%         yIRS
        sinkloc=[0;0;0]; %sink坐标[0,0,0]
        CHsloc=[];
        IRSloc=[0;yIRS;HIRS];
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%远场条件下IRS一块板反射信号，不具体表示每个RE的坐标%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        dIS=sqrt(sum((IRSloc-sinkloc).^2)); %IRS到sink之间的距离Nt*M
        g=sqrt(C0*((dIS/D0).^(-alpha_SI)))*(sqrt(beta_SI/(beta_SI+1))*ones(Nt,M)+sqrt(1/(beta_SI+1))*(sqrt(1/2)*(randn(Nt,M)+1j*randn(Nt,M)))); 
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%上行信道构建完毕，开始构建下行信道%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        CRSNsloc=[];
        for n=1:N
            CRSNsloc=[CRSNsloc [x1(:,n);y1(:,n);0]];
        end
        dSC=[];
        for n=1:N
            dSC=[dSC sqrt(sum((CRSNsloc(:,n)-sinkloc).^2))];%sink到CRSNs距离Nt*1
        end
        dIC=[];
        for n=1:N
            dIC=[dIC sqrt(sum((CRSNsloc(:,n)-IRSloc).^2))]; %IRS到CRSNs距离1*M
        end
        for n=1:N
            hr_n(:,n)=sqrt(C0.*(((dIC(1,n))./D0).^(-alpha_IC)))*(sqrt(beta_IC/(beta_IC+1))*ones(M,1)+sqrt(1/(beta_IC+1))*(sqrt(1/2)*(randn(M,1)+1j*randn(M,1)))); %hr,n维度M*1
        end
        for n=1:N
            hd_n(:,n)=sqrt(C0.*((dSC(1,n)./D0).^(-alpha_SC)))*(sqrt(beta_IC/(beta_IC+1))*ones(Nt,1)+sqrt(1/(beta_IC+1))*(sqrt(1/2)*(randn(Nt,1)+1j*randn(Nt,1))));
        end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%至此所有信道构建完毕%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %交替优化算法
        %固定波束赋形优化反射因子矩阵
        w0c=randn(Nt,1)+1j.*randn(Nt,1);%随机生成发射波束向量
        w0_mo=sqrt(sum((abs(w0c)).^2));
        w0=w0c./w0_mo;%单位化  w0_为固定波束赋形优化反射因子矩阵的波束赋形向量，即交替优化算法的初始迭代点 Nt*1
        Etotal_old=0;
        Etotal=10;
        AO=[];
        count=0;
        while (abs((Etotal_old-Etotal)/Etotal)>epsilon && count < maxIter)
            count = count + 1;
%             count
        %SCA优化方法，得到上界
        [v0] = hSCA_solving(g, hr_n, hd_n, M,  N, PS, Pirs, pout, derta1_2, derta3n_2, w0, t0, yita);
        phi0=diag((v0)');
        %SDR优化波束赋形
        [w0] = hSDR_solving(g, hr_n, hd_n, M, Nt, phi0, N, PS, Pirs, pout, derta1_2, derta3n_2, t0, yita);
        while (size(w0,1)==1)
            w0c=randn(Nt,1)+1j.*randn(Nt,1);%随机生成发射波束向量
            w0_mo=sqrt(sum((abs(w0c)).^2));
            w0=w0c./w0_mo;%单位化  w0_为固定波束赋形优化反射因子矩阵的波束赋形向量，即交替优化算法的初始迭代点 Nt*1
            [v0] = hSCA_solving(g, hr_n, hd_n, M,  N, PS, Pirs, pout, derta1_2, derta3n_2, w0, t0, yita);
            phi0=diag((v0)');
            [w0] = hSDR_solving(g, hr_n, hd_n, M, Nt, phi0, N, PS, Pirs, pout, derta1_2, derta3n_2, t0, yita);
        end
        Etotal_old=Etotal;
        EE1=[];
        Etotal_=t0*(PS*(norm(w0))^2+M*Pirs+PS*(norm(phi0*g'*w0))^2+derta1_2*(norm(phi0*eye(M)))^2);
        HH1=[];
        for n=1:N
            HH1=[HH1 (PS*(abs(((hd_n(:,n))'+(hr_n(:,n))'*phi0*g')*w0))^2+derta1_2*(norm((hr_n(:,n))'*phi0))^2+derta3n_2)];
        end
        HH2=sum(HH1(1:N));
        Eharvesting_=t0*yita*HH2;
        Etotal=(Etotal_-Eharvesting_);
%         HHm=t0*yita*HH1;
        AO=[AO Etotal]; %看交替优化收敛性
        end
%         HHM=[HHM ; HHm];
%         AO=[AO EE];
%         end
%         figure
%         plot(1:length(AO),real(AO));
        weizhi=[weizhi Etotal]; %IRS不同位置的能效
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%所有CHs上行数据传输阶段消耗的总能量%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%         EEe1=[];
%         for k=1:K
%             EEe1=[EEe1 (t1*(((derta1_2*(norm((wk(:,k))'*g*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k(:,k)+g*phik(:,:,k)*hr_k(:,k))))^2))*SNR))];
%         end
%         EEe2=sum(EEe1(1:K));
%         Eee=[Eee EEe2];
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%所有CRSNs节点收集的总能量%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%         Eeh2=[];
%         for n=1:N
%             Eeh2=[Eeh2 (PS*(abs(((hd_n(:,n))'+(hr_n(:,n))'*phi0*g')*w0))^2+derta1_2*(norm((hr_n(:,n))'*phi0))^2+derta3n_2)];
%         end
        Eeh2=HH1;
%         Eeh1=t0*yita*sum(Eeh2(1:N));
        Eeh1=Eharvesting_;
        HHm=t0*yita*Eeh2; %每个CRSNs节点收集的能量
        Eeh=[Eeh Eeh1];
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%CHk上行数据传输的发送功率%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%         pk=[];
%         for k=1:K
%             pk=[pk ((derta1_2*(norm((wk(:,k))'*g*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k(:,k)+g*phik(:,:,k)*hr_k(:,k))))^2))*SNR];
%         end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    end
%     figure
%     plot(1:length(weizhi),real(weizhi));   
%     eee=[eee ; Eee];
    hhh=[hhh ; Eeh];
    HHM=[HHM ; HHm];
%     ppk=[ppk ; pk];
    nengxiao=[nengxiao ; weizhi]; %it次不同IRS位置能效
end
hhm=mean(HHM,1);%求矩阵每一列的均值
% ppkk=mean(ppk,1);
% hhmm=xlswrite('100jiedianECM.xlsx',hhm,'Sheet1','C37:CX37');%将EBUCRP每轮选取的簇头数写入表格
% ppkk1=xlswrite('100jiedianECM.xlsx',ppkk,'Sheet1','C40:CX40');
% rr=[];
% for i=1:100
%     rr=[rr ; i];
% end
% %%%%%%%%%%%%%无IRS
% EUL21=0;
% for k=1:K %代回初始数据传输公式
%     EUL21=EUL21+(L1*(Eelec+Efs*((d01(:,k))^2)));
% end
% Einter1=EUL21;
% Gt=1;
% Gr=1;
% sum21=0;
% for n=1:N %代回初始能量收集公式
%     YY(:,n)=(PA*Gt*Gr*lamuda^2)/(16*pi^2*(d0(:,n))^2);
%     sum21=sum21+YY(:,n);
% end
% Eharvesting1=t0*yita*sum21;
% Ebenefit1=Eharvesting1-Einter1;
% yIRS_irs=[];
% for ii=-50:0.1:50 %%%%%%%%%%%%%%%%%%%%%%%%%
%     yIRS_irs=[yIRS_irs ii];
% end
% aveintra=mean(eee,1);%求矩阵每一列的均值
% aveharvesting=mean(hhh,1);
% aveweizhi=mean(nengxiao,1);
% plot(yIRS_irs, aveweizhi,'b-o','LineWidth',2)
% grid on  %显示网格线
% xlabel('Iteration Number (m)') 
% ylabel('Energy Efficiency (Bits/Joule/Hz)')
% legend('Nt=4')
% % sum=[];
% % for i=-50:0.1:50
% %     sum=[sum ; i];
% % end
% i=0;
% as=0;
% ass=xlsread('C:\Users\亚楠\Desktop\仿真结果.xlsx','Sheet2','D4:D1004');
% for j=1:length(ass)
%     if ass(j)>as
%         as=ass(j);
%         i=j;
%     end
% end