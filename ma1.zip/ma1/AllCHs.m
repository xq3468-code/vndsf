clc;
clear;
pout=db2pow(8)/1000;%pout为5dBm 10^-2.5 10dBm:10^-2; PC=PDC=-10dBm=10^-4,pIRS=10dBm=0.01
PC=db2pow(-10)/1000;
PDC=db2pow(-10)/1000;
Pirs=PC+PDC;
PS=10; %PS为30dBm 10^0 , 40dBm:10W , 37dBm:10^0.7,46dBm:40W，此处的PA是原文的PS，下同
M=10; %反射单元数
lamuda=0.3333; %信号传输波长0.325,0.3333
C0=(lamuda/(4*pi))^2; 
Nt=4; %sink天线数量
dsink=lamuda/2; %天线之间的间隔半波长
dx=lamuda/2;%每个RE的dx,相邻RE之间假定半波长间隔
dy=lamuda/2;%每个RE的dy
% K=20;%20个簇,sink(0,0,0),IRS(0,yIRS,dv),CHs(x(k),y(k),0)%%%%%%%%%%改变CHs数，ECM也要改
% CHpositionx=xlsread('100jiedianECM.xlsx','C7:V7');%CH节点坐标
% CHpositiony=xlsread('100jiedianECM.xlsx','C8:V8');
% K=15; %15个簇,sink(0,0,0),IRS(0,yIRS,dv),CHs(x(k),y(k),0)%%%%%%%%%%改变CHs数，ECM也要改
% CHpositionx=xlsread('100jiedianECM.xlsx','C11:Q11');%CH节点坐标
% CHpositiony=xlsread('100jiedianECM.xlsx','C12:Q12');
% K=10; %10个簇,sink(0,0,0),IRS(0,yIRS,dv),CHs(x(k),y(k),0)%%%%%%%%%%改变CHs数，ECM也要改
% CHpositionx=xlsread('100jiedianECM.xlsx','C15:L15');%CH节点坐标
% CHpositiony=xlsread('100jiedianECM.xlsx','C16:L16');
% K=5; %5个簇,sink(0,0,0),IRS(0,yIRS,dv),CHs(x(k),y(k),0)%%%%%%%%%%改变CHs数，ECM也要改
% CHpositionx=xlsread('100jiedianECM.xlsx','C19:G19');%CH节点坐标
% CHpositiony=xlsread('100jiedianECM.xlsx','C20:G20');
% x=CHpositionx;
% y=CHpositiony;
CRSNspositionx=xlsread('100jiedianECM.xlsx','C2:CX2');%CRSNs节点坐标
CRSNspositiony=xlsread('100jiedianECM.xlsx','C3:CX3');
x1=CRSNspositionx;
y1=CRSNspositiony;
K=100;%20个簇,sink(0,0,0),IRS(0,yIRS,dv),CHs(x(k),y(k),0)%%%%%%%%%%改变CHs数，ECM也要改
CHpositionx=CRSNspositionx;%CH节点坐标
CHpositiony=CRSNspositiony;
x=CHpositionx;
y=CHpositiony;
Eelec=50*0.000000001;%发送和接收数据时电路能耗Eelec=50nJ/b 
Efs=10*0.000000000001;%发送时功率放大器功耗取决于距离，当小于参考距离d0时为10pJ/b/m2;大于参考距离d0时为0.0013pJ/b/m4
Emp=0.0013*0.000000000001;
EDA=5*0.000000001; %聚合数据时消耗能量为5nJ/b/packet
L1=1000;%数据包大小1000bit,控制包大小100bit
N=100;%簇内CRSNs节点总数为100
% R_=2;%簇半径为2m
% dCMtoCH=(2*R_)/3;
ECM=0;
% ECM=L1*(Eelec+Efs*(dCMtoCH)^2);
% ECM=xlsread('100jiedianECM.xlsx','C10:C10');  %20CHs  %ECM是从CogLEACH中算出来的，此处的ECM为原文的(N-K)*ECM
% ECM=xlsread('100jiedianECM.xlsx','C14:C14');  %15CHs
% ECM=xlsread('100jiedianECM.xlsx','C18:C18');  %10CHs
% ECM=xlsread('100jiedianECM.xlsx','C22:C22');  %5CHs
ECH_intra=((N/K)-1)*(Eelec+EDA)*L1;
Esink=K*Eelec*L1;
Edt=K*Eelec*L1+ECM+K*ECH_intra;
HIRS = 5; % IRS与平面的垂直距离
D0=1;%参考距离
derta2_2=10^-11; %噪声功率-80dBm:10^-11
derta1_2=10^-11;
derta3n_2=10^-11;
% 路损参数
alpha_SI = 2.3; %级联链路莱斯
alpha_IC = 2.3;
alpha_SC = 2.9; %直接链路自由空间
% beta_SI = 10; %莱斯因子10  db2pow(3)
% beta_IC = 10;
% beta_SC = 10;
beta_SI = db2pow(3); %莱斯因子10  db2pow(3)
beta_IC = db2pow(3);
beta_SC = db2pow(3);
www=[];
t0=0.5;%sink辐射时间1s
t1=0.001;%CH k上行数据传输时长0.01s  此处的t1为原文的taok  taok=L/Rs=1000/10^6=0.001s
SNR=db2pow(30);%30dB
Bt=100000; %信道带宽  Rb=Blog2(1+SNR),Rb=1Mbps,SNR=30dB,推出B=1.0033e+05
R=Bt*log2(1+SNR);
tintra=(N/K-1)*(L1/(Bt*log2(1+SNR)));
T=K*t1+t0+tintra;
Rtotal=((Bt*log2(1+SNR))*K*tintra+(t1*K)*R)/(T-t0);
% Rtotal=R; %Rtotal为R的倍数
yita=0.8; %能量转换效率
epsilon=1e-3;
maxIter=20;
eee=[]; %建立空数组，为最后100次取平均值做准备
hhh=[];
nengxiao=[];
ppk=[];
% yIRS=-50:10:50;   %IRS:(0,yIRS,dv)-50:0.1:50
for it=4 %跑100次取平均值 it=1:100
    it
    weizhi=[];
    Eee=[];
    Etotal=[];
    Eeh=[];
    for yIRS=0   %IRS:(0,yIRS,dv)-50:0.1:50   
%     for yirs=1:length(yIRS)
%         yirs
%         yIRS_irs = yIRS(yirs);
        yIRS
        sinkloc=[0;0;0]; %sink坐标[0,0,0]
        CHsloc=[];
        IRSloc=[0;yIRS;HIRS];
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%远场条件下IRS一块板反射信号，不具体表示每个RE的坐标%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        dIS=sqrt(sum((IRSloc-sinkloc).^2)); %IRS到sink之间的距离Nt*M
        for k=1:K
            CHsloc=[CHsloc [x(:,k);y(:,k);0]];
        end
        dCS=[]; 
        for k=1:K
            dCS=[dCS sqrt(sum((sinkloc-CHsloc(:,k)).^2))];%sink到CHs距离Nt*1
        end
        dCI=[];
        for k=1:K
            dCI=[dCI sqrt(sum((CHsloc(:,k)-IRSloc).^2))]; %CHs到IRS距离M*1
        end
        g=sqrt(C0*((dIS/D0).^(-alpha_SI)))*(sqrt(beta_SI/(beta_SI+1))*ones(Nt,M)+sqrt(1/(beta_SI+1))*(sqrt(1/2)*(randn(Nt,M)+1j*randn(Nt,M)))); 
        for k=1:K
            hr_k(:,k)=sqrt(C0.*(((dCI(1,k))./D0).^(-alpha_IC)))*(sqrt(beta_IC/(beta_IC+1))*ones(M,1)+sqrt(1/(beta_IC+1))*(sqrt(1/2)*(randn(M,1)+1j*randn(M,1)))); %上行CH到IRS信道M*1
        end
        for k=1:K
            hd_k(:,k)=sqrt(C0.*((dCS(:,k)./D0).^(-alpha_SC)))*(sqrt(beta_IC/(beta_IC+1))*ones(Nt,1)+sqrt(1/(beta_IC+1))*(sqrt(1/2)*(randn(Nt,1)+1j*randn(Nt,1)))); %上行CH到sink信道Nt*1
        end
%         g=(sqrt(C0*((dIS/D0).^(-alpha_SI))).*exp(-1j*((2*pi/lamuda)*dIS)))*ones(Nt,M); 
%         for k=1:K
%             hr_k(:,k)=(sqrt(C0.*(((dCI(1,k))./D0).^(-alpha_IC))).*exp(-1j.*((2*pi/lamuda).*(dCI(1,k)))))*ones(M,1); %上行CH到IRS信道M*1
%         end
%         for k=1:K
%             hd_k(:,k)=(sqrt(C0.*((dCS(:,k)./D0).^(-alpha_SC))).*exp(-1j.*((2*pi/lamuda).*(dCS(:,k)))))*ones(Nt,1); %上行CH到sink信道Nt*1
%         end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%上行信道构建完毕，开始构建下行信道%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        CRSNsloc=[];
        for n=1:N
            CRSNsloc=[CRSNsloc [x1(:,n);y1(:,n);0]];
        end
        dSC=[];
        for n=1:N
            dSC=[dSC sqrt(sum((CRSNsloc(:,n)-sinkloc).^2))];%sink到CRSNs距离Nt*1
        end
        dIC=[];
        for n=1:N
            dIC=[dIC sqrt(sum((CRSNsloc(:,n)-IRSloc).^2))]; %IRS到CRSNs距离1*M
        end
        for n=1:N
            hr_n(:,n)=sqrt(C0.*(((dIC(1,n))./D0).^(-alpha_IC)))*(sqrt(beta_IC/(beta_IC+1))*ones(M,1)+sqrt(1/(beta_IC+1))*(sqrt(1/2)*(randn(M,1)+1j*randn(M,1)))); %hr,n维度M*1
        end
        for n=1:N
            hd_n(:,n)=sqrt(C0.*((dSC(1,n)./D0).^(-alpha_SC)))*(sqrt(beta_IC/(beta_IC+1))*ones(Nt,1)+sqrt(1/(beta_IC+1))*(sqrt(1/2)*(randn(Nt,1)+1j*randn(Nt,1))));
        end
%         for n=1:N
%             hr_n(:,n)=(sqrt(C0.*(((dIC(1,n))./D0).^(-alpha_IC))).*exp(-1j.*((2*pi/lamuda).*(dIC(1,n)))))*ones(M,1); %hr,n维度M*1
%         end
%         for n=1:N
%             hd_n(:,n)=(sqrt(C0.*((dSC(1,n)./D0).^(-alpha_SC))).*exp(-1j.*((2*pi/lamuda).*(dSC(1,n)))))*ones(Nt,1);
%         end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%至此所有信道构建完毕%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %交替优化算法
        %固定波束赋形优化反射因子矩阵
        w0c=randn(Nt,1)+1j.*randn(Nt,1);%随机生成发射波束向量
        w0_mo=sqrt(sum((abs(w0c)).^2));
        w0=w0c./w0_mo;%单位化  w0_为固定波束赋形优化反射因子矩阵的波束赋形向量，即交替优化算法的初始迭代点 Nt*1
        wk0=[];
        for k=1:K
            wkc=randn(Nt,1)+1j.*randn(Nt,1);%随机生成发射波束向量
            wk_mo=sqrt(sum((abs(wkc)).^2));
            wk_1=wkc./wk_mo;%单位化
            wk0=[wk0  wk_1];  %wk_为固定波束赋形优化反射因子矩阵的波束赋形向量，即交替优化算法的初始迭代点 Nt*1
        end
        wk=wk0;
        EE_old=0;
        EE=10;
        AO=[];
%         for Iao=1:50
%             Iao
%         if (abs((EE_old-EE)/EE)>epsilon)
        count=0;
        while (abs((EE_old-EE)/EE)>epsilon && count < maxIter)
            count = count + 1;
%             count
        %SCA优化方法，得到上界
        [ak, v0, theta] = SCA_solving(hr_k, g, hd_k, hr_n, hd_n, M, K, N, SNR, PS, Pirs, pout, derta1_2, derta2_2, derta3n_2, w0, wk, Edt, t1, t0, yita);
        for k=1:K
            vk(:,k)=ak(:,k).*exp(1j.*theta(:,k));
            phik(:,:,k)=diag((vk(:,k)).');
        end
        phi0=diag((v0)');
        %SDR优化波束赋形
        [wk, w0] = SDR_solving(hr_k, g, hd_k, hr_n, hd_n, M, Nt, phi0, phik, K, N, SNR, PS, Pirs, pout, derta1_2, derta2_2, derta3n_2, Edt, t1, t0, yita);
        while (size(w0,1)==1 || size(wk,1)==1)
            w0c=randn(Nt,1)+1j.*randn(Nt,1);%随机生成发射波束向量
            w0_mo=sqrt(sum((abs(w0c)).^2));
            w0=w0c./w0_mo;%单位化  w0_为固定波束赋形优化反射因子矩阵的波束赋形向量，即交替优化算法的初始迭代点 Nt*1
            wk0=[];
            for k=1:K
                wkc=randn(Nt,1)+1j.*randn(Nt,1);%随机生成发射波束向量
                wk_mo=sqrt(sum((abs(wkc)).^2));
                wk_1=wkc./wk_mo;%单位化
                wk0=[wk0  wk_1];  %wk_为固定波束赋形优化反射因子矩阵的波束赋形向量，即交替优化算法的初始迭代点 Nt*1
            end
            wk=wk0;
            [ak, v0, theta] = SCA_solving(hr_k, g, hd_k, hr_n, hd_n, M, K, N, SNR, PS, Pirs, pout, derta1_2, derta2_2, derta3n_2, w0, wk, Edt, t1, t0, yita);
            for k=1:K
                vk(:,k)=ak(:,k).*exp(1j.*theta(:,k));
                phik(:,:,k)=diag((vk(:,k)).');
            end
            phi0=diag((v0)');
            [wk, w0] = SDR_solving(hr_k, g, hd_k, hr_n, hd_n, M, Nt, phi0, phik, K, N, SNR, PS, Pirs, pout, derta1_2, derta2_2, derta3n_2, Edt, t1, t0, yita);
        end
        EE_old=EE;
        EE1=[];
        for k=1:K
            EE1=[EE1 (t1*(((derta1_2*(norm((wk(:,k))'*g*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k(:,k)+g*phik(:,:,k)*hr_k(:,k))))^2))*SNR+...
                ((derta1_2*(norm((wk(:,k))'*g*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k(:,k)+g*phik(:,:,k)*hr_k(:,k))))^2))*SNR*(norm(phik(:,:,k)*hr_k(:,k)))^2+...
                derta1_2*(norm(phik(:,:,k)*eye(M)))^2+M*Pirs)+(Eelec+EDA)*L1)];
        end
        EE2=sum(EE1(1:K));
        Etotal_=EE2+Esink+ECM+K*ECH_intra+t0*(PS*(norm(w0))^2+M*Pirs+PS*(norm(phi0*g'*w0))^2+derta1_2*(norm(phi0*eye(M)))^2);
        HH1=[];
        for n=1:N
            HH1=[HH1 (PS*(abs(((hd_n(:,n))'+(hr_n(:,n))'*phi0*g')*w0))^2+derta1_2*(norm((hr_n(:,n))'*phi0))^2+derta3n_2)];
        end
        HH2=sum(HH1(1:N));
        Eharvesting_=t0*yita*HH2;
        EE=Rtotal/(Etotal_-Eharvesting_);
        AO=[AO EE]; %看交替优化收敛性
        end
%         AO=[AO EE];
%         end
%         figure
%         plot(1:length(AO),real(AO));
        weizhi=[weizhi EE]; %IRS不同位置的能效
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%所有CHs上行数据传输阶段消耗的总能量%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        EEe1=[];
        for k=1:K
            EEe1=[EEe1 (t1*(((derta1_2*(norm((wk(:,k))'*g*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k(:,k)+g*phik(:,:,k)*hr_k(:,k))))^2))*SNR))];
        end
        EEe2=sum(EEe1(1:K));
        Eee=[Eee EEe2];
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%所有CRSNs节点收集的总能量%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        Eeh2=[];
        for n=1:N
            Eeh2=[Eeh2 (PS*(abs(((hd_n(:,n))'+(hr_n(:,n))'*phi0*g')*w0))^2+derta1_2*(norm((hr_n(:,n))'*phi0))^2+derta3n_2)];
        end
        Eeh1=t0*yita*sum(Eeh2(1:N));
        Eeh=[Eeh Eeh1];
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%CHk上行数据传输的功率%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        pk=[];
        for k=1:K
            pk=[pk ((derta1_2*(norm((wk(:,k))'*g*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k(:,k)+g*phik(:,:,k)*hr_k(:,k))))^2))*SNR];
        end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    end
%     figure
%     plot(1:length(weizhi),real(weizhi));
    eee=[eee ; Eee];
    ppk=[ppk ; pk];
    hhh=[hhh ; Eeh];
    nengxiao=[nengxiao ; weizhi]; %it次不同IRS位置能效
end
% %%%%%%%%%%%%%无IRS
