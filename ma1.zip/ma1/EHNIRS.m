clear;
clc;
PS=10; %PS为30dBm 10^0 , 40dBm:10W , 37dBm:10^0.7,46dBm:40W，此处的PA是原文的PS，下同
lamuda=0.3333; %信号传输波长0.325,0.3333
C0=(lamuda/(4*pi))^2; 
Nt=4; %sink天线数量
Kcluster=100;
CRSNspositionx=xlsread('100jiedianECM.xlsx','C2:CX2');%CRSNs节点坐标
CRSNspositiony=xlsread('100jiedianECM.xlsx','C3:CX3');
x1=CRSNspositionx;
y1=CRSNspositiony;
x=CRSNspositionx;
y=CRSNspositiony;
Eelec=50*0.000000001;%发送和接收数据时电路能耗Eelec=50nJ/b 
Efs=10*0.000000000001;%发送时功率放大器功耗取决于距离，当小于参考距离d0时为10pJ/b/m2;大于参考距离d0时为0.0013pJ/b/m4
Emp=0.0013*0.000000000001;
EDA=5*0.000000001; %聚合数据时消耗能量为5nJ/b/packet
L=1000;%数据包大小1000bit,控制包大小100bit                              
N=100;%簇内CRSNs节点总数为100
D0=1;
ECM=0;
ECH_intra=0;
Esink=Kcluster*Eelec*L;
Edt=Esink+ECM+ECH_intra;
derta2_2=10^-11; %噪声功率-80dBm:10^-11
derta1_2=10^-11;
derta3n_2=10^-11;
% 路损参数
alpha_SI = 2.3; %级联链路莱斯
alpha_IC = 2.3;
alpha_SC = 2.9; %直接链路自由空间
% beta_SI = 10; %莱斯因子10  db2pow(3)
% beta_IC = 10;
% beta_SC = 10;
beta_SI = db2pow(3); %莱斯因子10  db2pow(3)
beta_IC = db2pow(3);
beta_SC = db2pow(3);
% www=[];
t0=0.5;%sink辐射时间1s
t1=0.001;%CH k上行数据传输时长0.01s  此处的t1为原文的taok  taok=L/Rs=1000/10^6=0.001s
SNR=db2pow(30);%30dB
Bt=100000; %信道带宽  Rb=Blog2(1+SNR),Rb=1Mbps,SNR=30dB,推出B=1.0033e+05
R=Bt*log2(1+SNR);
tintra=(N/Kcluster-1)*(L/(Bt*log2(1+SNR)));
T=Kcluster*t1+t0+tintra;
Rtotal=((Bt*log2(1+SNR))*Kcluster*tintra+(t1*Kcluster)*R)/(T-t0);
% Rtotal=R; %Rtotal为R的倍数
yita=0.8; %能量转换效率
epsilon=1e-3;
maxIter=20;
eee1=[];
ES=[];
Exx=[];
% eee=[]; %建立空数组，为最后100次取平均值做准备
% hhh=[];
% ppk=[];
nengxiao=[];
HHM=[];
% yIRS=-50:10:50;   %IRS:(0,yIRS,dv)-50:0.1:50
for it=1:30 %跑100次取平均值 it=1:100
    it
%     weizhi=[];
%     Eee=[];
%     Etotal=[];
%     Eeh=[];
    for yIRS=2.1   %IRS:(0,yIRS,dv)-50:0.1:50
%     for yirs=1:length(yIRS)
%         yirs
%         yIRS_irs = yIRS(yirs);
%         yIRS
        sinkloc=[0;0]; %sink坐标[0,0,0]
        CHsloc=[];
%         IRSloc=[0;yIRS;HIRS];
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%远场条件下IRS一块板反射信号，不具体表示每个RE的坐标%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%         dIS=sqrt(sum((IRSloc-sinkloc).^2)); %IRS到sink之间的距离Nt*M
        for k=1:Kcluster
            CHsloc=[CHsloc [x(:,k);y(:,k)]];
        end
        dCS=[]; 
        for k=1:Kcluster
            dCS=[dCS sqrt(sum((sinkloc-CHsloc(:,k)).^2))];%sink到CHs距离Nt*1
        end
%         dCI=[];
%         for k=1:Kcluster
%             dCI=[dCI sqrt(sum((CHsloc(:,k)-IRSloc).^2))]; %CHs到IRS距离M*1
%         end
%         g=sqrt(C0*((dIS/D0).^(-alpha_SI)))*(sqrt(beta_SI/(beta_SI+1))*ones(Nt,M)+sqrt(1/(beta_SI+1))*(sqrt(1/2)*(randn(Nt,M)+1j*randn(Nt,M)))); 
%         for k=1:Kcluster
%             hr_k(:,k)=sqrt(C0.*(((dCI(1,k))./D0).^(-alpha_IC)))*(sqrt(beta_IC/(beta_IC+1))*ones(M,1)+sqrt(1/(beta_IC+1))*(sqrt(1/2)*(randn(M,1)+1j*randn(M,1)))); %上行CH到IRS信道M*1
%         end
        for k=1:Kcluster
            hd_k(:,k)=sqrt(C0.*((dCS(:,k)./D0).^(-alpha_SC)))*(sqrt(beta_SC/(beta_SC+1))*ones(Nt,1)+sqrt(1/(beta_SC+1))*(sqrt(1/2)*(randn(Nt,1)+1j*randn(Nt,1)))); %上行CH到sink信道Nt*1
        end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%上行信道构建完毕，开始构建下行信道%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        CRSNsloc=[];
        for n1=1:N
            CRSNsloc=[CRSNsloc [x1(:,n1);y1(:,n1)]];
        end
        dSC=[];
        for n1=1:N
            dSC=[dSC sqrt(sum((CRSNsloc(:,n1)-sinkloc).^2))];%sink到CRSNs距离Nt*1
        end
%         dIC=[];
%         for n=1:N
%             dIC=[dIC sqrt(sum((CRSNsloc(:,n)-IRSloc).^2))]; %IRS到CRSNs距离1*M
%         end
%         for n=1:N
%             hr_n(:,n)=sqrt(C0.*(((dIC(1,n))./D0).^(-alpha_IC)))*(sqrt(beta_IC/(beta_IC+1))*ones(M,1)+sqrt(1/(beta_IC+1))*(sqrt(1/2)*(randn(M,1)+1j*randn(M,1)))); %hr,n维度M*1
%         end
        for n1=1:N
            hd_n(:,n1)=sqrt(C0.*((dSC(1,n1)./D0).^(-alpha_SC)))*(sqrt(beta_SC/(beta_SC+1))*ones(Nt,1)+sqrt(1/(beta_SC+1))*(sqrt(1/2)*(randn(Nt,1)+1j*randn(Nt,1))));
        end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%至此所有信道构建完毕%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        %SDR优化波束赋形
        [w0] = EHNIRS_SDR(hd_k, hd_n, Nt, Kcluster, N, PS, derta2_2, t0, yita);
        while (size(w0,1)==1)
            [w0] = EHNIRS_SDR(hd_k, hd_n, Nt, Kcluster, N, PS, derta2_2, t0, yita);
        end
%       EE_old=EE;
        
        HH1=[];
        for n1=1:N
            HH1=[HH1 (PS*(abs((hd_n(:,n1))'*w0))^2)];
        end
        HH2=sum(HH1(1:N));
        Eharvesting_=t0*yita*HH2;
%         HHm=t0*yita*HH1;
%         AO=[AO EE]; %看交替优化收敛性
%         end
%         HHM=[HHM ; HHm];
%         AO=[AO EE];
%         end
%         figure
%         plot(1:length(AO),real(AO));
%         weizhi=[weizhi EE]; %IRS不同位置的能效
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%所有CHs上行数据传输阶段消耗的总能量%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%         EEe2=sum(EEe1(1:Kcluster));
%         Eee=[Eee EEe2];
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%EH-CRSNs总功耗%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%         Egonghao=Etotal_; %CHs向sink传输数据的功耗，上下行主动IRS的功耗，sink的功耗

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%所有CRSNs节点收集的总能量%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        Eeh1=Eharvesting_; %所有CRSNs节点收集的总能量
        HHm=t0*yita*HH1; %每个CRSNs节点收集的能量
%         Eeh=[Eeh Eeh1];
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%CHk上行数据传输的发送功率%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%         pk=[];
%         for k=1:Kcluster
%             pk=[pk ((derta1_2*(norm((wk(:,k))'*g*phik(:,:,k)))^2+derta2_2*(norm(wk(:,k)))^2)/((abs((wk(:,k))'*(hd_k(:,k)+g*phik(:,:,k)*hr_k(:,k))))^2))*SNR];
%         end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    end
%     figure
%     plot(1:length(weizhi),real(weizhi));
%     eee1=[eee1 ; EEe1];
%     ES=[ES ; EE1];
%     Exx=[Exx ; Ex];
%     eee=[eee ; Eee];
%     hhh=[hhh ; Eeh];
    HHM=[HHM ; HHm];
%     ppk=[ppk ; pk];
%     nengxiao=[nengxiao ; EE]; %it次不同IRS位置能效
end
% eemNIRS=mean(eee1,1);
% EEmNIRS=mean(nengxiao,1);
% ESS=mean(ES,1);
% EXX=mean(Exx,1);
hhm=mean(HHM,1);%求矩阵每一列的均值a=[1; 3; 5; 7];mean(a,1)
