function [w0] = pehSDR(g, hr_n, hd_n, M, Nt, phi0, N, PS, PC,  derta1_2, t0, yita)
        G1=phi0*g';  %M*Nt
        I0=derta1_2*(norm(phi0*eye(M)))^2;  %1*1
        for n=1:N
            hrn(:,n)=derta1_2*(norm((hr_n(:,n))'*phi0))^2;  %1*1
        end
        hn=[];
        for n=1:N
            hn=[hn ; ((hd_n(:,n))'+(hr_n(:,n))'*phi0*g')];  %1*Nt
        end
        C1=0;
        for n=1:N
            Cn1(:,:,n)=PS*((hn(n,:))'*hn(n,:));
            C1=C1+Cn1(:,:,n);
        end
        C=t0*yita*C1;
        cvx_begin sdp quiet
            variable W0(Nt,Nt) hermitian semidefinite; 
%             minimize real(Y1+Edt+t0*(PS*trace(W0)+M*PIRS+trace(BB*W0)+I0)-t0*yita*Z1);
            maximize real(trace(C*W0)-t0*(PS*trace(W0)+M*PC));
            subject to
            real(trace(W0))<=1;
            W0==hermitian_semidefinite(Nt);
       cvx_end
       %恢复秩1解
       max_F=-10;
       max_w2=0;
       L=10000;
       [U2, Sigma2] = eig(W0);
       for l = 1 : L
           r2=sqrt(2)/2*(randn(Nt,1)+1j*randn(Nt,1));
           w2=U2 * (Sigma2)^(0.5) * r2;  %构造秩1矩阵解
           F=w2'*C*w2-t0*(PS*(w2'*w2)+M*PC);
           if (F > max_F && w2'*w2<=1)
              max_F = F;
              max_w2 = w2;
           end
       end
       w0=max_w2;
end