function [wk, w0] = passiveSDR(hr_k, g, hd_k, hr_n, hd_n, M, Nt, phi0, phik, K, N, SNR, PS, PC,  derta1_2, derta2_2, Edt, t1, t0, yita)
        for k=1:K
            hk(:,k)=hd_k(:,k)+g*phik(:,:,k)*hr_k(:,k);  %Nt*1
            Gk(:,:,k)=g*phik(:,:,k);   %Nt*M
            hrk(:,k)=(norm(phik(:,:,k)*hr_k(:,k)))^2;   %1*1
            Ik(:,k)=derta1_2*(norm(phik(:,:,k)*eye(M)))^2;   %1*1
        end
        G1=phi0*g';  %M*Nt
        I0=derta1_2*(norm(phi0*eye(M)))^2;  %1*1
        for n=1:N
            hrn(:,n)=derta1_2*(norm((hr_n(:,n))'*phi0))^2;  %1*1
        end
        hn=[];
        for n=1:N
            hn=[hn ; ((hd_n(:,n))'+(hr_n(:,n))'*phi0*g')];  %1*Nt
        end
       
        for k=1:K
            Ak(:,:,k)=derta2_2*eye(Nt);
            Hk(:,:,k)=hk(:,k)*(hk(:,k))';
        end
        C1=0;
        for n=1:N
            Cn1(:,:,n)=PS*((hn(n,:))'*hn(n,:));
            C1=C1+Cn1(:,:,n);
        end
        C=t0*yita*C1;
        cvx_begin sdp quiet
            variable Wk1(Nt,Nt,K) hermitian semidefinite;%此处的Wk1是原文的Wk~,即pk*Wk,非负常数乘以半正定阵仍是半正定的 
            variable W0(Nt,Nt) hermitian semidefinite; 
            variable pk(1,K);
            expression Y;
            Y=[];
            for k=1:K
                Y=[Y (t1*((trace(Ak(:,:,k)*Wk1(:,:,k)))*SNR+M*PC))];
            end
%             Y1=sum(Y(1:K));
%             minimize real(Y1+Edt+t0*(PS*trace(W0)+M*PIRS+trace(BB*W0)+I0)-t0*yita*Z1);
            maximize real(trace(C*W0)-sum(Y(1:K))-Edt-t0*(PS*trace(W0)+M*PC));
            subject to
            for k=1:K
                real(trace(Hk(:,:,k)*Wk1(:,:,k)))==1;
                real(trace(Wk1(:,:,k)))<=pk(:,k);
                pk(:,k)>=0;
                Wk1(:,:,k)==hermitian_semidefinite(Nt);
            end
            real(trace(W0))<=1;
            W0==hermitian_semidefinite(Nt);
       cvx_end
       %恢复秩1解
       for k=1:K
           WK(:,:,k)=Wk1(:,:,k)/pk(:,k);
       end
       max_F=-10;
       max_w2=0;
       for k=1:K
           max_w1(:,k)=0;
       end
       L=10000;
       [U2, Sigma2] = eig(W0);
       for l = 1 : L
           w1=[];
           r1=sqrt(2)/2*(randn(Nt,1)+1j*randn(Nt,1));
           for k=1:K
               [U1,Sigma1]=eig(WK(:,:,k));%对每一个WK特征值分解
               s_=U1 * (Sigma1)^(0.5) * r1;
               w1=[w1 s_];%用U*sqrt(Sigma)*r表示每个时隙生成的是，并放在同一个数组中,构造K个秩1矩阵解
           end
           r2=sqrt(2)/2*(randn(Nt,1)+1j*randn(Nt,1));
           w2=U2 * (Sigma2)^(0.5) * r2;  %构造秩1矩阵解
           ss=[];
           for k=1:K
               ss=[ss (t1*((((w1(:,k))'*Ak(:,:,k)*(w1(:,k)))/((w1(:,k))'*Hk(:,:,k)*(w1(:,k))))*SNR+M*PC))];
           end
           F=w2'*C*w2-sum(ss(1:K))-Edt-t0*(PS*(w2'*w2)+M*PC);
           for k=1:K
               if (((w1(:,k)).'*(w1(:,k)))<=1)
                   ttt(k)=1;
               else
                   ttt(k)=0;
               end
           end
           if (F > max_F && w2'*w2<=1 && all(ttt)==1)
              max_F = F;
              max_w1 = w1;
              max_w2 = w2;
           end
       end
       w0=max_w2;
       wk=max_w1;
end