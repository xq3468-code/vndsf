function [wk, w0] = NIRS_SDR(hd_k, hd_n, Nt, Kcluster, N, SNR, PS, derta2_2, Edt, t1, t0, yita, Eelec, EDA, L)
       for k=1:Kcluster
           Ak(:,:,k)=derta2_2*eye(Nt);
           Hk(:,:,k)=hd_k(:,k)*(hd_k(:,k))';
       end
       C1=0;
       for n1=1:N
           Cn1(:,:,n1)=PS*(hd_n(:,n1)*(hd_n(:,n1))');
           C1=C1+Cn1(:,:,n1);
       end
       C=t0*yita*C1;
       cvx_begin sdp quiet
            variable Wk1(Nt,Nt,Kcluster) hermitian semidefinite;%此处的Wk1是原文的Wk~,即pk*Wk,非负常数乘以半正定阵仍是半正定的 
            variable W0(Nt,Nt) hermitian semidefinite; 
            variable pk(1,Kcluster);
            expression Y;
            Y=[];
            for k=1:Kcluster
                Y=[Y (t1*(trace(Ak(:,:,k)*Wk1(:,:,k)))*SNR+(Eelec+EDA)*L)];
            end
%             Y1=sum(Y(1:K));
%             minimize real(Y1+Edt+t0*(PS*trace(W0)+M*PIRS+trace(BB*W0)+I0)-t0*yita*Z1);
            maximize real(trace(C*W0)-sum(Y(1:Kcluster))-Edt-t0*PS*trace(W0));
            subject to
            for k=1:Kcluster
                real(trace(Hk(:,:,k)*Wk1(:,:,k)))==1;
                real(trace(Wk1(:,:,k)))<=pk(:,k);
                pk(:,k)>=0;
                Wk1(:,:,k)==hermitian_semidefinite(Nt);
            end
                real(trace(W0))<=1;
                W0==hermitian_semidefinite(Nt);
       cvx_end
       %恢复秩1解
       for k=1:Kcluster
           WK(:,:,k)=Wk1(:,:,k)/pk(:,k);
       end
       max_F=-10;
       max_w2=0;
       for k=1:Kcluster
           max_w1(:,k)=0;
       end
       L2=10000;
       [U2, Sigma2] = eig(W0);
       for l = 1 : L2
           w1=[];
           r1=sqrt(2)/2*(randn(Nt,1)+1j*randn(Nt,1));
           for k=1:Kcluster
               [U1,Sigma1]=eig(WK(:,:,k));%对每一个WK特征值分解
               s_=U1 * (Sigma1)^(0.5) * r1;
               w1=[w1 s_];%用U*sqrt(Sigma)*r表示每个时隙生成的是，并放在同一个数组中,构造K个秩1矩阵解
           end
           r2=sqrt(2)/2*(randn(Nt,1)+1j*randn(Nt,1));
           w2=U2 * (Sigma2)^(0.5) * r2;  %构造秩1矩阵解
           ss=[];
           for k=1:Kcluster
               ss=[ss (t1*(((w1(:,k))'*Ak(:,:,k)*(w1(:,k)))/((w1(:,k))'*Hk(:,:,k)*(w1(:,k))))*SNR+(Eelec+EDA)*L)];
           end
           F=w2'*C*w2-sum(ss(1:Kcluster))-Edt-t0*PS*(w2'*w2);
           for k=1:Kcluster
               if (((w1(:,k)).'*(w1(:,k)))<=1)
                   ttt(k)=1;
               else
                   ttt(k)=0;
               end
           end
           if (F > max_F && (w2'*w2)<=1 && all(ttt)==1)
              max_F = F;
              max_w1 = w1;
              max_w2 = w2;
           end
       end
       w0=max_w2;
       wk=max_w1;
end