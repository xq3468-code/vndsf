function [ak, v0, theta] = AEbenefitSCA(hr_k, g, hd_k, hr_n, hd_n, M, Kcluster, N, SNR, PS, Pirs, pout, derta1_2, derta2_2, derta3n_2, w0, wk, t1, t0, yita)
        K=Kcluster;
        for k=1:K
            theta(:,k)=mod((angle((wk(:,k))'*hd_k(:,k))*ones(M,1)-angle(diag((wk(:,k))'*g)*hr_k(:,k))),2*pi);%IRS最优相位 M*1
        end
        ak_=[];
        for k=1:K
            ak1=ones(M,1);
            ak_=[ak_ ak1];  %ak_为原文的ak_q-1，即SCA算法的初始迭代点 K个M*1
        end
        phi0_=unifrnd(0,2*pi,M,1);
        v0_=cos(phi0_)+sin(phi0_)*1j;  %v0_为原文的v0_q-1，即SCA算法的初始迭代点 M*1
        w01=(norm(w0))^2;  %w01为原文的w0_，即||w0||^2
        wk1=[];
        for k=1:K
            wk11=(norm(wk(:,k)))^2;  
            wk1=[wk1 wk11];  %wk1为原文的wk_，即||wk||^2
        end
        Eeh=t0*(PS*w01+M*Pirs); 
        g_=[];
        for k=1:K
            g_=[g_ ; (wk(:,k))'*g];  %1*M
            G(:,:,k)=diag((abs(g_(k,:))).^2);  %M*M
            bk(:,k)=diag((hr_k(:,k))')*(g_(k,:))';  %M*1
            Hr_k(:,:,k)=diag((abs(hr_k(:,k))).^2);  %M*M
            hdk_(:,k)=(wk(:,k))'*hd_k(:,k);   %1*1
        end
        g0_=(w0)'*g;  %1*M
        G0=PS*diag((abs(g0_)).^2)+derta1_2*eye(M);   %M*M
        for n=1:N
            hdn_(:,n)=(w0)'*(hd_n(:,n));  %1*1
            bn(:,n)=diag((hr_n(:,n))')*(g0_)';  %M*1
            Hr_n(:,:,n)=diag((abs(hr_n(:,n))).^2);  %M*M
        end
        Sh=0;
        for n=1:N
            Sh1(:,:,n)=bn(:,n)*(bn(:,n))';
            Sh=Sh+Sh1(:,:,n);
        end
        SH=PS*Sh;
        PAI=0;
        for n=1:N
            PAI=PAI+Hr_n(:,:,n);
        end
        PA=derta1_2*PAI;
        Xi=0;
        for n=1:N
            Xi1(:,n)=bn(:,n)*hdn_(:,n);
            Xi=Xi+Xi1(:,n);
        end
        XI=PS*Xi;
        HD1=0;
        for n=1:N
            HD1=HD1+(abs(hdn_(:,n)))^2;
        end
        HD=PS*HD1;
        ZAO=0;
        for n=1:N
            ZAO=ZAO+derta3n_2;
        end
        for k=1:K
            tk_(:,k)=(derta1_2*((ak_(:,k)).'*G(:,:,k)*ak_(:,k))+derta2_2*wk1(:,k))/((abs(abs(hdk_(:,k))+abs((bk(:,k))')*ak_(:,k)))^2);
            uk_(:,k)=tk_(:,k)*((ak_(:,k)).'*Hr_k(:,:,k)*ak_(:,k));
        end
        A11=[];
        B11=[];
        for k=1:K
            A11=[A11 (t1*(((derta1_2*((ak_(:,k)).'*G(:,:,k)*ak_(:,k))+derta2_2*wk1(:,k))/((abs(abs(hdk_(:,k))+abs((bk(:,k))')*ak_(:,k)))^2))*SNR))];
        end
        A_=sum(A11(1:K));
        for n=1:N
            B11=[B11 (PS*(abs(hdn_(:,n)+(bn(:,n))'*v0_))^2+derta1_2*(v0_'*Hr_n(:,:,n)*v0_)+derta3n_2)];
        end
        B_=sum(B11(1:N));
        SS_=t0*yita*B_-A_;
        SSS=[];
        for Isca=1:10 %1:100  quiet
            cvx_begin quiet
                variable ak(M,K);
                variable v0(M,1) complex;
                variable tk(1,K);
                variable uk(1,K);
                expression A;
                A=[];
                for k=1:K
                    A=[A (t1*tk(:,k)*SNR)];
                end
%                 minimize real(square_pos(norm((v0'*G0), 2)))   %二范数求模求平方用square_pos(norm(x, 2))：||x||^2
                maximize real(t0*yita*real(2*real(v0'*(SH*v0_+XI+PA*v0_))-(v0_)'*SH*v0_-(v0_)'*PA*v0_+HD+ZAO)-sum(A(1:K)))
                subject to 
                for k=1:K
                    (10^10)*(derta1_2*((ak(:,k)).'*G(:,:,k)*ak(:,k))+derta2_2*wk1(:,k))<=(10^10)*(tk_(:,k)*(abs(abs(hdk_(:,k))+abs((bk(:,k))')*ak_(:,k)))^2+...
                        (abs(abs(hdk_(:,k))+abs((bk(:,k))')*ak_(:,k)))^2*(tk(:,k)-tk_(:,k))+...
                        tk_(:,k)*2*real((ak_(:,k)).'*abs(bk(:,k))*abs((bk(:,k))')+abs((hdk_(:,k))')*abs((bk(:,k))'))*(ak(:,k)-ak_(:,k)));
                    SNR*uk(:,k)+derta1_2*((ak(:,k)).'*eye(M)*ak(:,k))<=pout;
                    ((ak(:,k)).'*Hr_k(:,:,k)*ak(:,k))<=(uk_(:,k))/(tk_(:,k))+(uk(:,k)-uk_(:,k))/(tk_(:,k))-((uk_(:,k))/(tk_(:,k))^2)*(tk(:,k)-tk_(:,k));
                    tk(:,k)>=0;
                    uk(:,k)>=0;
                end
                real(v0'*G0*v0)<=pout;
                for k=1:K
                    for m=1:M
                        ak(m,k)>=1;
                    end
                end
                for m=1:M
                    2*real((v0(m))'*v0_(m))-(v0_(m))'*v0_(m)>=1;
                end
            cvx_end
            ASS1=[];
            for k=1:K
                ASS1=[ASS1 (t1*(((derta1_2*((ak(:,k)).'*G(:,:,k)*ak(:,k))+derta2_2*wk1(:,k))/((abs(abs(hdk_(:,k))+abs((bk(:,k))')*ak(:,k)))^2))*SNR))];
            end
            ASS=sum(ASS1(1:K));
            BSS1=[];
            for n=1:N
                BSS1=[BSS1 ((PS*(abs(hdn_(:,n)+(bn(:,n))'*v0))^2+derta1_2*(v0'*Hr_n(:,:,n)*v0))+derta3n_2)];
            end
            BSS=sum(BSS1(1:N));
            SS=t0*yita*BSS-ASS;
            if mean(abs(SS-SS_))<1e-3 %1e-8
               break
            else
               v0_=v0;
               SS_=SS;
               for k=1:K
                   ak_(:,k)=ak(:,k);
                   tk_(:,k)=(derta1_2*((ak_(:,k)).'*G(:,:,k)*ak_(:,k))+derta2_2*wk1(:,k))/((abs(abs(hdk_(:,k))+abs((bk(:,k))')*ak_(:,k)))^2);
                   uk_(:,k)=tk_(:,k)*((ak_(:,k)).'*Hr_k(:,:,k)*ak_(:,k));
               end
            end
            SSS=[SSS SS];
        end
%         figure
%         plot(1:length(SSS),real(SSS));
end