function [v0, theta] = passiveSCA(hr_k, g, hd_k, hr_n, hd_n, M, K, N,  PS, w0, wk)
        for k=1:K
            theta(:,k)=mod((angle((wk(:,k))'*hd_k(:,k))*ones(M,1)-angle(diag((wk(:,k))'*g)*hr_k(:,k))),2*pi);%IRS最优相位 M*1
        end
        phi0_=unifrnd(0,2*pi,M,1);
        v0=cos(phi0_)+sin(phi0_)*1j;  %v0_为原文的v0_q-1，即SCA算法的初始迭代点 M*1
        w01=(norm(w0))^2;  %w01为原文的w0_，即||w0||^2
        wk1=[];
        for k=1:K
            wk11=(norm(wk(:,k)))^2;  
            wk1=[wk1 wk11];  %wk1为原文的wk_，即||wk||^2
        end
        g0_=(w0)'*g;  %1*M
        for n=1:N
            hdn_(:,n)=(w0)'*(hd_n(:,n));  %1*1
            bn(:,n)=diag((hr_n(:,n))')*(g0_)';  %M*1
        end
        Sh=0;
        for n=1:N
            Sh1(:,:,n)=bn(:,n)*(bn(:,n))';
            Sh=Sh+Sh1(:,:,n);
        end
        E=PS*Sh;
        bd=0;
        for n=1:N
            bd1(:,n)=bn(:,n)* hdn_(:,n);
            bd=bd+bd1(:,n);
        end
        for itsca=1:500
            yitam=E*v0+PS*bd;
            v0_=zeros(M,1);
            for m=1:M
                if yitam(m)==0
                    v0_(m,1)=1;
                else
                    v0_(m,1)=(yitam(m))/abs(yitam(m));
                end
            end
            if norm(v0-v0_)<=1e-12
                break
            else
                v0=v0_;
            end
        end
        
%     phi=unifrnd(0,2*pi,1,M*N);
%     u=cos(phi)+sin(phi)*1j;
%     u=u';
%     xk=diag(hr)*g;
%     yk=hd;
%     zk=xk*xk';
%     for itsca=1:500
%         itsca
%         s=zk*u+xk*yk';
%         s_=s./abs(s);
%         u_=zeros(M*N,1);
%         for i=1:M*N
%             if s(i)==0
%                 u_(i)=1;
%             else
%                 u_(i)=s(i)/(abs(s(i)));
%             end
%         end
%         if norm(u-u_)<=1e-12
%             break
%         else
%             u=u_;
%         end
%     end

%         Xi=0;
%         for n=1:N
%             Xi1(:,n)=bn(:,n)*hdn_(:,n);
%             Xi=Xi+Xi1(:,n);
%         end
%         XI=PS*Xi;
%         HD1=0;
%         for n=1:N
%             HD1=HD1+(abs(hdn_(:,n)))^2;
%         end
%         HD=PS*HD1;
         
%         for n=1:N
%             Rn(:,:,n)=[bn(:,n)*(bn(:,n))' bn(:,n)*hdn_(:,n) ; (hdn_(:,n))'*(bn(:,n))' (abs(hdn_(:,n)))^2];
%         end
%         W_=0;
%         for n=1:N
%             W(:,:,n)=PS*Rn(:,:,n);
%             W_=W_+W(:,:,n);
%         end
%         A=[];
%         cvx_begin sdp 
%             variable V0(M+1,M+1)  hermitian semidefinite;
%             maximize real(trace(W_*V0))  %cvx优化循环和，用sum函数
%             subject to 
%             V0==hermitian_semidefinite(M+1);
%             diag(V0)==1;%半正定阵最后一个数是1
% %             diag(V0)>=1;
%        cvx_end
%        max_F1 = 0;
%        max_v0 = 0;
%        [U,Sigma]=eig(V0);
%        L=10000;
%        for l=1:L %高斯随机化获得秩1解
%            r=sqrt(2)/2*(randn(M+1,1)+1j*randn(M+1,1));
%            v02=U*sqrt(Sigma)*r;
%            ss2=v02'*W_*v02;
%            if (ss2>max_F1)
%               max_v0=v02;
%               max_F1=ss2;
%            end
%        end
%        v2=(max_v0/max_v0(end));%把反射因子v0最后一项变成1
%        v0=v2(1:M);
%        BSS=[];
%        for n=1:N
%            BSS=[BSS (PS*(abs(hdn_(:,n)+(bn(:,n))'*v0_))^2)];
%        end
%        BSS1=sum(BSS(1:N));
%        SS_=t0*yita*BSS1;
%        SSS=[];
%         for Isca=1:10 %1:100  quiet
%             cvx_begin 
%                 variable v0(M,1) complex;
% %                 minimize real(square_pos(norm((v0'*G0), 2)))   %二范数求模求平方用square_pos(norm(x, 2))：||x||^2
%                 maximize real(t0*yita*real(2*real(v0'*(E*v0_+XI))-(v0_)'*E*v0_+HD))
% %                 maximize real(t0*yita*real(B1)-A1-Edt-t0*(Eeh+v0'*G0*v0))
%                 subject to 
%                 for m=1:M
%                     2*real((v0(m))'*v0_(m))-(v0_(m))'*v0_(m)==1;
% %                     abs(v0(m))==1;
%                 end
%             cvx_end
%             BSS1=[];
%             for n=1:N
%                 BSS1=[BSS1 (PS*(abs(hdn_(:,n)+(bn(:,n))'*v0))^2)];
%             end
%             BSS=sum(BSS1(1:N));
%             SS=t0*yita*BSS;
%             if mean(abs(SS-SS_))<1e-7 %1e-8
%                break
%             else
%                v0_=v0;
%                SS_=SS;
%             end
%             SSS=[SSS SS];
%         end
end