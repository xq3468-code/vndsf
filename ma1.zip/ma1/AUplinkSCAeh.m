function [v0] = AUplinkSCAeh(g, M,  PS, pout, derta1_2, w0)
        phi0_=unifrnd(0,2*pi,M,1);
        v0_=cos(phi0_)+sin(phi0_)*1j;  %v0_为原文的v0_q-1，即SCA算法的初始迭代点 M*1
        g0_=(w0)'*g;  %1*M
        G0=PS*diag((abs(g0_)).^2)+derta1_2*eye(M);   %M*M
        cvx_begin quiet
            variable v0(M,1) complex;
            find v0;
            subject to 
            real(v0'*G0*v0)<=pout;
            for m=1:M
                2*real((v0(m))'*v0_(m))-(v0_(m))'*v0_(m)==1;
            end
       cvx_end
%         figure
%         plot(1:length(SSS),real(SSS));
end