function [v0] = hSingle_SCA(g, hr_n, hd_n, M,  N, PS, Pirs, pout, derta1_2, derta3n_2, t0, yita)
        phi0_=unifrnd(0,2*pi,M,1);
        v0_=cos(phi0_)+sin(phi0_)*1j;  %v0_为原文的v0_q-1，即SCA算法的初始迭代点 M*1
        Eeh=t0*(PS+M*Pirs); 
        G0=PS*diag((abs(g)).^2)+derta1_2*eye(M);   %M*M
        for n=1:N
            bn(:,n)=diag((hr_n(:,n))')*g';  %M*1
            Hr_n(:,:,n)=diag((abs(hr_n(:,n))).^2);  %M*M
        end
        Sh=0;
        for n=1:N
            Sh1(:,:,n)=bn(:,n)*(bn(:,n))';
            Sh=Sh+Sh1(:,:,n);
        end
        SH=PS*Sh;
        PAI=0;
        for n=1:N
            PAI=PAI+Hr_n(:,:,n);
        end
        PA=derta1_2*PAI;
        Xi=0;
        for n=1:N
            Xi1(:,n)=bn(:,n)*hd_n(:,n);
            Xi=Xi+Xi1(:,n);
        end
        XI=PS*Xi;
        HD1=0;
        for n=1:N
            HD1=HD1+(abs(hd_n(:,n)))^2;
        end
        HD=PS*HD1;
        ZAO=0;
        for n=1:N
            ZAO=ZAO+derta3n_2;
        end
        B11=[];
        for n=1:N
            B11=[B11 (PS*(abs(hd_n(:,n)+(bn(:,n))'*v0_))^2+derta1_2*(v0_'*Hr_n(:,:,n)*v0_)+derta3n_2)];
        end
        B_=sum(B11(1:N));
        SS_=Eeh+t0*(v0_'*G0*v0_)-t0*yita*B_;
        SSS=[];
        for Isca=1:10 %1:100  quiet
            cvx_begin quiet
                variable v0(M,1) complex;
%                 minimize real(square_pos(norm((v0'*G0), 2)))   %二范数求模求平方用square_pos(norm(x, 2))：||x||^2
                minimize real(t0*(v0'*G0*v0)-t0*yita*real(2*real(v0'*(SH*v0_+XI+PA*v0_))-(v0_)'*SH*v0_-(v0_)'*PA*v0_+HD+ZAO))
                subject to 
                real(v0'*G0*v0)<=pout;
                for m=1:M
                    2*real((v0(m))'*v0_(m))-(v0_(m))'*v0_(m)>=1;
                end
            cvx_end
            BSS1=[];
            for n=1:N
                BSS1=[BSS1 ((PS*(abs(hd_n(:,n)+(bn(:,n))'*v0))^2+derta1_2*(v0'*Hr_n(:,:,n)*v0))+derta3n_2)];
            end
            BSS=sum(BSS1(1:N));
            SS=Eeh+t0*(v0'*G0*v0)-t0*yita*BSS;
            if mean(abs(SS-SS_))<1e-3 %1e-8
               break
            else
               v0_=v0;
               SS_=SS;
            end
            SSS=[SSS SS];
        end
%         figure
%         plot(1:length(SSS),real(SSS));
end