function [ak, v0, theta] = ARandomSCA(hr_k, g, hd_k, hr_n, hd_n, M, Kcluster, N, SNR, PS, Pirs, pout, derta1_2, derta2_2, derta3n_2, w0, wk, t0)
        theta=[];
        for k=1:Kcluster
            phik_=unifrnd(0,2*pi,M,1);
            vk_=cos(phik_)+sin(phik_)*1j; 
            theta=[theta vk_]; %%随机生成上行IRS相移
        end
        ak_=[];
        for k=1:Kcluster
            ak1=ones(M,1);
            ak_=[ak_ ak1];  %ak_为原文的ak_q-1，即SCA算法的初始迭代点 K个M*1
        end
        phi0_=unifrnd(0,2*pi,M,1);
        v0_=cos(phi0_)+sin(phi0_)*1j;  %v0_为原文的v0_q-1，即SCA算法的初始迭代点 M*1
        w01=(norm(w0))^2;  %w01为原文的w0_，即||w0||^2
        wk1=[];
        for k=1:Kcluster
            wk11=(norm(wk(:,k)))^2;  
            wk1=[wk1 wk11];  %wk1为原文的wk_，即||wk||^2
        end
        Eeh=t0*(PS*w01+M*Pirs); 
        g_=[];
        for k=1:Kcluster
            g_=[g_ ; (wk(:,k))'*g];  %1*M
            G(:,:,k)=diag((abs(g_(k,:))).^2);  %M*M
            bk(:,k)=diag((hr_k(:,k))')*(g_(k,:))';  %M*1
            Hr_k(:,:,k)=diag((abs(hr_k(:,k))).^2);  %M*M
            hdk_(:,k)=(wk(:,k))'*hd_k(:,k);   %1*1
        end
        g0_=(w0)'*g;  %1*M
        G0=PS*diag((abs(g0_)).^2)+derta1_2*eye(M);   %M*M
        for n=1:N
            hdn_(:,n)=(w0)'*(hd_n(:,n));  %1*1
            bn(:,n)=diag((hr_n(:,n))')*(g0_)';  %M*1
            Hr_n(:,:,n)=diag((abs(hr_n(:,n))).^2);  %M*M
        end
        Sh=0;
        for n=1:N
            Sh1(:,:,n)=bn(:,n)*(bn(:,n))';
            Sh=Sh+Sh1(:,:,n);
        end
        SH=PS*Sh;
        PAI=0;
        for n=1:N
            PAI=PAI+Hr_n(:,:,n);
        end
        PA=derta1_2*PAI;
        Xi=0;
        for n=1:N
            Xi1(:,n)=bn(:,n)*hdn_(:,n);
            Xi=Xi+Xi1(:,n);
        end
        XI=PS*Xi;
        HD1=0;
        for n=1:N
            HD1=HD1+(abs(hdn_(:,n)))^2;
        end
        HD=PS*HD1;
        ZAO=0;
        for n=1:N
            ZAO=ZAO+derta3n_2;
        end
        for k=1:Kcluster
            tk_(:,k)=(derta1_2*((ak_(:,k)).'*G(:,:,k)*ak_(:,k))+derta2_2*wk1(:,k))/((abs(abs(hdk_(:,k))+abs((bk(:,k))')*ak_(:,k)))^2);
            uk_(:,k)=tk_(:,k)*((ak_(:,k)).'*Hr_k(:,:,k)*ak_(:,k));
        end
        %%******************************在约束下随机生成上行IRS振幅******************************************
        cvx_begin quiet
            variable ak(M,Kcluster);
            variable tk(1,Kcluster);
            variable uk(1,Kcluster);
            find ak;
            subject to 
            for k=1:Kcluster
                (10^10)*(derta1_2*((ak(:,k)).'*G(:,:,k)*ak(:,k))+derta2_2*wk1(:,k))<=(10^10)*(tk_(:,k)*(abs(abs(hdk_(:,k))+abs((bk(:,k))')*ak_(:,k)))^2+...
                    (abs(abs(hdk_(:,k))+abs((bk(:,k))')*ak_(:,k)))^2*(tk(:,k)-tk_(:,k))+...
                    tk_(:,k)*2*real((ak_(:,k)).'*abs(bk(:,k))*abs((bk(:,k))')+abs((hdk_(:,k))')*abs((bk(:,k))'))*(ak(:,k)-ak_(:,k)));
                SNR*uk(:,k)+derta1_2*((ak(:,k)).'*eye(M)*ak(:,k))<=pout;
                ((ak(:,k)).'*Hr_k(:,:,k)*ak(:,k))<=(uk_(:,k))/(tk_(:,k))+(uk(:,k)-uk_(:,k))/(tk_(:,k))-((uk_(:,k))/(tk_(:,k))^2)*(tk(:,k)-tk_(:,k));
                tk(:,k)>=0;
                uk(:,k)>=0;
            end
            for k=1:Kcluster
                for m=1:M
                    ak(m,k)>=1;
                end
            end
        cvx_end
        %%******************************随机生成下行IRS反射因子*************************************************
        cvx_begin quiet
            variable v0(M,1) complex;
            find v0;
            subject to
            real(v0'*G0*v0)<=pout;
            for m=1:M
                2*real((v0(m))'*v0_(m))-(v0_(m))'*v0_(m)==1;
            end
        cvx_end
%         figure
%         plot(1:length(SSS),real(SSS));
end