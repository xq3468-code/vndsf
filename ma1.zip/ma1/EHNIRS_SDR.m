function [w0] = EHNIRS_SDR(hd_k, hd_n, Nt, Kcluster, N, PS, derta2_2, t0, yita)
       for k=1:Kcluster
           Ak(:,:,k)=derta2_2*eye(Nt);
           Hk(:,:,k)=hd_k(:,k)*(hd_k(:,k))';
       end
       C1=0;
       for n1=1:N
           Cn1(:,:,n1)=PS*(hd_n(:,n1)*(hd_n(:,n1))');
           C1=C1+Cn1(:,:,n1);
       end
       C=t0*yita*C1;
       cvx_begin sdp quiet
            variable W0(Nt,Nt) hermitian semidefinite; 
            maximize real(trace(C*W0)-t0*PS*trace(W0));
            subject to
            real(trace(W0))<=1;
            W0==hermitian_semidefinite(Nt);
       cvx_end
       %恢复秩1解
       max_F=-10;
       max_w2=0;
       L2=10000;
       [U2, Sigma2] = eig(W0);
       for l = 1 : L2
           r2=sqrt(2)/2*(randn(Nt,1)+1j*randn(Nt,1));
           w2=U2 * (Sigma2)^(0.5) * r2;  %构造秩1矩阵解
           F=w2'*C*w2-t0*PS*(w2'*w2);
           if (F > max_F && (w2'*w2)<=1)
              max_F = F;
              max_w2 = w2;
           end
       end
       w0=max_w2;
end